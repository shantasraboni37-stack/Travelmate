.class final Lcom/GETMODPC/M;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/GETMODPC/F;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1a
    name = "Config"
.end annotation


# static fields
.field static final COLOR_BACKGROUND:Ljava/lang/String;

.field static final COLOR_BUTTON_EXIT:Ljava/lang/String;

.field static final COLOR_BUTTON_UPDATE:Ljava/lang/String;

.field static final COLOR_CONTENT_TEXT:Ljava/lang/String;

.field static final COLOR_DARK_BACKGROUND:Ljava/lang/String;

.field static final COLOR_DARK_BUTTON_EXIT:Ljava/lang/String;

.field static final COLOR_DARK_BUTTON_UPDATE:Ljava/lang/String;

.field static final COLOR_DARK_CONTENT_TEXT:Ljava/lang/String;

.field static final COLOR_DARK_EXIT_TEXT:Ljava/lang/String;

.field static final COLOR_DARK_SUBTITLE_TEXT:Ljava/lang/String;

.field static final COLOR_DARK_TITLE_TEXT:Ljava/lang/String;

.field static final COLOR_DARK_UPDATE_TEXT:Ljava/lang/String;

.field static final COLOR_EXIT_TEXT:Ljava/lang/String;

.field static final COLOR_SUBTITLE_TEXT:Ljava/lang/String;

.field static final COLOR_TITLE_TEXT:Ljava/lang/String;

.field static final COLOR_UPDATE_TEXT:Ljava/lang/String;

.field private static final short:[S


# direct methods
.method static constructor <clinit>()V
    .registers 52

    const/4 v0, 0x4

    invoke-static {v0}, Lcom/GETMODPC/U;->classesInit0(I)V

    const v0, 0x70

    new-array v0, v0, [S

    fill-array-data v0, :array_160

    sput-object v0, Lcom/GETMODPC/M;->short:[S

    invoke-static/range {}, Lcom/GETMODPC/M;->nnec()[S

    move-result-object v34

    const v37, 0x18d

    const v35, 0x0

    const v36, 0x7

    invoke-static/range {v34 .. v37}, Lcom/GETMODPC/A;->oooc([SIII)Ljava/lang/String;

    move-result-object v34

    move-object/from16 v0, v34

    sput-object v0, Lcom/GETMODPC/M;->COLOR_BACKGROUND:Ljava/lang/String;

    invoke-static/range {}, Lcom/GETMODPC/M;->nnec()[S

    move-result-object v26

    const v29, 0xbc4

    const v27, 0x7

    const v28, 0x7

    invoke-static/range {v26 .. v29}, Lcom/GETMODPC/C;->nncn([SIII)Ljava/lang/String;

    move-result-object v26

    move-object/from16 v0, v26

    sput-object v0, Lcom/GETMODPC/M;->COLOR_BUTTON_EXIT:Ljava/lang/String;

    invoke-static/range {}, Lcom/GETMODPC/M;->nnec()[S

    move-result-object v15

    const v18, 0x41f

    const v16, 0xe

    const v17, 0x7

    invoke-static/range {v15 .. v18}, Lcom/GETMODPC/E;->ncce([SIII)Ljava/lang/String;

    move-result-object v15

    move-object/from16 v0, v15

    sput-object v0, Lcom/GETMODPC/M;->COLOR_BUTTON_UPDATE:Ljava/lang/String;

    invoke-static {}, Lcom/GETMODPC/M;->nnec()[S

    move-result-object v6

    const v9, 0x49a

    const v7, 0x15

    const v8, 0x7

    invoke-static/range {v6 .. v9}, Lcom/GETMODPC/C;->nncn([SIII)Ljava/lang/String;

    move-result-object v6

    move-object/from16 v0, v6

    sput-object v0, Lcom/GETMODPC/M;->COLOR_CONTENT_TEXT:Ljava/lang/String;

    invoke-static {}, Lcom/GETMODPC/M;->nnec()[S

    move-result-object v7

    const v10, 0x5c9

    const v8, 0x1c

    const v9, 0x7

    invoke-static/range {v7 .. v10}, Lcom/GETMODPC/A;->oooc([SIII)Ljava/lang/String;

    move-result-object v7

    move-object/from16 v0, v7

    sput-object v0, Lcom/GETMODPC/M;->COLOR_DARK_BACKGROUND:Ljava/lang/String;

    invoke-static/range {}, Lcom/GETMODPC/M;->nnec()[S

    move-result-object v16

    const v19, 0xb2c

    const v17, 0x23

    const v18, 0x7

    invoke-static/range {v16 .. v19}, Lcom/GETMODPC/D;->cnec([SIII)Ljava/lang/String;

    move-result-object v16

    move-object/from16 v0, v16

    sput-object v0, Lcom/GETMODPC/M;->COLOR_DARK_BUTTON_EXIT:Ljava/lang/String;

    invoke-static/range {}, Lcom/GETMODPC/M;->nnec()[S

    move-result-object v20

    const v23, 0x590

    const v21, 0x2a

    const v22, 0x7

    invoke-static/range {v20 .. v23}, Lcom/GETMODPC/D;->cnec([SIII)Ljava/lang/String;

    move-result-object v20

    move-object/from16 v0, v20

    sput-object v0, Lcom/GETMODPC/M;->COLOR_DARK_BUTTON_UPDATE:Ljava/lang/String;

    invoke-static {}, Lcom/GETMODPC/M;->nnec()[S

    move-result-object v9

    const v12, 0xad3

    const v10, 0x31

    const v11, 0x7

    invoke-static/range {v9 .. v12}, Lcom/GETMODPC/D;->cnec([SIII)Ljava/lang/String;

    move-result-object v9

    move-object/from16 v0, v9

    sput-object v0, Lcom/GETMODPC/M;->COLOR_DARK_CONTENT_TEXT:Ljava/lang/String;

    invoke-static {}, Lcom/GETMODPC/M;->nnec()[S

    move-result-object v7

    const v10, 0x406

    const v8, 0x38

    const v9, 0x7

    invoke-static/range {v7 .. v10}, Lcom/GETMODPC/C;->nncn([SIII)Ljava/lang/String;

    move-result-object v7

    move-object/from16 v0, v7

    sput-object v0, Lcom/GETMODPC/M;->COLOR_DARK_EXIT_TEXT:Ljava/lang/String;

    invoke-static/range {}, Lcom/GETMODPC/M;->nnec()[S

    move-result-object v37

    const v40, 0x3a7

    const v38, 0x3f

    const v39, 0x7

    invoke-static/range {v37 .. v40}, Lcom/GETMODPC/D;->cnec([SIII)Ljava/lang/String;

    move-result-object v37

    move-object/from16 v0, v37

    sput-object v0, Lcom/GETMODPC/M;->COLOR_DARK_SUBTITLE_TEXT:Ljava/lang/String;

    invoke-static/range {}, Lcom/GETMODPC/M;->nnec()[S

    move-result-object v34

    const v37, 0x686

    const v35, 0x46

    const v36, 0x7

    invoke-static/range {v34 .. v37}, Lcom/GETMODPC/C;->nncn([SIII)Ljava/lang/String;

    move-result-object v34

    move-object/from16 v0, v34

    sput-object v0, Lcom/GETMODPC/M;->COLOR_DARK_TITLE_TEXT:Ljava/lang/String;

    invoke-static/range {}, Lcom/GETMODPC/M;->nnec()[S

    move-result-object v10

    const v13, 0xadf

    const v11, 0x4d

    const v12, 0x7

    invoke-static/range {v10 .. v13}, Lcom/GETMODPC/D;->cnec([SIII)Ljava/lang/String;

    move-result-object v10

    move-object/from16 v0, v10

    sput-object v0, Lcom/GETMODPC/M;->COLOR_DARK_UPDATE_TEXT:Ljava/lang/String;

    invoke-static/range {}, Lcom/GETMODPC/M;->nnec()[S

    move-result-object v13

    const v16, 0x1a3

    const v14, 0x54

    const v15, 0x7

    invoke-static/range {v13 .. v16}, Lcom/GETMODPC/C;->nncn([SIII)Ljava/lang/String;

    move-result-object v13

    move-object/from16 v0, v13

    sput-object v0, Lcom/GETMODPC/M;->COLOR_EXIT_TEXT:Ljava/lang/String;

    invoke-static/range {}, Lcom/GETMODPC/M;->nnec()[S

    move-result-object v24

    const v27, 0x3aa

    const v25, 0x5b

    const v26, 0x7

    invoke-static/range {v24 .. v27}, Lcom/GETMODPC/E;->ncce([SIII)Ljava/lang/String;

    move-result-object v24

    move-object/from16 v0, v24

    sput-object v0, Lcom/GETMODPC/M;->COLOR_SUBTITLE_TEXT:Ljava/lang/String;

    invoke-static/range {}, Lcom/GETMODPC/M;->nnec()[S

    move-result-object v15

    const v18, 0x945

    const v16, 0x62

    const v17, 0x7

    invoke-static/range {v15 .. v18}, Lcom/GETMODPC/E;->ncce([SIII)Ljava/lang/String;

    move-result-object v15

    move-object/from16 v0, v15

    sput-object v0, Lcom/GETMODPC/M;->COLOR_TITLE_TEXT:Ljava/lang/String;

    invoke-static/range {}, Lcom/GETMODPC/M;->nnec()[S

    move-result-object v38

    const v41, 0x1f3

    const v39, 0x69

    const v40, 0x7

    invoke-static/range {v38 .. v41}, Lcom/GETMODPC/E;->ncce([SIII)Ljava/lang/String;

    move-result-object v38

    move-object/from16 v0, v38

    sput-object v0, Lcom/GETMODPC/M;->COLOR_UPDATE_TEXT:Ljava/lang/String;

    return-void

    nop

    :array_160
    .array-data 2
        0x1aes
        0x1cbs
        0x1cbs
        0x1cbs
        0x1cbs
        0x1cbs
        0x1cbs
        0xbe7s
        0xb81s
        0xbf4s
        0xb81s
        0xbf4s
        0xb81s
        0xbf4s
        0x43cs
        0x42ds
        0x42es
        0x426s
        0x429s
        0x459s
        0x42cs
        0x4b9s
        0x4aes
        0x4a8s
        0x4aes
        0x4a8s
        0x4aes
        0x4a8s
        0x5eas
        0x5fbs
        0x5f8s
        0x5fbs
        0x5f8s
        0x5fbs
        0x5f8s
        0xb0fs
        0xb18s
        0xb1es
        0xb18s
        0xb1es
        0xb18s
        0xb1es
        0x5b3s
        0x5a2s
        0x5a1s
        0x5a9s
        0x5a6s
        0x5d6s
        0x5a3s
        0xaf0s
        0xa97s
        0xa97s
        0xa97s
        0xa97s
        0xa97s
        0xa97s
        0x425s
        0x443s
        0x443s
        0x443s
        0x443s
        0x443s
        0x443s
        0x384s
        0x3e3s
        0x3e3s
        0x3e3s
        0x3e3s
        0x3e3s
        0x3e3s
        0x6a5s
        0x6c0s
        0x6c0s
        0x6c0s
        0x6c0s
        0x6c0s
        0x6c0s
        0xafcs
        0xa99s
        0xa99s
        0xa99s
        0xa99s
        0xa99s
        0xa99s
        0x180s
        0x197s
        0x191s
        0x197s
        0x191s
        0x197s
        0x191s
        0x389s
        0x39ds
        0x39fs
        0x39ds
        0x39fs
        0x39ds
        0x39fs
        0x966s
        0x975s
        0x975s
        0x975s
        0x975s
        0x975s
        0x975s
        0x1d0s
        0x1b5s
        0x1b5s
        0x1b5s
        0x1b5s
        0x1b5s
        0x1b5s
    .end array-data
.end method

.method private constructor <init>()V
    .registers 52

    move-object/from16 v0, p0

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public static native nnec()[S
.end method
