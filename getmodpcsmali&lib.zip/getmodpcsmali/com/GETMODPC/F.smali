.class public Lcom/GETMODPC/F;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/GETMODPC/N;,
        Lcom/GETMODPC/M;
    }
.end annotation


# static fields
.field private static currentContextRef:Ljava/lang/ref/WeakReference;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/lang/ref/WeakReference<",
            "Landroid/content/Context;",
            ">;"
        }
    .end annotation
.end field

.field private static currentDialogRef:Ljava/lang/ref/WeakReference;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/lang/ref/WeakReference<",
            "Landroid/app/Dialog;",
            ">;"
        }
    .end annotation
.end field

.field private static final short:[S


# direct methods
.method static bridge synthetic -$$Nest$smisUpdateNeeded(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)Z
    .registers 3

    const/4 p0, 0x0

    return p0
.end method

.method static bridge synthetic -$$Nest$smshowUpdateDialog(Landroid/content/Context;Lorg/json/JSONObject;)V
    .registers 53

    move-object/from16 v1, p1

    move-object/from16 v0, p0

    invoke-static {v0, v1}, Lcom/GETMODPC/F;->neon(Ljava/lang/Object;Ljava/lang/Object;)V

    return-void
.end method

.method static constructor <clinit>()V
    .registers 52

    const/16 v0, 0x10

    invoke-static {v0}, Lcom/GETMODPC/U;->classesInit0(I)V

    const v0, 0x2eb

    new-array v0, v0, [S

    fill-array-data v0, :array_10

    sput-object v0, Lcom/GETMODPC/F;->short:[S

    return-void

    :array_10
    .array-data 2
        0x954s
        0x962s
        0x964s
        0x963s
        0x978s
        0x97as
        0x942s
        0x967s
        0x973s
        0x976s
        0x963s
        0x972s
        0x953s
        0x97es
        0x976s
        0x97bs
        0x978s
        0x970s
        0x35fs
        0x368s
        0x368s
        0x375s
        0x368s
        0x33as
        0x368s
        0x37fs
        0x37cs
        0x368s
        0x37fs
        0x369s
        0x372s
        0x373s
        0x374s
        0x37ds
        0x33as
        0x37es
        0x373s
        0x37bs
        0x376s
        0x375s
        0x37ds
        0x33as
        0x375s
        0x374s
        0x33as
        0x36es
        0x372s
        0x37fs
        0x377s
        0x37fs
        0x33as
        0x379s
        0x372s
        0x37bs
        0x374s
        0x37ds
        0x37fs
        0x320s
        0x33as
        0x8aas
        0x89ds
        0x89ds
        0x880s
        0x89ds
        0x8cfs
        0x886s
        0x881s
        0x8cfs
        0x887s
        0x88es
        0x881s
        0x88bs
        0x883s
        0x88as
        0x8acs
        0x880s
        0x881s
        0x889s
        0x886s
        0x888s
        0x89as
        0x89ds
        0x88es
        0x89bs
        0x886s
        0x880s
        0x881s
        0x8acs
        0x887s
        0x88es
        0x881s
        0x888s
        0x88as
        0x88bs
        0x8d5s
        0x8cfs
        0x729s
        0x71es
        0x71es
        0x703s
        0x71es
        0x74cs
        0x70fs
        0x703s
        0x701s
        0x71cs
        0x70ds
        0x71es
        0x705s
        0x702s
        0x70bs
        0x74cs
        0x71as
        0x709s
        0x71es
        0x71fs
        0x705s
        0x703s
        0x702s
        0x71fs
        0x756s
        0x74cs
        0x693s
        0x6a5s
        0x6a3s
        0x6a4s
        0x6bfs
        0x6bds
        0x685s
        0x6a0s
        0x6b4s
        0x6b1s
        0x6a4s
        0x6b5s
        0x694s
        0x6b9s
        0x6b1s
        0x6bcs
        0x6bfs
        0x6b7s
        0xae9s
        0xae6s
        0xaecs
        0xafas
        0xae7s
        0xae1s
        0xaecs
        0xaa6s
        0xae1s
        0xae6s
        0xafcs
        0xaeds
        0xae6s
        0xafcs
        0xaa6s
        0xae9s
        0xaebs
        0xafcs
        0xae1s
        0xae7s
        0xae6s
        0xaa6s
        0xac5s
        0xac9s
        0xac1s
        0xac6s
        0x655s
        0x65as
        0x650s
        0x646s
        0x65bs
        0x65ds
        0x650s
        0x61as
        0x65ds
        0x65as
        0x640s
        0x651s
        0x65as
        0x640s
        0x61as
        0x657s
        0x655s
        0x640s
        0x651s
        0x653s
        0x65bs
        0x646s
        0x64ds
        0x61as
        0x67cs
        0x67bs
        0x679s
        0x671s
        0x23ds
        0x20as
        0x20as
        0x217s
        0x20as
        0x258s
        0x21ds
        0x200s
        0x211s
        0x20cs
        0x211s
        0x216s
        0x21fs
        0x258s
        0x219s
        0x208s
        0x208s
        0x242s
        0x258s
        0x616s
        0x620s
        0x626s
        0x621s
        0x63as
        0x638s
        0x600s
        0x625s
        0x631s
        0x634s
        0x621s
        0x630s
        0x611s
        0x63cs
        0x634s
        0x639s
        0x63as
        0x632s
        0xc4fs
        0xc78s
        0xc78s
        0xc65s
        0xc78s
        0xc2as
        0xc6es
        0xc63s
        0xc79s
        0xc67s
        0xc63s
        0xc79s
        0xc79s
        0xc63s
        0xc64s
        0xc6ds
        0xc2as
        0xc6es
        0xc63s
        0xc6bs
        0xc66s
        0xc65s
        0xc6ds
        0xc2as
        0xc6bs
        0xc6cs
        0xc7es
        0xc6fs
        0xc78s
        0xc2as
        0xc6es
        0xc65s
        0xc7ds
        0xc64s
        0xc66s
        0xc65s
        0xc6bs
        0xc6es
        0xc30s
        0xc2as
        0x94fs
        0x979s
        0x97fs
        0x978s
        0x963s
        0x961s
        0x959s
        0x97cs
        0x968s
        0x96ds
        0x978s
        0x969s
        0x948s
        0x965s
        0x96ds
        0x960s
        0x963s
        0x96bs
        0x990s
        0x99fs
        0x995s
        0x983s
        0x99es
        0x998s
        0x995s
        0x9dfs
        0x998s
        0x99fs
        0x985s
        0x994s
        0x99fs
        0x985s
        0x9dfs
        0x990s
        0x992s
        0x985s
        0x998s
        0x99es
        0x99fs
        0x9dfs
        0x9a7s
        0x9b8s
        0x9b4s
        0x9a6s
        0x51es
        0x53cs
        0x533s
        0x533s
        0x532s
        0x529s
        0x57ds
        0x532s
        0x52ds
        0x538s
        0x533s
        0x57ds
        0x539s
        0x532s
        0x52as
        0x533s
        0x531s
        0x532s
        0x53cs
        0x539s
        0x57ds
        0x531s
        0x534s
        0x533s
        0x536s
        0xb03s
        0xb34s
        0xb34s
        0xb29s
        0xb34s
        0xb66s
        0xb29s
        0xb36s
        0xb23s
        0xb28s
        0xb2fs
        0xb28s
        0xb21s
        0xb66s
        0xb22s
        0xb29s
        0xb31s
        0xb28s
        0xb2as
        0xb29s
        0xb27s
        0xb22s
        0xb66s
        0xb2as
        0xb2fs
        0xb28s
        0xb2ds
        0xb7cs
        0xb66s
        0x1afs
        0x199s
        0x19fs
        0x198s
        0x183s
        0x181s
        0x1b9s
        0x19cs
        0x188s
        0x18ds
        0x198s
        0x189s
        0x1a8s
        0x185s
        0x18ds
        0x180s
        0x183s
        0x18bs
        0xb6ds
        0xb5bs
        0xb5ds
        0xb5as
        0xb41s
        0xb43s
        0xb7bs
        0xb5es
        0xb4as
        0xb4fs
        0xb5as
        0xb4bs
        0xb6as
        0xb47s
        0xb4fs
        0xb42s
        0xb41s
        0xb49s
        0x1ads
        0x1b3s
        0x1b4s
        0x1bes
        0x1b5s
        0x1ads
        0x3e1s
        0x384s
        0x384s
        0x384s
        0x384s
        0x384s
        0x384s
        0x55as
        0x54bs
        0x548s
        0x54bs
        0x548s
        0x54bs
        0x548s
        0xa35s
        0xa08s
        0xa15s
        0xa0ds
        0xa04s
        0x9b6s
        0x9ads
        0x9a3s
        0x9acs
        0x9b0s
        0x9a1s
        0x9abs
        0x9b1s
        0x9b7s
        0x99bs
        0x9b6s
        0x9a1s
        0x9a3s
        0x9b1s
        0x9a8s
        0x9a5s
        0x9b6s
        0x9eas
        0x9b0s
        0x9b0s
        0x9a2s
        0x341s
        0x376s
        0x376s
        0x36bs
        0x376s
        0x324s
        0x368s
        0x36bs
        0x365s
        0x360s
        0x36ds
        0x36as
        0x363s
        0x324s
        0x367s
        0x371s
        0x377s
        0x370s
        0x36bs
        0x369s
        0x324s
        0x362s
        0x36bs
        0x36as
        0x370s
        0x33es
        0x324s
        0x6b9s
        0x6aas
        0x6aas
        0x6aas
        0x6aas
        0x6aas
        0x6aas
        0x5a2s
        0x593s
        0x593s
        0x5ads
        0x582s
        0x58es
        0x586s
        0x863s
        0x804s
        0x804s
        0x804s
        0x804s
        0x804s
        0x804s
        0x3a7s
        0x3b3s
        0x3b1s
        0x3b3s
        0x3b1s
        0x3b3s
        0x3b1s
        0x437s
        0x404s
        0x413s
        0x412s
        0x408s
        0x40es
        0x40fs
        0x441s
        0x923s
        0x930s
        0x927s
        0x926s
        0x93cs
        0x93as
        0x93bs
        0x91bs
        0x934s
        0x938s
        0x930s
        0x85ds
        0x84as
        0x843s
        0x84as
        0x84es
        0x85cs
        0x84as
        0x86bs
        0x84es
        0x85bs
        0x84as
        0xcbfs
        0xcd9s
        0xcacs
        0xcd9s
        0xcacs
        0xcd9s
        0xcacs
        0x799s
        0x78es
        0x78es
        0x78es
        0x78es
        0x78es
        0x78es
        0xafcs
        0xac2s
        0xad6s
        0x89as
        0x8a8s
        0xb60s
        0x2255s
        0x257s
        0x2271s
        0x273s
        0x273s
        0xacas
        0xadds
        0xadbs
        0xadds
        0xadbs
        0xadds
        0xadbs
        0x87cs
        0x81bs
        0x81bs
        0x81bs
        0x81bs
        0x81bs
        0x81bs
        0x59cs
        0x581s
        0x590s
        0x58ds
        0x9c1s
        0x9a7s
        0x9a7s
        0x9a7s
        0x9a7s
        0x9a7s
        0x9a7s
        0x371s
        0x374s
        0x360s
        0x365s
        0x370s
        0x361s
        0x262s
        0x273s
        0x270s
        0x278s
        0x277s
        0x207s
        0x272s
        0xbb0s
        0xbbbs
        0xba3s
        0xbbas
        0xbb8s
        0xbbbs
        0xbb5s
        0xbb0s
        0xb98s
        0xbbds
        0xbbas
        0xbbfs
        0xb1ds
        0xb3fs
        0xb2es
        0xb37s
        0xb35s
        0xb3es
        0xb2as
        0xb39s
        0xb74s
        0xb30s
        0xb2as
        0xb3ds
        0x4dcs
        0x4ebs
        0x4ebs
        0x4f6s
        0x4ebs
        0x4b9s
        0x4f5s
        0x4f6s
        0x4f8s
        0x4fds
        0x4f0s
        0x4f7s
        0x4fes
        0x4b9s
        0x4ffs
        0x4ebs
        0x4f6s
        0x4f4s
        0x4b9s
        0x4f8s
        0x4eas
        0x4eas
        0x4fcs
        0x4eds
        0x4eas
        0x4a3s
        0x4b9s
        0xca9s
        0xca3s
        0xc9fs
        0xcb5s
        0xcb0s
        0xca4s
        0xca1s
        0xcb4s
        0xca5s
        0xcf2s
        0xce4s
        0xcf7s
        0xce1s
        0xcf7s
        0xcf4s
        0xcfas
        0xcf3s
        0xb6es
        0xb59s
        0xb59s
        0xb44s
        0xb59s
        0xb0bs
        0xb47s
        0xb44s
        0xb4as
        0xb4fs
        0xb42s
        0xb45s
        0xb4cs
        0xb0bs
        0xb4ds
        0xb59s
        0xb44s
        0xb46s
        0xb0bs
        0xb4fs
        0xb59s
        0xb4as
        0xb5cs
        0xb4as
        0xb49s
        0xb47s
        0xb4es
        0xb11s
        0xb0bs
        0xb28s
        0xb1fs
        0xb1fs
        0xb02s
        0xb1fs
        0xb4ds
        0xb18s
        0xb1es
        0xb04s
        0xb03s
        0xb0as
        0xb4ds
        0xb0cs
        0xb1ds
        0xb1ds
        0xb4ds
        0xb04s
        0xb0es
        0xb02s
        0xb03s
        0xb57s
        0xb4ds
        0xb1es
        0xb29s
        0xb29s
        0xb34s
        0xb29s
        0xb7bs
        0xb28s
        0xb33s
        0xb34s
        0xb2cs
        0xb32s
        0xb35s
        0xb3cs
        0xb7bs
        0xb2es
        0xb2bs
        0xb3fs
        0xb3as
        0xb2fs
        0xb3es
        0xb7bs
        0xb3fs
        0xb32s
        0xb3as
        0xb37s
        0xb34s
        0xb3cs
        0xb61s
        0xb7bs
    .end array-data
.end method

.method public constructor <init>()V
    .registers 52

    move-object/from16 v0, p0

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public static native ccoo(Ljava/lang/Object;Ljava/lang/Object;)Landroid/os/AsyncTask;
.end method

.method private static native createTextViewButton(Landroid/content/Context;Ljava/lang/String;IIZ)Landroid/widget/TextView;
.end method

.method private static native dpToPx(Landroid/content/Context;I)I
.end method

.method public static native ecco(Ljava/lang/Object;I)I
.end method

.method public static native ecee(Ljava/lang/Object;)V
.end method

.method public static native ecoc()Ljava/lang/ref/WeakReference;
.end method

.method public static native econ()Ljava/lang/ref/WeakReference;
.end method

.method public static native eeoc(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Z
.end method

.method private static native getDarkerColor(IF)I
.end method

.method public static native handleConfigurationChanged(Landroid/content/res/Configuration;)V
.end method

.method private static native isUpdateNeeded(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)Z
.end method

.method static synthetic lambda$showUpdateDialog$0()V
    .registers 52

    invoke-static {}, Lcom/GETMODPC/A;->oncn()I

    move-result v0

    invoke-static {v0}, Lcom/GETMODPC/C;->oncc(I)V

    const/4 v0, 0x0

    invoke-static {v0}, Lcom/GETMODPC/C;->neoe(I)V

    return-void
.end method

.method static synthetic lambda$showUpdateDialog$1()V
    .registers 52

    invoke-static {}, Lcom/GETMODPC/A;->oncn()I

    move-result v0

    invoke-static {v0}, Lcom/GETMODPC/C;->oncc(I)V

    const/4 v0, 0x0

    invoke-static {v0}, Lcom/GETMODPC/C;->neoe(I)V

    return-void
.end method

.method static synthetic lambda$showUpdateDialog$2(Landroid/app/Dialog;Landroid/content/Context;Landroid/view/View;)V
    .registers 59

    move-object/from16 v7, p2

    move-object/from16 v6, p1

    move-object/from16 v5, p0

    :try_start_6
    invoke-static {v5}, Lcom/GETMODPC/C;->noeo(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_f

    invoke-static {v5}, Lcom/GETMODPC/A;->ncno(Ljava/lang/Object;)V

    :cond_f
    invoke-static {}, Lcom/GETMODPC/F;->econ()Ljava/lang/ref/WeakReference;

    move-result-object v0

    invoke-static {v0}, Lcom/GETMODPC/B;->eooc(Ljava/lang/Object;)V

    instance-of v0, v6, Landroid/app/Activity;

    const-wide/16 v1, 0xc8

    if-eqz v0, :cond_34

    move-object v0, v6

    check-cast v0, Landroid/app/Activity;

    invoke-static {v0}, Lcom/GETMODPC/B;->ooec(Ljava/lang/Object;)V

    new-instance v0, Landroid/os/Handler;

    invoke-static {}, Lcom/GETMODPC/B;->cenn()Landroid/os/Looper;

    move-result-object v3

    invoke-direct {v0, v3}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    new-instance v3, Lcom/GETMODPC/G;

    invoke-direct {v3}, Lcom/GETMODPC/G;-><init>()V

    invoke-static {v0, v3, v1, v2}, Lcom/GETMODPC/E;->ncnn(Ljava/lang/Object;Ljava/lang/Object;J)Z

    goto :goto_7c

    :cond_34
    new-instance v0, Landroid/content/Intent;

    invoke-static/range {}, Lcom/GETMODPC/F;->oeoc()[S

    move-result-object v23

    const v26, 0xa88

    const v24, 0x8c

    const v25, 0x1a

    invoke-static/range {v23 .. v26}, Lcom/GETMODPC/E;->ncce([SIII)Ljava/lang/String;

    move-result-object v23

    move-object/from16 v3, v23

    invoke-direct {v0, v3}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    invoke-static/range {}, Lcom/GETMODPC/F;->oeoc()[S

    move-result-object v14

    const v17, 0x634

    const v15, 0xa6

    const v16, 0x1c

    invoke-static/range {v14 .. v17}, Lcom/GETMODPC/C;->nncn([SIII)Ljava/lang/String;

    move-result-object v14

    move-object/from16 v3, v14

    invoke-static {v0, v3}, Lcom/GETMODPC/C;->ecoo(Ljava/lang/Object;Ljava/lang/Object;)Landroid/content/Intent;

    const v3, 0x10008000

    invoke-static {v0, v3}, Lcom/GETMODPC/B;->eene(Ljava/lang/Object;I)Landroid/content/Intent;

    invoke-static {v6, v0}, Lcom/GETMODPC/A;->onen(Ljava/lang/Object;Ljava/lang/Object;)V

    new-instance v3, Landroid/os/Handler;

    invoke-static {}, Lcom/GETMODPC/B;->cenn()Landroid/os/Looper;

    move-result-object v4

    invoke-direct {v3, v4}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    new-instance v4, Lcom/GETMODPC/I;

    invoke-direct {v4}, Lcom/GETMODPC/I;-><init>()V

    invoke-static {v3, v4, v1, v2}, Lcom/GETMODPC/E;->ncnn(Ljava/lang/Object;Ljava/lang/Object;J)Z
    :try_end_7c
    .catch Ljava/lang/Exception; {:try_start_6 .. :try_end_7c} :catch_7d

    :goto_7c
    goto :goto_c4

    :catch_7d
    move-exception v0

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-static/range {}, Lcom/GETMODPC/F;->oeoc()[S

    move-result-object v39

    const v42, 0x278

    const v40, 0xc2

    const v41, 0x13

    invoke-static/range {v39 .. v42}, Lcom/GETMODPC/C;->nncn([SIII)Ljava/lang/String;

    move-result-object v39

    move-object/from16 v2, v39

    invoke-static {v1, v2}, Lcom/GETMODPC/B;->oecc(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-static {v0}, Lcom/GETMODPC/C;->cnnn(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v2

    invoke-static {v1, v2}, Lcom/GETMODPC/B;->oecc(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-static {v1}, Lcom/GETMODPC/B;->ennc(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    invoke-static/range {}, Lcom/GETMODPC/F;->oeoc()[S

    move-result-object v34

    const v37, 0x655

    const v35, 0xd5

    const v36, 0x12

    invoke-static/range {v34 .. v37}, Lcom/GETMODPC/D;->cnec([SIII)Ljava/lang/String;

    move-result-object v34

    move-object/from16 v2, v34

    invoke-static {}, Lcom/GETMODPC/A;->oncn()I

    move-result v1

    invoke-static {v1}, Lcom/GETMODPC/C;->oncc(I)V

    const/4 v1, 0x0

    invoke-static {v1}, Lcom/GETMODPC/C;->neoe(I)V

    :goto_c4
    return-void
.end method

.method static synthetic lambda$showUpdateDialog$3(Landroid/app/Dialog;)V
    .registers 55

    move-object/from16 v3, p0

    :try_start_2
    invoke-static {v3}, Lcom/GETMODPC/C;->noeo(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_b

    invoke-static {v3}, Lcom/GETMODPC/A;->ncno(Ljava/lang/Object;)V

    :cond_b
    invoke-static {}, Lcom/GETMODPC/F;->econ()Ljava/lang/ref/WeakReference;

    move-result-object v0

    invoke-static {v0}, Lcom/GETMODPC/B;->eooc(Ljava/lang/Object;)V
    :try_end_12
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_12} :catch_13

    goto :goto_4f

    :catch_13
    move-exception v0

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-static/range {}, Lcom/GETMODPC/F;->oeoc()[S

    move-result-object v32

    const v35, 0xc0a

    const v33, 0xe7

    const v34, 0x28

    invoke-static/range {v32 .. v35}, Lcom/GETMODPC/E;->ncce([SIII)Ljava/lang/String;

    move-result-object v32

    move-object/from16 v2, v32

    invoke-static {v1, v2}, Lcom/GETMODPC/B;->oecc(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-static {v0}, Lcom/GETMODPC/C;->cnnn(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v2

    invoke-static {v1, v2}, Lcom/GETMODPC/B;->oecc(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-static {v1}, Lcom/GETMODPC/B;->ennc(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    invoke-static/range {}, Lcom/GETMODPC/F;->oeoc()[S

    move-result-object v29

    const v32, 0x90c

    const v30, 0x10f

    const v31, 0x12

    invoke-static/range {v29 .. v32}, Lcom/GETMODPC/C;->nncn([SIII)Ljava/lang/String;

    move-result-object v29

    move-object/from16 v2, v29

    :goto_4f
    return-void
.end method

.method static synthetic lambda$showUpdateDialog$4(Ljava/lang/String;Landroid/content/Context;Landroid/app/Dialog;Landroid/view/View;)V
    .registers 60

    move-object/from16 v8, p3

    move-object/from16 v7, p2

    move-object/from16 v6, p1

    move-object/from16 v5, p0

    :try_start_8
    new-instance v0, Landroid/content/Intent;

    invoke-static/range {}, Lcom/GETMODPC/F;->oeoc()[S

    move-result-object v44

    const v47, 0x9f1

    const v45, 0x121

    const v46, 0x1a

    invoke-static/range {v44 .. v47}, Lcom/GETMODPC/E;->ncce([SIII)Ljava/lang/String;

    move-result-object v44

    move-object/from16 v1, v44

    invoke-static {v5}, Lcom/GETMODPC/E;->cncn(Ljava/lang/Object;)Landroid/net/Uri;

    move-result-object v2

    invoke-direct {v0, v1, v2}, Landroid/content/Intent;-><init>(Ljava/lang/String;Landroid/net/Uri;)V

    invoke-static {v6, v0}, Lcom/GETMODPC/A;->onen(Ljava/lang/Object;Ljava/lang/Object;)V

    new-instance v1, Landroid/os/Handler;

    invoke-static {}, Lcom/GETMODPC/B;->cenn()Landroid/os/Looper;

    move-result-object v2

    invoke-direct {v1, v2}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    new-instance v2, Lcom/GETMODPC/L;

    invoke-direct {v2, v7}, Lcom/GETMODPC/L;-><init>(Landroid/app/Dialog;)V

    const-wide/16 v3, 0x320

    invoke-static {v1, v2, v3, v4}, Lcom/GETMODPC/E;->ncnn(Ljava/lang/Object;Ljava/lang/Object;J)Z
    :try_end_3a
    .catch Ljava/lang/Exception; {:try_start_8 .. :try_end_3a} :catch_3c

    nop

    goto :goto_93

    :catch_3c
    move-exception v0

    invoke-static/range {}, Lcom/GETMODPC/F;->oeoc()[S

    move-result-object v35

    const v38, 0x55d

    const v36, 0x13b

    const v37, 0x19

    invoke-static/range {v35 .. v38}, Lcom/GETMODPC/E;->ncce([SIII)Ljava/lang/String;

    move-result-object v35

    move-object/from16 v1, v35

    const/4 v2, 0x0

    invoke-static {v6, v1, v2}, Lcom/GETMODPC/C;->neeo(Ljava/lang/Object;Ljava/lang/Object;I)Landroid/widget/Toast;

    move-result-object v1

    invoke-static {v1}, Lcom/GETMODPC/C;->oceo(Ljava/lang/Object;)V

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-static/range {}, Lcom/GETMODPC/F;->oeoc()[S

    move-result-object v19

    const v22, 0xb46

    const v20, 0x154

    const v21, 0x1d

    invoke-static/range {v19 .. v22}, Lcom/GETMODPC/C;->nncn([SIII)Ljava/lang/String;

    move-result-object v19

    move-object/from16 v2, v19

    invoke-static {v1, v2}, Lcom/GETMODPC/B;->oecc(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-static {v0}, Lcom/GETMODPC/C;->cnnn(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v2

    invoke-static {v1, v2}, Lcom/GETMODPC/B;->oecc(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-static {v1}, Lcom/GETMODPC/B;->ennc(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    invoke-static/range {}, Lcom/GETMODPC/F;->oeoc()[S

    move-result-object v35

    const v38, 0x1ec

    const v36, 0x171

    const v37, 0x12

    invoke-static/range {v35 .. v38}, Lcom/GETMODPC/D;->cnec([SIII)Ljava/lang/String;

    move-result-object v35

    move-object/from16 v2, v35

    :goto_93
    return-void
.end method

.method static synthetic lambda$showUpdateDialog$5(Landroid/content/DialogInterface;)V
    .registers 53

    move-object/from16 v1, p0

    invoke-static {}, Lcom/GETMODPC/F;->econ()Ljava/lang/ref/WeakReference;

    move-result-object v0

    if-eqz v0, :cond_b

    invoke-static {v0}, Lcom/GETMODPC/B;->eooc(Ljava/lang/Object;)V

    :cond_b
    return-void
.end method

.method public static native ncoo(Ljava/lang/Object;Ljava/lang/Object;IIZ)Landroid/widget/TextView;
.end method

.method public static native neon(Ljava/lang/Object;Ljava/lang/Object;)V
.end method

.method public static native nup(Landroid/content/Context;)V
.end method

.method public static native oeoc()[S
.end method

.method public static native onoo(IF)I
.end method

.method private static native showUpdateDialog(Landroid/content/Context;Lorg/json/JSONObject;)V
.end method
