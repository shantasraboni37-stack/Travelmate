.class public final synthetic Lcom/GETMODPC/G;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# direct methods
.method static constructor <clinit>()V
    .registers 52

    const/16 v0, 0x11

    invoke-static {v0}, Lcom/GETMODPC/U;->classesInit0(I)V

    return-void
.end method

.method public synthetic constructor <init>()V
    .registers 52

    move-object/from16 v0, p0

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public static native cneo()V
.end method


# virtual methods
.method public final native run()V
.end method
