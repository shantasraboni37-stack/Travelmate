.class public final synthetic Lcom/GETMODPC/H;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/view/View$OnClickListener;


# instance fields
.field public final synthetic f$0:Ljava/lang/String;

.field public final synthetic f$1:Landroid/content/Context;

.field public final synthetic f$2:Landroid/app/Dialog;


# direct methods
.method static constructor <clinit>()V
    .registers 52

    const/16 v0, 0xe

    invoke-static {v0}, Lcom/GETMODPC/U;->classesInit0(I)V

    return-void
.end method

.method public synthetic constructor <init>(Ljava/lang/String;Landroid/content/Context;Landroid/app/Dialog;)V
    .registers 55

    move-object/from16 v3, p3

    move-object/from16 v2, p2

    move-object/from16 v1, p1

    move-object/from16 v0, p0

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    iput-object v1, v0, Lcom/GETMODPC/H;->f$0:Ljava/lang/String;

    iput-object v2, v0, Lcom/GETMODPC/H;->f$1:Landroid/content/Context;

    iput-object v3, v0, Lcom/GETMODPC/H;->f$2:Landroid/app/Dialog;

    return-void
.end method

.method public static native cncc(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V
.end method


# virtual methods
.method public final native onClick(Landroid/view/View;)V
.end method
