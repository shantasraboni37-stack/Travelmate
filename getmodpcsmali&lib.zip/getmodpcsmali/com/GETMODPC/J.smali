.class public final synthetic Lcom/GETMODPC/J;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/view/View$OnClickListener;


# instance fields
.field public final synthetic f$0:Landroid/app/Dialog;

.field public final synthetic f$1:Landroid/content/Context;


# direct methods
.method static constructor <clinit>()V
    .registers 52

    const/4 v0, 0x5

    invoke-static {v0}, Lcom/GETMODPC/U;->classesInit0(I)V

    return-void
.end method

.method public synthetic constructor <init>(Landroid/app/Dialog;Landroid/content/Context;)V
    .registers 54

    move-object/from16 v2, p2

    move-object/from16 v1, p1

    move-object/from16 v0, p0

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    iput-object v1, v0, Lcom/GETMODPC/J;->f$0:Landroid/app/Dialog;

    iput-object v2, v0, Lcom/GETMODPC/J;->f$1:Landroid/content/Context;

    return-void
.end method

.method public static native onec(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V
.end method


# virtual methods
.method public final native onClick(Landroid/view/View;)V
.end method
