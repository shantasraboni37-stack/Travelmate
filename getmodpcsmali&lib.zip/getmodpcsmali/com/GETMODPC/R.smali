.class final Lcom/GETMODPC/R;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/GETMODPC/O;->a(Landroid/content/Context;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x8
    name = null
.end annotation


# instance fields
.field final synthetic val$context:Landroid/content/Context;

.field final synthetic val$dialog:Landroid/app/Dialog;


# direct methods
.method static constructor <clinit>()V
    .registers 52

    const/4 v0, 0x2

    invoke-static {v0}, Lcom/GETMODPC/U;->classesInit0(I)V

    return-void
.end method

.method constructor <init>(Landroid/content/Context;Landroid/app/Dialog;)V
    .registers 54

    move-object/from16 v2, p2

    move-object/from16 v1, p1

    move-object/from16 v0, p0

    iput-object v1, v0, Lcom/GETMODPC/R;->val$context:Landroid/content/Context;

    iput-object v2, v0, Lcom/GETMODPC/R;->val$dialog:Landroid/app/Dialog;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public static native nccc(Ljava/lang/Object;)Landroid/content/Context;
.end method

.method public static native ncoc(Ljava/lang/Object;)Landroid/app/Dialog;
.end method


# virtual methods
.method public native onClick(Landroid/view/View;)V
.end method
