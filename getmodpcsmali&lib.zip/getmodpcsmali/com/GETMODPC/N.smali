.class Lcom/GETMODPC/N;
.super Landroid/os/AsyncTask;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/GETMODPC/F;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0xa
    name = "FetchUpdateDataTask"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Landroid/os/AsyncTask<",
        "Ljava/lang/String;",
        "Ljava/lang/Void;",
        "Ljava/lang/String;",
        ">;"
    }
.end annotation


# static fields
.field private static final short:[S


# instance fields
.field private final contextRef:Ljava/lang/ref/WeakReference;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/lang/ref/WeakReference<",
            "Landroid/content/Context;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method static constructor <clinit>()V
    .registers 52

    const/16 v0, 0x9

    invoke-static {v0}, Lcom/GETMODPC/U;->classesInit0(I)V

    const v0, 0x8f

    new-array v0, v0, [S

    fill-array-data v0, :array_10

    sput-object v0, Lcom/GETMODPC/N;->short:[S

    return-void

    :array_10
    .array-data 2
        0x307s
        0x306s
        0x344s
        0x30as
        0x308s
        0x30as
        0x301s
        0x30cs
        0x6d4s
        0x6d6s
        0x6c7s
        0x72es
        0x70cs
        0x70es
        0x705s
        0x708s
        0x740s
        0x72es
        0x702s
        0x703s
        0x719s
        0x71fs
        0x702s
        0x701s
        0x81ds
        0x83fs
        0x82cs
        0x82as
        0x820s
        0x82cs
        0x7ces
        0x7f9s
        0x7f9s
        0x7e4s
        0x7f9s
        0x7abs
        0x7eds
        0x7ees
        0x7ffs
        0x7e8s
        0x7e3s
        0x7e2s
        0x7e5s
        0x7ecs
        0x7abs
        0x7fes
        0x7fbs
        0x7efs
        0x7eas
        0x7ffs
        0x7ees
        0x7abs
        0x7efs
        0x7eas
        0x7ffs
        0x7eas
        0x7b1s
        0x7abs
        0xa2fs
        0xa19s
        0xa1fs
        0xa18s
        0xa03s
        0xa01s
        0xa39s
        0xa1cs
        0xa08s
        0xa0ds
        0xa18s
        0xa09s
        0xa28s
        0xa05s
        0xa0ds
        0xa00s
        0xa03s
        0xa0bs
        0x274s
        0x267s
        0x270s
        0x271s
        0x26bs
        0x26ds
        0x26cs
        0x241s
        0x26ds
        0x266s
        0x267s
        0x226s
        0x235s
        0x222s
        0x223s
        0x239s
        0x23fs
        0x23es
        0x21es
        0x231s
        0x23ds
        0x235s
        0x7c8s
        0x7ffs
        0x7ffs
        0x7e2s
        0x7ffs
        0x7ads
        0x7fds
        0x7ecs
        0x7ffs
        0x7fes
        0x7e4s
        0x7e3s
        0x7eas
        0x7ads
        0x7f8s
        0x7fds
        0x7e9s
        0x7ecs
        0x7f9s
        0x7e8s
        0x7ads
        0x7c7s
        0x7des
        0x7c2s
        0x7c3s
        0x7b7s
        0x7ads
        0x919s
        0x92fs
        0x929s
        0x92es
        0x935s
        0x937s
        0x90fs
        0x92as
        0x93es
        0x93bs
        0x92es
        0x93fs
        0x91es
        0x933s
        0x93bs
        0x936s
        0x935s
        0x93ds
    .end array-data
.end method

.method constructor <init>(Landroid/content/Context;)V
    .registers 54

    move-object/from16 v2, p1

    move-object/from16 v1, p0

    invoke-direct {v1}, Landroid/os/AsyncTask;-><init>()V

    new-instance v0, Ljava/lang/ref/WeakReference;

    invoke-direct {v0, v2}, Ljava/lang/ref/WeakReference;-><init>(Ljava/lang/Object;)V

    iput-object v0, v1, Lcom/GETMODPC/N;->contextRef:Ljava/lang/ref/WeakReference;

    return-void
.end method

.method public static native cceo(Ljava/lang/Object;Ljava/lang/Object;)V
.end method

.method public static native cnne(Ljava/lang/Object;Ljava/lang/Object;)V
.end method

.method public static native ncoe(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Z
.end method

.method public static native noee()[S
.end method

.method public static native ocee(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/String;
.end method

.method public static native oncn(Ljava/lang/Object;)Ljava/lang/ref/WeakReference;
.end method


# virtual methods
.method protected bridge synthetic doInBackground([Ljava/lang/Object;)Ljava/lang/Object;
    .registers 53

    move-object/from16 v1, p1

    move-object/from16 v0, p0

    check-cast v1, [Ljava/lang/String;

    invoke-static {v0, v1}, Lcom/GETMODPC/N;->ocee(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    return-object v1
.end method

.method protected varargs native doInBackground([Ljava/lang/String;)Ljava/lang/String;
.end method

.method protected bridge synthetic onPostExecute(Ljava/lang/Object;)V
    .registers 53

    move-object/from16 v1, p1

    move-object/from16 v0, p0

    check-cast v1, Ljava/lang/String;

    invoke-static {v0, v1}, Lcom/GETMODPC/N;->cceo(Ljava/lang/Object;Ljava/lang/Object;)V

    return-void
.end method

.method protected native onPostExecute(Ljava/lang/String;)V
.end method
