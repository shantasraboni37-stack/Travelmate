.class public final synthetic Lcom/GETMODPC/L;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic f$0:Landroid/app/Dialog;


# direct methods
.method static constructor <clinit>()V
    .registers 52

    const/4 v0, 0x3

    invoke-static {v0}, Lcom/GETMODPC/U;->classesInit0(I)V

    return-void
.end method

.method public synthetic constructor <init>(Landroid/app/Dialog;)V
    .registers 53

    move-object/from16 v1, p1

    move-object/from16 v0, p0

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    iput-object v1, v0, Lcom/GETMODPC/L;->f$0:Landroid/app/Dialog;

    return-void
.end method

.method public static native eonn(Ljava/lang/Object;)V
.end method


# virtual methods
.method public final native run()V
.end method
