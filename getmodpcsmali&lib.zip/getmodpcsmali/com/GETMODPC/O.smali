.class public Lcom/GETMODPC/O;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/GETMODPC/T;
    }
.end annotation


# static fields
.field static close_id:I

.field static image_id:I

.field static link_id:I

.field static settings:Ljava/lang/String;

.field private static final short:[S

.field static toast:Ljava/lang/String;


# direct methods
.method static constructor <clinit>()V
    .registers 52

    const/16 v0, 0xa

    invoke-static {v0}, Lcom/GETMODPC/U;->classesInit0(I)V

    const v0, 0x1f8

    new-array v0, v0, [S

    fill-array-data v0, :array_4a

    sput-object v0, Lcom/GETMODPC/O;->short:[S

    const/16 v0, 0x258

    sput v0, Lcom/GETMODPC/O;->close_id:I

    invoke-static/range {}, Lcom/GETMODPC/O;->neon()[S

    move-result-object v27

    const v30, 0x94d

    const v28, 0x0

    const v29, 0x1c

    invoke-static/range {v27 .. v30}, Lcom/GETMODPC/C;->nncn([SIII)Ljava/lang/String;

    move-result-object v27

    move-object/from16 v0, v27

    sput-object v0, Lcom/GETMODPC/O;->settings:Ljava/lang/String;

    invoke-static/range {}, Lcom/GETMODPC/O;->neon()[S

    move-result-object v12

    const v15, 0x166

    const v13, 0x1c

    const v14, 0x10

    invoke-static/range {v12 .. v15}, Lcom/GETMODPC/D;->cnec([SIII)Ljava/lang/String;

    move-result-object v12

    move-object/from16 v0, v12

    invoke-static {v0}, Lcom/GETMODPC/A;->eeen(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    sput-object v0, Lcom/GETMODPC/O;->toast:Ljava/lang/String;

    const/16 v0, 0x1f4

    sput v0, Lcom/GETMODPC/O;->link_id:I

    const/16 v0, 0xc8

    sput v0, Lcom/GETMODPC/O;->image_id:I

    return-void

    :array_4a
    .array-data 2
        0x976s
        0x92es
        0x925s
        0x928s
        0x939s
        0x92es
        0x925s
        0x924s
        0x92es
        0x926s
        0x977s
        0x97cs
        0x976s
        0x919s
        0x925s
        0x928s
        0x920s
        0x928s
        0x977s
        0x97fs
        0x976s
        0x919s
        0x922s
        0x92cs
        0x93es
        0x939s
        0x977s
        0x97ds
        0x137s
        0x123s
        0x102s
        0x10as
        0x102s
        0x121s
        0x157s
        0x110s
        0x13cs
        0x12es
        0x124s
        0x10cs
        0x105s
        0x111s
        0x15bs
        0x15bs
        0x114s
        0x109s
        0x118s
        0x123s
        0x3c1s
        0x3c0s
        0x3c8s
        0x7fbs
        0x7efs
        0x7f6s
        0x7ees
        0x7b4s
        0x7f9s
        0x700s
        0x70fs
        0x714s
        0x715s
        0x712s
        0x7fes
        0x7e1s
        0x7eds
        0x7ffs
        0xb9fs
        0xbeds
        0xb95s
        0xbffs
        0xbc9s
        0xbc1s
        0xbe4s
        0xbc3s
        0xbcbs
        0xb91s
        0xbebs
        0xbd0s
        0xbc9s
        0xbfds
        0xbc2s
        0xbc4s
        0xb9fs
        0xbeds
        0xb95s
        0xbffs
        0xbc8s
        0xbf6s
        0xb9as
        0xb9as
        0xc9s
        0xe4s
        0xebs
        0xeas
        0xe8s
        0xe9s
        0xecs
        0x96s
        0x98s
        0x4f4s
        0xebs
        0xeas
        0xe3s
        0xe2s
        0xe1s
        0x910s
        0x972s
        0x914s
        0x917s
        0x916s
        0x917s
        0x97bs
        0x907s
        0x917s
        0x907s
        0x90fs
        0x97fs
        0xa35s
        0xa34s
        0xa39s
        0xa38s
        0x64bs
        0x644s
        0x65fs
        0x65es
        0x659s
        0x672s
        0x65fs
        0x658s
        0x643s
        0xc16s
        0xc19s
        0xc02s
        0xc03s
        0xc04s
        0xc2fs
        0xc02s
        0xc05s
        0xc1es
        0xbd2s
        0xbdds
        0xbc6s
        0xbc7s
        0xbc0s
        0xbebs
        0xbc6s
        0xbc1s
        0xbdas
        0xbbas
        0xbb5s
        0xbaes
        0xbafs
        0xba8s
        0xadds
        0xac2s
        0xaces
        0xadcs
        0x43cs
        0x44es
        0x436s
        0x45cs
        0x46as
        0x462s
        0x447s
        0x460s
        0x468s
        0x432s
        0x448s
        0x473s
        0x46as
        0x45es
        0x461s
        0x467s
        0x43cs
        0x44es
        0x436s
        0x45cs
        0x46bs
        0x455s
        0x439s
        0x439s
        0xa08s
        0xa07s
        0xa1cs
        0xa1ds
        0xa1as
        0x312s
        0x30ds
        0x301s
        0x313s
        0xa99s
        0xa8fs
        0xa89s
        0xa85s
        0xa84s
        0xa8es
        0x6aes
        0x6b1s
        0x6bds
        0x6afs
        0xc02s
        0xc70s
        0xc08s
        0xc62s
        0xc54s
        0xc5cs
        0xc79s
        0xc5es
        0xc56s
        0xc0cs
        0xc76s
        0xc4ds
        0xc54s
        0xc60s
        0xc5fs
        0xc59s
        0xc02s
        0xc70s
        0xc08s
        0xc62s
        0xc55s
        0xc6bs
        0xc07s
        0xc07s
        0x1f6s
        0x1f9s
        0x1e2s
        0x1e3s
        0x1e4s
        0x44as
        0x455s
        0x459s
        0x44bs
        0xbfas
        0xbecs
        0xbeas
        0xbe6s
        0xbe7s
        0xbeds
        0xc15s
        0xc0as
        0xc06s
        0xc14s
        0x249s
        0x23bs
        0x243s
        0x229s
        0x21fs
        0x217s
        0x232s
        0x215s
        0x21ds
        0x247s
        0x23ds
        0x206s
        0x21fs
        0x22bs
        0x214s
        0x212s
        0x249s
        0x23bs
        0x243s
        0x229s
        0x21es
        0x220s
        0x24cs
        0x24cs
        0x3e3s
        0x3ecs
        0x3f7s
        0x3f6s
        0x3f1s
        0xbb9s
        0xba6s
        0xbaas
        0xbb8s
        0x2d6s
        0x2a4s
        0x2dcs
        0x2b6s
        0x280s
        0x288s
        0x2ads
        0x28as
        0x282s
        0x2d8s
        0x2a2s
        0x299s
        0x280s
        0x2b4s
        0x28bs
        0x28ds
        0x2d6s
        0x2a4s
        0x2dcs
        0x2b6s
        0x281s
        0x2bfs
        0x2d3s
        0x2d3s
        0x702s
        0x760s
        0x706s
        0x705s
        0x704s
        0x705s
        0x769s
        0x715s
        0x705s
        0x715s
        0x71ds
        0x76ds
        0xb48s
        0xb49s
        0xb44s
        0xb45s
        0x9ecs
        0x9fas
        0x9fcs
        0x9f0s
        0x9f1s
        0x9fbs
        0x9c0s
        0x9eds
        0x9eas
        0x9f1s
        0xbbcs
        0xbaas
        0xbacs
        0xba0s
        0xba1s
        0xbabs
        0xb90s
        0xbbds
        0xbbas
        0xba1s
        0xcd1s
        0xcc7s
        0xcc1s
        0xccds
        0xcccs
        0xcc6s
        0xcfds
        0xcd0s
        0xcd7s
        0xcccs
        0x994s
        0x9f6s
        0x990s
        0x993s
        0x992s
        0x993s
        0x9ffs
        0x983s
        0x993s
        0x983s
        0x98bs
        0x9fbs
        0x530s
        0x531s
        0x53cs
        0x53ds
        0x190s
        0x186s
        0x180s
        0x18cs
        0x18ds
        0x187s
        0x1bcs
        0x191s
        0x196s
        0x18ds
        0xc7bs
        0xc6ds
        0xc6bs
        0xc67s
        0xc66s
        0xc6cs
        0xc57s
        0xc7as
        0xc7ds
        0xc66s
        0x1ffs
        0x1e9s
        0x1efs
        0x1e3s
        0x1e2s
        0x1e8s
        0x1d3s
        0x1fes
        0x1f9s
        0x1e2s
        0x9d4s
        0x9cbs
        0x9c7s
        0x9d5s
        0xcd9s
        0xcdfs
        0xcc8s
        0xcd9s
        0xcc9s
        0xcd8s
        0xcc3s
        0xcc8s
        0xccfs
        0x5b4s
        0x5bbs
        0x5a0s
        0x5a1s
        0x5a6s
        0x58ds
        0x5bfs
        0x247s
        0x258s
        0x254s
        0x246s
        0xb4es
        0xb3cs
        0xb44s
        0xb2es
        0xb18s
        0xb10s
        0xb35s
        0xb12s
        0xb1as
        0xb40s
        0xb3as
        0xb01s
        0xb18s
        0xb2cs
        0xb13s
        0xb15s
        0xb4es
        0xb3cs
        0xb44s
        0xb2es
        0xb19s
        0xb27s
        0xb4bs
        0xb4bs
        0x615s
        0x63as
        0x639s
        0x625s
        0x633s
        0x849s
        0x846s
        0x845s
        0x859s
        0x84fs
        0x875s
        0x848s
        0x85fs
        0x85es
        0x85es
        0x845s
        0x844s
        0x875s
        0x85es
        0x84fs
        0x852s
        0x85es
        0x1c0s
        0x1c7s
        0x1c1s
        0x1das
        0x1dds
        0x1d4s
        0x8acs
        0x8a3s
        0x8a9s
        0x8bfs
        0x8a2s
        0x8a4s
        0x8a9s
        0x46cs
        0x46es
        0x461s
        0x46cs
        0x46as
        0x463s
        0x6a8s
        0x6afs
        0x6a9s
        0x6b2s
        0x6b5s
        0x6bcs
        0x336s
        0x339s
        0x333s
        0x325s
        0x338s
        0x33es
        0x333s
        0x149s
        0xba1s
        0x510s
        0x50ds
        0x526s
        0x522s
        0x528s
        0x50ds
        0x573s
        0x524s
    .end array-data
.end method

.method public constructor <init>()V
    .registers 52

    move-object/from16 v0, p0

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method private static native a(Landroid/content/Context;)Landroid/graphics/drawable/Drawable;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation
.end method

.method public static native a(Landroid/content/Context;)V
.end method

.method public static native a(Landroid/content/Context;)Z
.end method

.method public static native a$1(Landroid/content/Context;)V
.end method

.method public static native a$2(Landroid/content/Context;)V
.end method

.method public static native a$3(Landroid/content/Context;)V
.end method

.method public static native a$4(Landroid/content/Context;)V
.end method

.method static synthetic access$000(Landroid/content/Context;)V
    .registers 56

    move-object/from16 v4, p0

    invoke-static {v4}, Lcom/GETMODPC/O;->ocon(Ljava/lang/Object;)V

    return-void
.end method

.method static synthetic access$0001(Landroid/content/Context;)V
    .registers 52

    move-object/from16 v0, p0

    invoke-static {v0}, Lcom/GETMODPC/O;->onco(Ljava/lang/Object;)V

    return-void
.end method

.method public static native b(Landroid/content/Context;)Z
.end method

.method public static native ba(Landroid/content/Context;)Z
.end method

.method public static native byte(Ljava/lang/String;)Ljava/lang/String;
.end method

.method private static native chetchik(Landroid/content/Context;)V
.end method

.method private static native chetchik$1(Landroid/content/Context;)V
.end method

.method public static native cnon()I
.end method

.method public static native dia(Landroid/content/Context;)V
.end method

.method public static native ecco(I)Ljava/lang/String;
.end method

.method public static native ence()I
.end method

.method public static native ennc(Ljava/lang/Object;)Landroid/graphics/drawable/Drawable;
.end method

.method private static native getCloseText(Landroid/content/Context;)Ljava/lang/String;
.end method

.method private static native i(I)I
.end method

.method public static native lay()I
.end method

.method public static native nenn(I)I
.end method

.method public static native neon()[S
.end method

.method public static native nnce()Ljava/lang/String;
.end method

.method public static native ocon(Ljava/lang/Object;)V
.end method

.method public static native ocoo()Ljava/lang/String;
.end method

.method public static native oene(Ljava/lang/Object;)Ljava/lang/String;
.end method

.method public static native onco(Ljava/lang/Object;)V
.end method

.method public static native onnn()I
.end method

.method private static native s(I)Ljava/lang/String;
.end method

.method public static native sp(Landroid/content/Context;)Landroid/content/SharedPreferences;
.end method
