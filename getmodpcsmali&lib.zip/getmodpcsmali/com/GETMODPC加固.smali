.class public Lcom/GETMODPC加固;
.super Landroid/app/Application;


# direct methods
.method static constructor <clinit>()V
    .registers 4

    const-string v0, "MIIC5zCCAc+gAwIBAgIEGucrjDANBgkqhkiG9w0BAQsFADAkMRIwEAYDVQQKEwlieXRlZGFuY2UxDjAMBgNVBAMTBWxlbW9uMB4XDTE5MDUwNzEyMzUyOFoXDTQ0MDQzMDEyMzUyOFowJDESMBAGA1UEChMJYnl0ZWRhbmNlMQ4wDAYDVQQDEwVsZW1vbjCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBAJCIJ30nX2SHJMxMBXaRSVDV/OpCogn/0csnoNnbrjOETxs8eJkra6KtyvYQErO4RD6Wil7qZJfIAzIf6oZE6zJHeZRUSoKX03SaBNzf9uYK7xnRcdnhOaveVrCW2eFtAxPu0Gk306fvMkg1yCDt141ZfFkCXrVBq7c1PFwmBuOfb9nJxDnNgoqxGA2/Gz+JnVKSeyNqP25Bhrgr2SXdFBf2XU78J0RffhRLMRREE8d6RFgacR7YfLixaDJ/UHKxoYV2qcyzzzeLatesiO29xpW73dnuj2oJ2ibWad0wpM5GMQEYresXnKVI3YKqxkMU47gEAgh4K4nj86KaKK8H19MCAwEAAaMhMB8wHQYDVR0OBBYEFOXc8LnQAa6zT+eveTV5ow0f9mXkMA0GCSqGSIb3DQEBCwUAA4IBAQBSW3CmnqDAJpafqZj4FnVa16yE1sEDuVFIKLAyF2s0nbArv9W4ImD4DySi509xd3H3Kvz60OHWlmaCqb0wjv1fpTLDWN+1GBjTai/sy+tX0EviFWsFWs60PldNtz/VxmPFfDCSIFCEQRhLriCPD1MD+BiFO217d4vBDfcJEQPpLZK7/8jTxuTczq5eLe1DRS0GZy9SwL9T997rftrLkIe0jLLQwUphIQe8dXJmXwIzY5qNTb2hLzrq/z0TUAvd09v0ZVvAjgoiwWWjZxr0i7C6y9tU/dDgf2C2BfGeTIyXyZXlcm+rb+vSAadjuoDHQT+/04mKef2GRRgL0oED2W7R"

    const-string v1, "com.lemon.lvoverseas"

    invoke-static {v1, v0}, Lcom/GETMODPC加固;->c(Ljava/lang/String;Ljava/lang/String;)V

    invoke-static {}, LPunisher/Interceptor;->f()V

    return-void
.end method

.method public constructor <init>()V
    .registers 1

    invoke-direct {p0}, Landroid/app/Application;-><init>()V

    return-void
.end method

.method public static a(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/reflect/Field;
    .registers 5

    const/4 v0, 0x1

    :try_start_1
    invoke-virtual {p0, p1}, Ljava/lang/Class;->getDeclaredField(Ljava/lang/String;)Ljava/lang/reflect/Field;

    move-result-object v1

    invoke-virtual {v1, v0}, Ljava/lang/reflect/AccessibleObject;->setAccessible(Z)V
    :try_end_8
    .catch Ljava/lang/NoSuchFieldException; {:try_start_1 .. :try_end_8} :catch_9

    return-object v1

    :catch_9
    move-exception v1

    :goto_a
    invoke-virtual {p0}, Ljava/lang/Class;->getSuperclass()Ljava/lang/Class;

    move-result-object p0

    if-eqz p0, :cond_22

    const-class v2, Ljava/lang/Object;

    invoke-virtual {p0, v2}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-nez v2, :cond_22

    :try_start_18
    invoke-virtual {p0, p1}, Ljava/lang/Class;->getDeclaredField(Ljava/lang/String;)Ljava/lang/reflect/Field;

    move-result-object v2

    invoke-virtual {v2, v0}, Ljava/lang/reflect/AccessibleObject;->setAccessible(Z)V
    :try_end_1f
    .catch Ljava/lang/NoSuchFieldException; {:try_start_18 .. :try_end_1f} :catch_20

    return-object v2

    :catch_20
    nop

    goto :goto_a

    :cond_22
    throw v1
.end method

.method public static b(Ljava/lang/String;Ljava/lang/String;)Z
    .registers 14

    const-string v0, "/"

    invoke-virtual {p1, v0}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v1

    const/4 v2, 0x0

    if-eqz v1, :cond_bb

    const-string v1, ".apk"

    invoke-virtual {p1, v1}, Ljava/lang/String;->endsWith(Ljava/lang/String;)Z

    move-result v1

    if-nez v1, :cond_13

    goto/16 :goto_bb

    :cond_13
    const/4 v1, 0x1

    invoke-virtual {p1, v1}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x6

    invoke-virtual {p1, v0, v3}, Ljava/lang/String;->split(Ljava/lang/String;I)[Ljava/lang/String;

    move-result-object p1

    array-length v0, p1

    const-string v4, "base.apk"

    const-string v5, "mnt"

    const-string v6, "data"

    const/4 v7, 0x4

    const/4 v8, 0x2

    const-string v9, "app"

    if-eq v0, v7, :cond_73

    const/4 v10, 0x5

    if-ne v0, v10, :cond_2e

    goto :goto_73

    :cond_2e
    const/4 v11, 0x3

    if-ne v0, v11, :cond_48

    aget-object v0, p1, v2

    invoke-virtual {v0, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_bb

    aget-object v0, p1, v1

    invoke-virtual {v0, v9}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_bb

    aget-object p1, p1, v8

    invoke-virtual {p1, p0}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result p0

    return p0

    :cond_48
    if-ne v0, v3, :cond_bb

    aget-object v0, p1, v2

    invoke-virtual {v0, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_bb

    aget-object v0, p1, v1

    const-string v1, "expand"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_bb

    aget-object v0, p1, v11

    invoke-virtual {v0, v9}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_bb

    aget-object v0, p1, v10

    invoke-virtual {v0, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_bb

    aget-object p1, p1, v7

    invoke-virtual {p1, p0}, Ljava/lang/String;->endsWith(Ljava/lang/String;)Z

    move-result p0

    return p0

    :cond_73
    :goto_73
    aget-object v3, p1, v2

    invoke-virtual {v3, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_95

    aget-object v3, p1, v1

    invoke-virtual {v3, v9}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_95

    add-int/lit8 v3, v0, -0x1

    aget-object v3, p1, v3

    invoke-virtual {v3, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_95

    sub-int/2addr v0, v8

    aget-object p1, p1, v0

    invoke-virtual {p1, p0}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result p0

    return p0

    :cond_95
    aget-object v3, p1, v2

    invoke-virtual {v3, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_bb

    aget-object v1, p1, v1

    const-string v3, "asec"

    invoke-virtual {v1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_bb

    add-int/lit8 v1, v0, -0x1

    aget-object v1, p1, v1

    const-string v3, "pkg.apk"

    invoke-virtual {v1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_bb

    sub-int/2addr v0, v8

    aget-object p1, p1, v0

    invoke-virtual {p1, p0}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result p0

    return p0

    :cond_bb
    :goto_bb
    return v2
.end method

.method private static c(Ljava/lang/String;Ljava/lang/String;)V
    .registers 5

    const-class v0, Landroid/os/Parcel;

    new-instance v1, Landroid/content/pm/Signature;

    const/4 v2, 0x2

    invoke-static {p1, v2}, Landroid/util/Base64;->decode(Ljava/lang/String;I)[B

    move-result-object p1

    const/4 v2, 0x0

    invoke-direct {v1, p1}, Landroid/content/pm/Signature;-><init>([B)V

    sget-object p1, Landroid/content/pm/PackageInfo;->CREATOR:Landroid/os/Parcelable$Creator;

    new-instance v2, Lcom/GETMODPC加固$l;

    invoke-direct {v2, p1, p0, v1}, Lcom/GETMODPC加固$l;-><init>(Landroid/os/Parcelable$Creator;Ljava/lang/String;Landroid/content/pm/Signature;)V

    :try_start_14
    const-class p0, Landroid/content/pm/PackageInfo;

    const-string p1, "CREATOR"

    invoke-static {p0, p1}, Lcom/GETMODPC加固;->a(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/reflect/Field;

    move-result-object p0

    const/4 p1, 0x0

    invoke-virtual {p0, p1, v2}, Ljava/lang/reflect/Field;->set(Ljava/lang/Object;Ljava/lang/Object;)V
    :try_end_20
    .catch Ljava/lang/Exception; {:try_start_14 .. :try_end_20} :catch_7d

    sget p0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v1, 0x1c

    if-lt p0, v1, :cond_45

    const-string p0, "Landroid/app"

    const-string v1, "Landroid/os/Parcel;"

    const-string v2, "Landroid/content/pm"

    filled-new-array {v1, v2, p0}, [Ljava/lang/String;

    move-result-object p0

    sget-object v1, Lcom/GETMODPC加固$j;->f:Ljava/util/HashSet;

    invoke-static {p0}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    move-result-object p0

    invoke-interface {v1, p0}, Ljava/util/Set;->addAll(Ljava/util/Collection;)Z

    invoke-virtual {v1}, Ljava/util/HashSet;->size()I

    move-result p0

    new-array p0, p0, [Ljava/lang/String;

    invoke-virtual {v1, p0}, Ljava/util/HashSet;->toArray([Ljava/lang/Object;)[Ljava/lang/Object;

    invoke-static {p0}, Lcom/GETMODPC加固$j;->b([Ljava/lang/String;)Z

    :cond_45
    :try_start_45
    const-class p0, Landroid/content/pm/PackageManager;

    const-string v1, "sPackageInfoCache"

    invoke-static {p0, v1}, Lcom/GETMODPC加固;->a(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/reflect/Field;

    move-result-object p0

    invoke-virtual {p0, p1}, Ljava/lang/reflect/Field;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v1

    const-string v2, "clear"

    invoke-virtual {v1, v2, p1}, Ljava/lang/Class;->getMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v1

    invoke-virtual {v1, p0, p1}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_5e
    .catchall {:try_start_45 .. :try_end_5e} :catchall_5e

    :catchall_5e
    :try_start_5e
    const-string p0, "mCreators"

    invoke-static {v0, p0}, Lcom/GETMODPC加固;->a(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/reflect/Field;

    move-result-object p0

    invoke-virtual {p0, p1}, Ljava/lang/reflect/Field;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ljava/util/Map;

    invoke-interface {p0}, Ljava/util/Map;->clear()V
    :try_end_6d
    .catchall {:try_start_5e .. :try_end_6d} :catchall_6d

    :catchall_6d
    :try_start_6d
    const-string p0, "sPairedCreators"

    invoke-static {v0, p0}, Lcom/GETMODPC加固;->a(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/reflect/Field;

    move-result-object p0

    invoke-virtual {p0, p1}, Ljava/lang/reflect/Field;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ljava/util/Map;

    invoke-interface {p0}, Ljava/util/Map;->clear()V
    :try_end_7c
    .catchall {:try_start_6d .. :try_end_7c} :catchall_7c

    :catchall_7c
    return-void

    :catch_7d
    move-exception p0

    new-instance p1, Ljava/lang/RuntimeException;

    invoke-direct {p1, p0}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/Throwable;)V

    throw p1
.end method
