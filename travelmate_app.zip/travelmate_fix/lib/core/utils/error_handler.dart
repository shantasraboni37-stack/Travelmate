import 'package:flutter/material.dart';
import 'api_client.dart';

/// Show user-friendly error message
void showErrorSnack(BuildContext context, dynamic error) {
  String message;
  if (error is ApiException) {
    switch (error.statusCode) {
      case 0:
        message = 'No internet connection. Please check your network.';
        break;
      case 401:
        message = 'Session expired. Please login again.';
        break;
      case 403:
        message = 'You don\'t have permission for this action.';
        break;
      case 404:
        message = 'Resource not found.';
        break;
      case 500:
        message = 'Server error. Please try again later.';
        break;
      default:
        message = error.message;
    }
  } else if (error is Exception) {
    message = error.toString().replaceAll('Exception: ', '');
  } else {
    message = error.toString();
  }

  ScaffoldMessenger.of(context).showSnackBar(
    SnackBar(
      content: Row(
        children: [
          const Icon(Icons.error_outline, color: Colors.white),
          const SizedBox(width: 12),
          Expanded(child: Text(message)),
        ],
      ),
      backgroundColor: const Color(0xFFBA1A1A),
      behavior: SnackBarBehavior.floating,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      duration: const Duration(seconds: 4),
      action: SnackBarAction(
        label: 'DISMISS',
        textColor: Colors.white,
        onPressed: () {},
      ),
    ),
  );
}

/// Show success message
void showSuccessSnack(BuildContext context, String message) {
  ScaffoldMessenger.of(context).showSnackBar(
    SnackBar(
      content: Row(
        children: [
          const Icon(Icons.check_circle_outline, color: Colors.white),
          const SizedBox(width: 12),
          Expanded(child: Text(message)),
        ],
      ),
      backgroundColor: Colors.green,
      behavior: SnackBarBehavior.floating,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      duration: const Duration(seconds: 2),
    ),
  );
}

/// Wrap any async operation with error handling
Future<T?> safeAsync<T>({
  required BuildContext context,
  required Future<T> Function() operation,
  String? loadingMessage,
  VoidCallback? onSuccess,
}) async {
  try {
    final result = await operation();
    onSuccess?.call();
    return result;
  } catch (e) {
    showErrorSnack(context, e);
    return null;
  }
}
