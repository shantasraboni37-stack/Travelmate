import 'package:flutter/material.dart';
import 'package:permission_handler/permission_handler.dart';

class PermissionHelper {
  static Future<bool> requestWithExplanation({
    required BuildContext context,
    required Permission permission,
    required String title,
    required String reason,
    required String icon,
  }) async {
    final status = await permission.status;
    if (status.isGranted) return true;
    if (status.isPermanentlyDenied) {
      await openAppSettings();
      return false;
    }

    final confirmed = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        title: Row(children: [
          Text(icon, style: const TextStyle(fontSize: 24)),
          const SizedBox(width: 10),
          Text(title, style: const TextStyle(fontWeight: FontWeight.w800)),
        ]),
        content: Text(reason, style: const TextStyle(height: 1.5)),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx, false),
            child: const Text('Not Now'),
          ),
          ElevatedButton(
            onPressed: () => Navigator.pop(ctx, true),
            child: const Text('Allow'),
          ),
        ],
      ),
    );

    if (confirmed != true) return false;
    final result = await permission.request();
    return result.isGranted;
  }

  static Future<bool> requestCamera(BuildContext context) =>
      requestWithExplanation(
        context: context,
        permission: Permission.camera,
        title: 'Camera Access',
        icon: '\ud83d\udcf7',
        reason: 'TravelMate needs your camera to capture profile photos and share travel moments.',
      );

  static Future<bool> requestLocation(BuildContext context) =>
      requestWithExplanation(
        context: context,
        permission: Permission.locationWhenInUse,
        title: 'Location Access',
        icon: '\ud83d\udccd',
        reason: 'TravelMate uses your location to show nearby travel buddies and rank relevant posts.',
      );

  static Future<bool> requestMicrophone(BuildContext context) =>
      requestWithExplanation(
        context: context,
        permission: Permission.microphone,
        title: 'Microphone Access',
        icon: '\ud83c\udfa4',
        reason: 'TravelMate needs your microphone for audio and video calls.',
      );

  static Future<bool> requestPhotos(BuildContext context) =>
      requestWithExplanation(
        context: context,
        permission: Permission.photos,
        title: 'Photo Library',
        icon: '\ud83d\uddbc\ufe0f',
        reason: 'TravelMate needs access to your photos for profile pictures and sharing.',
      );

  static Future<bool> requestNotifications(BuildContext context) =>
      requestWithExplanation(
        context: context,
        permission: Permission.notification,
        title: 'Notifications',
        icon: '\ud83d\udd14',
        reason: 'Get notified when buddies message you or react to your posts.',
      );

  static Future<bool> requestStorage(BuildContext context) =>
      requestWithExplanation(
        context: context,
        permission: Permission.storage,
        title: 'Storage Access',
        icon: '\ud83d\udcbe',
        reason: 'TravelMate needs storage access to save media and files.',
      );
}
