import 'package:cloud_firestore/cloud_firestore.dart';
import '../../models/post.dart';

/// Repository for post CRUD operations
class PostRepository {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  /// Stream of buddy finder posts
  Stream<List<Post>> getBuddyFinderPosts() {
    return _firestore
        .collection('posts')
        .where('postType', isEqualTo: 'buddy_finder')
        .orderBy('createdAt', descending: true)
        .snapshots()
        .map((snapshot) => snapshot.docs
            .map((d) => Post.fromMap(d.data() as Map<String, dynamic>))
            .toList());
  }

  /// Stream of community posts
  Stream<List<Post>> getCommunityPosts() {
    return _firestore
        .collection('posts')
        .where('postType', isEqualTo: 'community')
        .orderBy('createdAt', descending: true)
        .snapshots()
        .map((snapshot) => snapshot.docs
            .map((d) => Post.fromMap(d.data() as Map<String, dynamic>))
            .toList());
  }

  /// Create a new post
  Future<String> createPost(Post post) async {
    final docRef = _firestore.collection('posts').doc();
    final data = post.toMap();
    data['postId'] = docRef.id;
    data['createdAt'] = FieldValue.serverTimestamp();
    await docRef.set(data);
    return docRef.id;
  }

  /// Toggle like reaction
  Future<void> toggleLike(String postId, String userId) async {
    final likeRef = _firestore
        .collection('posts')
        .doc(postId)
        .collection('reactions')
        .doc(userId);

    final doc = await likeRef.get();
    if (doc.exists) {
      await likeRef.delete();
      await _firestore.collection('posts').doc(postId).update({
        'reactionsCount.like': FieldValue.increment(-1),
      });
    } else {
      await likeRef.set({
        'type': 'like',
        'userId': userId,
        'createdAt': FieldValue.serverTimestamp(),
      });
      await _firestore.collection('posts').doc(postId).update({
        'reactionsCount.like': FieldValue.increment(1),
      });
    }
  }

  /// Delete a post (author only)
  Future<void> deletePost(String postId) async {
    await _firestore.collection('posts').doc(postId).delete();
  }
}
