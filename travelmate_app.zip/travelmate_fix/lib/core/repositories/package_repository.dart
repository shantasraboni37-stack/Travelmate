import 'package:cloud_firestore/cloud_firestore.dart';
import '../../models/package.dart';

class PackageRepository {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  Stream<List<Package>> getPackages() {
    return _firestore
        .collection('packages')
        .orderBy('createdAt', descending: true)
        .snapshots()
        .map((snapshot) => snapshot.docs
            .map((d) => Package.fromMap(d.data() as Map<String, dynamic>))
            .toList());
  }

  Future<Package?> getPackageById(String packageId) async {
    final doc = await _firestore.collection('packages').doc(packageId).get();
    if (!doc.exists) return null;
    return Package.fromMap(doc.data() as Map<String, dynamic>);
  }

  Stream<Package?> getPackageStream(String packageId) {
    return _firestore
        .collection('packages')
        .doc(packageId)
        .snapshots()
        .map((doc) =>
            doc.exists ? Package.fromMap(doc.data() as Map<String, dynamic>) : null);
  }
}
