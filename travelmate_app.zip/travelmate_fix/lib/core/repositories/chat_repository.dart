import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_database/firebase_database.dart';
import '../../models/chat.dart';

/// Repository for chat operations
class ChatRepository {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  final FirebaseDatabase _rtdb = FirebaseDatabase.instance;

  /// Stream of user's chats
  Stream<List<Chat>> getUserChats(String userId) {
    return _firestore
        .collection('chats')
        .where('members', arrayContains: userId)
        .orderBy('lastMessageTime', descending: true)
        .snapshots()
        .map((snapshot) => snapshot.docs
            .map((d) => Chat.fromMap(d.data() as Map<String, dynamic>))
            .toList());
  }

  /// Stream of messages in a chat
  Stream<List<Message>> getChatMessages(String chatId) {
    return _firestore
        .collection('chats')
        .doc(chatId)
        .collection('messages')
        .orderBy('createdAt', descending: true)
        .snapshots()
        .map((snapshot) => snapshot.docs
            .map((d) => Message.fromMap(d.data() as Map<String, dynamic>))
            .toList());
  }

  /// Send a message
  Future<void> sendMessage({
    required String chatId,
    required String senderId,
    required String content,
    String type = 'text',
  }) async {
    final msgRef = _firestore
        .collection('chats')
        .doc(chatId)
        .collection('messages')
        .doc();

    await msgRef.set({
      'messageId': msgRef.id,
      'senderId': senderId,
      'content': content,
      'type': type,
      'status': 'sent',
      'readBy': [senderId],
      'createdAt': FieldValue.serverTimestamp(),
    });

    // Update chat metadata
    final chatRef = _firestore.collection('chats').doc(chatId);
    final chatDoc = await chatRef.get();
    final members = List<String>.from(chatDoc.data()?['members'] ?? []);

    final updates = <String, dynamic>{
      'lastMessage': content,
      'lastMessageTime': FieldValue.serverTimestamp(),
      'lastMessageSenderId': senderId,
    };

    for (final m in members) {
      if (m != senderId) {
        updates['unreadCounts.$m'] = FieldValue.increment(1);
      }
    }

    await chatRef.update(updates);
  }

  /// Mark messages as read
  Future<void> markAsRead(String chatId, String userId) async {
    await _firestore.collection('chats').doc(chatId).update({
      'unreadCounts.$userId': 0,
    });
  }

  /// Update typing status in RTDB
  Future<void> setTypingStatus(String chatId, String userId, bool isTyping) async {
    await _rtdb.ref('typing/$chatId/$userId').set(isTyping);
  }

  /// Stream typing status
  Stream<bool> getTypingStatus(String chatId, String userId) {
    return _rtdb
        .ref('typing/$chatId/$userId')
        .onValue
        .map((event) => event.snapshot.value == true);
  }

  /// Create or get 1-on-1 chat
  Future<String> getOrCreateChat(String userId1, String userId2) async {
    // Check if chat already exists
    final existing = await _firestore
        .collection('chats')
        .where('type', isEqualTo: 'individual')
        .where('members', arrayContains: userId1)
        .get();

    for (final doc in existing.docs) {
      final members = List<String>.from(doc.data()['members'] ?? []);
      if (members.contains(userId2) && members.length == 2) {
        return doc.id;
      }
    }

    // Create new chat
    final chatRef = _firestore.collection('chats').doc();
    await chatRef.set({
      'chatId': chatRef.id,
      'type': 'individual',
      'members': [userId1, userId2],
      'admins': [],
      'unreadCounts': {userId1: 0, userId2: 0},
      'createdAt': FieldValue.serverTimestamp(),
    });
    return chatRef.id;
  }
}
