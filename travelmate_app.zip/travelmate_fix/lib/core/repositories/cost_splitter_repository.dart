import 'dart:math';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import '../../models/expense.dart';

class CostSplitterRepository {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  /// Generate a random 6-character uppercase alphanumeric room code
  String _generateRoomCode() {
    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
    final rand = Random.secure();
    return List.generate(6, (_) => chars[rand.nextInt(chars.length)]).join();
  }

  Stream<List<Map<String, dynamic>>> getUserRooms() {
    final uid = FirebaseAuth.instance.currentUser?.uid;
    if (uid == null) return Stream.value([]);
    return _firestore
        .collection('splitter_rooms')
        .where('members', arrayContains: uid)
        .orderBy('createdAt', descending: true)
        .snapshots()
        .map((snapshot) =>
            snapshot.docs.map((d) => d.data() as Map<String, dynamic>).toList());
  }

  Future<String> createRoom(String roomName) async {
    final uid = FirebaseAuth.instance.currentUser!.uid;
    final userDoc = await _firestore.collection('users').doc(uid).get();
    final userName = userDoc.data()?['displayName'] ?? 'Unknown';

    // Generate unique room code
    String roomCode;
    bool isUnique = false;
    do {
      roomCode = _generateRoomCode();
      final existing = await _firestore
          .collection('splitter_rooms')
          .where('roomCode', isEqualTo: roomCode)
          .limit(1)
          .get();
      isUnique = existing.docs.isEmpty;
    } while (!isUnique);

    final docRef = _firestore.collection('splitter_rooms').doc();
    await docRef.set({
      'roomId': docRef.id,
      'roomName': roomName,
      'roomCode': roomCode,
      'createdBy': uid,
      'members': [uid],
      'memberNames': [userName],
      'createdAt': FieldValue.serverTimestamp(),
    });
    return docRef.id;
  }

  /// Join a room by its 6-character room code
  Future<bool> joinRoomByCode(String roomCode) async {
    final uid = FirebaseAuth.instance.currentUser!.uid;
    final userDoc = await _firestore.collection('users').doc(uid).get();
    final userName = userDoc.data()?['displayName'] ?? 'Unknown';

    final snapshot = await _firestore
        .collection('splitter_rooms')
        .where('roomCode', isEqualTo: roomCode.toUpperCase())
        .limit(1)
        .get();

    if (snapshot.docs.isEmpty) return false;

    final roomDoc = snapshot.docs.first;
    final members = List<String>.from(roomDoc.data()['members'] ?? []);
    final memberNames = List<String>.from(roomDoc.data()['memberNames'] ?? []);

    if (members.contains(uid)) return true; // Already a member

    members.add(uid);
    memberNames.add(userName);

    await roomDoc.reference.update({
      'members': members,
      'memberNames': memberNames,
    });
    return true;
  }

  Stream<List<Expense>> getRoomExpenses(String roomId) {
    return _firestore
        .collection('splitter_rooms')
        .doc(roomId)
        .collection('expenses')
        .orderBy('createdAt', descending: true)
        .snapshots()
        .map((snapshot) => snapshot.docs
            .map((d) => Expense.fromMap(d.data() as Map<String, dynamic>))
            .toList());
  }

  Future<void> addExpense(String roomId, Expense expense) async {
    final docRef = _firestore
        .collection('splitter_rooms')
        .doc(roomId)
        .collection('expenses')
        .doc();
    await docRef.set({
      ...expense.toMap(),
      'expenseId': docRef.id,
      'createdAt': FieldValue.serverTimestamp(),
    });
  }
}
