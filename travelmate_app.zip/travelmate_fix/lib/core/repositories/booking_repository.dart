import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import '../../models/booking.dart';

class BookingRepository {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  Stream<List<Booking>> getUserBookings() {
    final uid = FirebaseAuth.instance.currentUser?.uid;
    if (uid == null) return Stream.value([]);
    return _firestore
        .collection('bookings')
        .where('userId', isEqualTo: uid)
        .orderBy('createdAt', descending: true)
        .snapshots()
        .map((snapshot) => snapshot.docs
            .map((d) => Booking.fromMap(d.data() as Map<String, dynamic>))
            .toList());
  }

  Future<void> createBooking(Booking booking) async {
    await _firestore.collection('bookings').doc(booking.bookingId).set(
          booking.toMap()..['createdAt'] = FieldValue.serverTimestamp(),
        );
  }
}
