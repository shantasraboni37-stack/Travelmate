import 'dart:io';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import '../../models/user.dart';
import '../services/r2_service.dart';

class UserRepository {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  final FirebaseAuth _auth = FirebaseAuth.instance;

  String? get currentUid => _auth.currentUser?.uid;

  Stream<UserModel?> getCurrentUserStream() {
    final uid = currentUid;
    if (uid == null) return Stream.value(null);
    return _firestore
        .collection('users')
        .doc(uid)
        .snapshots()
        .map((doc) =>
            doc.exists ? UserModel.fromMap(doc.data() as Map<String, dynamic>) : null);
  }

  Future<UserModel?> getCurrentUser() async {
    final uid = currentUid;
    if (uid == null) return null;
    final doc = await _firestore.collection('users').doc(uid).get();
    if (!doc.exists) return null;
    return UserModel.fromMap(doc.data() as Map<String, dynamic>);
  }

  Future<void> updateProfile({
    String? displayName,
    String? bio,
    List<String>? interests,
    File? profilePic,
    File? coverPic,
  }) async {
    final uid = currentUid;
    if (uid == null) throw Exception('Not logged in');

    final updates = <String, dynamic>{
      'updatedAt': FieldValue.serverTimestamp(),
    };

    if (displayName != null) updates['displayName'] = displayName;
    if (bio != null) updates['bio'] = bio;
    if (interests != null) updates['interests'] = interests;

    if (profilePic != null) {
      final url = await R2Service.uploadPrivate(
        file: profilePic,
        key: 'users/profile/$uid/profile.jpg',
        contentType: 'image/jpeg',
      );
      updates['profilePicUrl'] = url;
      updates['hasProfilePic'] = true;
    }

    if (coverPic != null) {
      final url = await R2Service.uploadPrivate(
        file: coverPic,
        key: 'users/profile/$uid/cover.jpg',
        contentType: 'image/jpeg',
      );
      updates['coverPicUrl'] = url;
      updates['hasCoverPic'] = true;
    }

    await _firestore.collection('users').doc(uid).update(updates);
  }

  Future<void> updateSetting(String field, dynamic value) async {
    final uid = currentUid;
    if (uid == null) throw Exception('Not logged in');
    await _firestore.collection('users').doc(uid).update({field: value});
  }

  Future<void> toggleFollow(String targetUid) async {
    final uid = currentUid;
    if (uid == null) throw Exception('Not logged in');

    final followRef = _firestore
        .collection('follows')
        .doc('${uid}_$targetUid');

    final doc = await followRef.get();
    if (doc.exists) {
      await followRef.delete();
      // Decrement counts
      await _firestore.collection('users').doc(uid).update({
        'followingCount': FieldValue.increment(-1),
      });
      await _firestore.collection('users').doc(targetUid).update({
        'followerCount': FieldValue.increment(-1),
      });
    } else {
      await followRef.set({
        'followId': '${uid}_$targetUid',
        'followerUid': uid,
        'followedUid': targetUid,
        'status': 'accepted',
        'createdAt': FieldValue.serverTimestamp(),
      });
      await _firestore.collection('users').doc(uid).update({
        'followingCount': FieldValue.increment(1),
      });
      await _firestore.collection('users').doc(targetUid).update({
        'followerCount': FieldValue.increment(1),
      });
    }
  }
}
