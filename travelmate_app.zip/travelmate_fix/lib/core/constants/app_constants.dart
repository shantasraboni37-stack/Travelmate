class AppConstants {
  AppConstants._();

  // Worker API
  static const String workerBaseUrl =
      'https://travelmate-go.nasimkhan1488537.workers.dev';

  // R2 Public Bucket (direct URLs)
  static const String r2PublicBase =
      'https://pub-c308fa6c5a3f4549ad0c878afc3e51a4.r2.dev';

  // Stripe
  static const String stripePublishableKey =
      'pk_test_51TEE0JIQwqiJ8yclGI1PC5Sa3NzdILNuucJnMpc33j4AV2DZVfkQp4m0eDWMSGHe7B2ARMD6NgHn07VDOuxyuSR700umIyDaY4';

  // Agora
  static const String agoraAppId = '4542fbff5cde4249a2f6bd37a6cd467d';

  // Firebase (android)
  static const String firebaseApiKey =
      'AIzaSyCqouOltNT8A-FGYX3lCjQtBUTfDMyNFtk';
  static const String firebaseAppId =
      '1:131478112691:android:54c6b7d845ccf8461c63c6';
  static const String firebaseProjectId = 'travelmate-world';
  static const String firebaseDatabaseUrl =
      'https://travelmate-world-default-rtdb.firebaseio.com';
  static const String firebaseStorageBucket =
      'travelmate-world.firebasestorage.app';

  // Travel interests for setup
  static const List<String> travelInterests = [
    'Adventure',
    'Beach',
    'Culture',
    'Nature',
    'Food',
    'History',
    'City',
    'Mountain',
    'Backpacking',
    'Luxury',
    'Wildlife',
    'Camping',
  ];

  // Gender options
  static const List<String> genderOptions = [
    'Male',
    'Female',
    'Other',
    'Prefer not to say',
  ];

  // Max values
  static const int maxFriends = 2000;
  static const int maxPostImages = 10;
  static const int maxBioLength = 200;
  static const int maxVisitedPlaces = 7;

  // Sticker packs
  static const List<Map<String, dynamic>> stickerPacks = [
    {'name': 'UtyaDuck', 'count': 40, 'folder': 'UtyaDuck'},
    {'name': 'LadyVampire', 'count': 16, 'folder': 'LadyVampire'},
    {'name': 'KangarooFighter', 'count': 27, 'folder': 'KangarooFighter'},
    {'name': 'Memes', 'count': 31, 'folder': 'Memes'},
    {'name': 'NyaChan', 'count': 27, 'folder': 'NyaChan'},
    {'name': 'YellowBoy', 'count': 22, 'folder': 'YellowBoy'},
    {'name': 'MuscleDoge', 'count': 35, 'folder': 'MuscleDoge'},
    {'name': 'FunkyGoose', 'count': 41, 'folder': 'FunkyGoose'},
    {'name': 'CloudiaSheep', 'count': 26, 'folder': 'CloudiaSheep'},
  ];

  // Package countries
  static const List<String> packageCountries = [
    'japan',
    'italy',
    'maldives',
    'turkey',
    'peru',
    'morocco',
    'iceland',
    'thailand',
    'srilanka',
    'newzealand',
  ];
}
