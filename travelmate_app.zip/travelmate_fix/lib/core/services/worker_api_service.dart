import 'dart:convert';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:http/http.dart' as http;
import '../constants/app_constants.dart';

class WorkerApiService {
  static const _base = AppConstants.workerBaseUrl;

  static Future<String> _token() async {
    final user = FirebaseAuth.instance.currentUser;
    if (user == null) throw Exception('User not logged in');
    final token = await user.getIdToken();
    if (token == null || token.isEmpty) throw Exception('Failed to get auth token');
    return token;
  }

  static Map<String, String> _headers(String token) => {
        'Authorization': 'Bearer $token',
        'Content-Type': 'application/json',
      };

  // Health check
  static Future<Map<String, dynamic>> healthCheck() async {
    final res = await http.get(Uri.parse(_base));
    return jsonDecode(res.body) as Map<String, dynamic>;
  }

  // POST /feed/rank
  static Future<List<dynamic>> rankFeed({
    required List<Map<String, dynamic>> posts,
    required String viewerCountry,
    required List<String> viewerInterests,
  }) async {
    final token = await _token();
    final res = await http.post(
      Uri.parse('$_base/feed/rank'),
      headers: _headers(token),
      body: jsonEncode({
        'posts': posts,
        'viewerCountry': viewerCountry,
        'viewerInterests': viewerInterests,
      }),
    );
    if (res.statusCode != 200) throw Exception('Feed rank failed: ${res.body}');
    return (jsonDecode(res.body)['ranked'] as List);
  }

  // POST /notify - single device
  static Future<void> sendNotification({
    required String fcmToken,
    required String title,
    required String body,
    Map<String, String>? data,
  }) async {
    final token = await _token();
    await http.post(
      Uri.parse('$_base/notify'),
      headers: _headers(token),
      body: jsonEncode({
        'token': fcmToken,
        'title': title,
        'body': body,
        if (data != null) 'data': data,
      }),
    );
  }

  // POST /notify/multicast
  static Future<void> sendMulticast({
    required List<String> fcmTokens,
    required String title,
    required String body,
    Map<String, String>? data,
  }) async {
    final token = await _token();
    await http.post(
      Uri.parse('$_base/notify/multicast'),
      headers: _headers(token),
      body: jsonEncode({
        'tokens': fcmTokens,
        'title': title,
        'body': body,
        if (data != null) 'data': data,
      }),
    );
  }

  // POST /agora/token
  static Future<Map<String, dynamic>> getAgoraToken(String channelName) async {
    final token = await _token();
    final res = await http.post(
      Uri.parse('$_base/agora/token'),
      headers: _headers(token),
      body: jsonEncode({'channelName': channelName}),
    );
    if (res.statusCode != 200) throw Exception('Agora token failed');
    return jsonDecode(res.body) as Map<String, dynamic>;
  }

  // POST /payment/intent
  static Future<String> createPaymentIntent({
    required double amountUsd,
    required String packageName,
    String bookingType = 'package',
  }) async {
    final token = await _token();
    final res = await http.post(
      Uri.parse('$_base/payment/intent'),
      headers: _headers(token),
      body: jsonEncode({
        'amountUsd': amountUsd,
        'packageName': packageName,
        'bookingType': bookingType,
      }),
    );
    if (res.statusCode != 200) throw Exception('Payment intent failed');
    return jsonDecode(res.body)['clientSecret'] as String;
  }

  // POST /payment/confirm-booking
  static Future<String> confirmBooking({
    required String paymentIntentId,
    required String packageId,
    required String packageName,
    required int participants,
    required double totalAmountUsd,
    String bookingType = 'package',
    String? guideUid,
  }) async {
    final token = await _token();
    final res = await http.post(
      Uri.parse('$_base/payment/confirm-booking'),
      headers: _headers(token),
      body: jsonEncode({
        'paymentIntentId': paymentIntentId,
        'packageId': packageId,
        'packageName': packageName,
        'participants': participants,
        'totalAmountUsd': totalAmountUsd,
        'bookingType': bookingType,
        if (guideUid != null) 'guideUid': guideUid,
      }),
    );
    if (res.statusCode != 200) throw Exception('Booking confirm failed');
    return jsonDecode(res.body)['bookingId'] as String;
  }

  // POST /r2/sign-upload
  static Future<Map<String, dynamic>> getPresignedUrl({
    required String key,
    required String contentType,
  }) async {
    final token = await _token();
    final res = await http.post(
      Uri.parse('$_base/r2/sign-upload'),
      headers: _headers(token),
      body: jsonEncode({'key': key, 'contentType': contentType}),
    );
    if (res.statusCode != 200) {
      throw Exception('Failed to get presigned URL: ${res.body}');
    }
    return jsonDecode(res.body) as Map<String, dynamic>;
  }
}
