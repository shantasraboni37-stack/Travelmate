import 'dart:convert';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import '../../app/router/router.dart';
import '../../firebase_options.dart';

// Background FCM handler - must be top-level
@pragma('vm:entry-point')
Future<void> firebaseMessagingBackgroundHandler(RemoteMessage message) async {
  // Ensure Firebase is initialized in background isolate
  await Firebase.initializeApp(
    options: DefaultFirebaseOptions.currentPlatform,
  );
  await _showLocalNotification(message);
}

Future<void> _showLocalNotification(RemoteMessage message) async {
  final localNotifications = FlutterLocalNotificationsPlugin();
  const androidChannel = AndroidNotificationChannel(
    'travelmate_high_importance',
    'TravelMate Notifications',
    description: 'Notifications for TravelMate',
    importance: Importance.max,
  );

  await localNotifications
      .resolvePlatformSpecificImplementation<
          AndroidFlutterLocalNotificationsPlugin>()
      ?.createNotificationChannel(androidChannel);

  final notification = message.notification;
  if (notification == null) return;

  await localNotifications.show(
    notification.hashCode,
    notification.title,
    notification.body,
    NotificationDetails(
      android: AndroidNotificationDetails(
        androidChannel.id,
        androidChannel.name,
        channelDescription: androidChannel.description,
        importance: Importance.max,
        priority: Priority.high,
        icon: '@mipmap/ic_launcher',
      ),
    ),
    payload: jsonEncode(message.data),
  );
}

class FcmService {
  static final _localNotifications = FlutterLocalNotificationsPlugin();
  static const _androidChannel = AndroidNotificationChannel(
    'travelmate_high_importance',
    'TravelMate Notifications',
    description: 'Notifications for TravelMate',
    importance: Importance.max,
  );

  static Future<void> initialize(WidgetRef ref) async {
    final messaging = FirebaseMessaging.instance;

    // Request permission (Android 13+)
    await messaging.requestPermission(
      alert: true,
      badge: true,
      sound: true,
    );

    // Init local notifications
    await _localNotifications.initialize(
      const InitializationSettings(
        android: AndroidInitializationSettings('@mipmap/ic_launcher'),
      ),
      onDidReceiveNotificationResponse: (response) {
        if (response.payload != null) {
          final data = jsonDecode(response.payload!) as Map<String, dynamic>;
          _handleNotificationTap(data, ref);
        }
      },
    );

    await _localNotifications
        .resolvePlatformSpecificImplementation<
            AndroidFlutterLocalNotificationsPlugin>()
        ?.createNotificationChannel(_androidChannel);

    // Foreground handler
    FirebaseMessaging.onMessage.listen((RemoteMessage message) {
      _showLocalNotification(message);
    });

    // Background tap handler
    FirebaseMessaging.onMessageOpenedApp.listen((RemoteMessage message) {
      _handleNotificationTap(message.data, ref);
    });

    // Terminated tap handler
    final initialMessage = await messaging.getInitialMessage();
    if (initialMessage != null) {
      _handleNotificationTap(initialMessage.data, ref);
    }

    // Save FCM token
    final token = await messaging.getToken();
    if (token != null) await _saveFcmToken(token);

    // Token refresh
    messaging.onTokenRefresh.listen(_saveFcmToken);

    // Setup RTDB online presence
    await _setupPresence(ref);
  }

  /// Setup RTDB online presence - writes status/{uid}/online
  static Future<void> _setupPresence(WidgetRef ref) async {
    final uid = FirebaseAuth.instance.currentUser?.uid;
    if (uid == null) return;

    final database = FirebaseDatabase.instance;
    final statusRef = database.ref('status/$uid');

    // Set online
    await statusRef.set({
      'online': true,
      'lastSeen': ServerValue.timestamp,
    });

    // Set up disconnect hook - mark offline when connection drops
    await statusRef.onDisconnect().set({
      'online': false,
      'lastSeen': ServerValue.timestamp,
    });
  }

  /// Update online status manually (called when app goes to background/foreground)
  static Future<void> updateOnlineStatus(bool online) async {
    final uid = FirebaseAuth.instance.currentUser?.uid;
    if (uid == null) return;

    final statusRef = FirebaseDatabase.instance.ref('status/$uid');
    await statusRef.set({
      'online': online,
      'lastSeen': ServerValue.timestamp,
    });
  }

  static void _handleNotificationTap(
      Map<String, dynamic> data, WidgetRef ref) {
    final router = ref.read(routerProvider);
    final type = data['type'] ?? '';
    final chatId = data['chatId'] ?? data['chat_id'] ?? '';
    final packageId = data['packageId'] ?? data['package_id'] ?? '';

    switch (type) {
      case 'new_message':
        if (chatId.isNotEmpty) {
          WidgetsBinding.instance.addPostFrameCallback((_) {
            router.push('/chat/$chatId');
          });
        } else {
          WidgetsBinding.instance.addPostFrameCallback((_) {
            router.push('/chats');
          });
        }
        break;
      case 'follow':
      case 'friend_request':
        WidgetsBinding.instance.addPostFrameCallback((_) {
          router.push('/notifications');
        });
        break;
      case 'booking_confirmed':
        WidgetsBinding.instance.addPostFrameCallback((_) {
          router.push('/bookings');
        });
        break;
      case 'package':
        if (packageId.isNotEmpty) {
          WidgetsBinding.instance.addPostFrameCallback((_) {
            router.push('/package/$packageId');
          });
        } else {
          WidgetsBinding.instance.addPostFrameCallback((_) {
            router.push('/packages');
          });
        }
        break;
      default:
        // Unknown type - navigate to notifications as fallback
        WidgetsBinding.instance.addPostFrameCallback((_) {
          router.push('/notifications');
        });
    }
  }

  static Future<void> _saveFcmToken(String token) async {
    final uid = FirebaseAuth.instance.currentUser?.uid;
    if (uid == null) return;
    await FirebaseFirestore.instance
        .collection('users')
        .doc(uid)
        .update({'fcmToken': token});
  }
}
