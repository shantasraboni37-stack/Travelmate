import 'dart:io';
import 'dart:typed_data';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:http/http.dart' as http;
import '../constants/app_constants.dart';
import 'worker_api_service.dart';

class R2Service {
  static const _workerBase = AppConstants.workerBaseUrl;
  static const _publicBase = AppConstants.r2PublicBase;

  /// Upload file to private R2 via Worker presigned URL
  static Future<String> uploadPrivate({
    required File file,
    required String key,
    required String contentType,
  }) async {
    // Step 1: Get presigned URL from Worker
    final signData = await WorkerApiService.getPresignedUrl(
      key: key,
      contentType: contentType,
    );
    final uploadUrl = signData['uploadUrl'] as String;
    final proxyUrl = signData['proxyUrl'] as String;

    // Step 2: PUT file directly to R2
    final bytes = await file.readAsBytes();
    final putRes = await http.put(
      Uri.parse(uploadUrl),
      headers: {'Content-Type': contentType},
      body: bytes,
    );
    if (putRes.statusCode != 200) {
      throw Exception('R2 upload failed: ${putRes.statusCode}');
    }

    // Step 3: Return proxy URL to store in Firestore
    return proxyUrl;
  }

  /// Upload bytes to private R2
  static Future<String> uploadPrivateBytes({
    required Uint8List bytes,
    required String key,
    required String contentType,
  }) async {
    final signData = await WorkerApiService.getPresignedUrl(
      key: key,
      contentType: contentType,
    );
    final uploadUrl = signData['uploadUrl'] as String;
    final proxyUrl = signData['proxyUrl'] as String;

    final putRes = await http.put(
      Uri.parse(uploadUrl),
      headers: {'Content-Type': contentType},
      body: bytes,
    );
    if (putRes.statusCode != 200) {
      throw Exception('R2 upload failed: ${putRes.statusCode}');
    }
    return proxyUrl;
  }

  /// Load private image URL (profile, cover, chat media)
  static String privateUrl(String key) => '$_workerBase/media/$key';

  /// Profile pic URL for a user
  static String profilePicUrl(String uid) =>
      '$_workerBase/media/users/profile/$uid/profile.jpg';

  /// Cover pic URL for a user
  static String coverPicUrl(String uid) =>
      '$_workerBase/media/users/profile/$uid/cover.jpg';

  /// Chat media URL
  static String chatMediaUrl(String chatId, String folder, String filename) =>
      '$_workerBase/media/chat/$folder/$chatId/$filename';

  // --- Public R2 URLs (no auth needed) ---
  static String packageImg(String country, String file) =>
      '$_publicBase/media/images/packages/$country/$file';

  static String packageVideo(String country, String file) =>
      '$_publicBase/media/videos/packages/$country/$file';

  static String reviewerPic(String name) =>
      '$_publicBase/media/images/feedback/$name.jpg';

  static String feedbackVideo(int n) =>
      '$_publicBase/media/videos/feedback/d$n.mp4';

  static String bannerImg(String folder, String file) =>
      '$_publicBase/media/images/banners/$folder/$file';

  static String onboardingVideo(String file) =>
      '$_publicBase/media/videos/onboarding/$file';

  static String onboardingImage(String file) =>
      '$_publicBase/media/images/onboarding/$file';

  static String finderVideo(String file) =>
      '$_publicBase/media/videos/finder/$file';

  static String communityVideo(String file) =>
      '$_publicBase/media/videos/community/$file';
}
