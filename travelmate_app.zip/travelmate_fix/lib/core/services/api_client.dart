import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:http/http.dart' as http;
import '../constants/app_constants.dart';

/// Centralized API client that auto-attaches Firebase JWT to every request.
/// All API calls go through this class - never use http directly.
class ApiClient {
  ApiClient._();
  static final ApiClient instance = ApiClient._();

  static const _base = AppConstants.workerBaseUrl;

  /// Get current Firebase ID token. Refreshes automatically if expired.
  Future<String> _getToken() async {
    final user = FirebaseAuth.instance.currentUser;
    if (user == null) throw ApiException('User not authenticated', 401);
    final token = await user.getIdToken(true); // force refresh
    if (token == null || token.isEmpty) {
      throw ApiException('Failed to get Firebase token', 401);
    }
    return token;
  }

  Map<String, String> _headers(String token) => {
        'Authorization': 'Bearer $token',
        'Content-Type': 'application/json',
        'Accept': 'application/json',
      };

  /// Generic GET request
  Future<dynamic> get(String path) async {
    try {
      final token = await _getToken();
      final response = await http.get(
        Uri.parse('$_base$path'),
        headers: _headers(token),
      );
      return _handleResponse(response);
    } on SocketException {
      throw ApiException('No internet connection', 0);
    } catch (e) {
      throw ApiException(e.toString(), -1);
    }
  }

  /// Generic POST request
  Future<dynamic> post(String path, {Map<String, dynamic>? body}) async {
    try {
      final token = await _getToken();
      final response = await http.post(
        Uri.parse('$_base$path'),
        headers: _headers(token),
        body: body != null ? jsonEncode(body) : null,
      );
      return _handleResponse(response);
    } on SocketException {
      throw ApiException('No internet connection', 0);
    } catch (e) {
      throw ApiException(e.toString(), -1);
    }
  }

  /// Generic PUT request (for R2 direct uploads)
  Future<void> putRaw(String url, {required List<int> bytes, required String contentType}) async {
    try {
      final response = await http.put(
        Uri.parse(url),
        headers: {'Content-Type': contentType},
        body: bytes,
      );
      if (response.statusCode != 200) {
        throw ApiException('Upload failed: ${response.statusCode}', response.statusCode);
      }
    } on SocketException {
      throw ApiException('No internet connection', 0);
    }
  }

  /// GET raw image bytes with auth token (for private R2 images)
  Future<Uint8List> getAuthenticated(String url, {required String token}) async {
    try {
      final response = await http.get(
        Uri.parse(url),
        headers: {
          'Authorization': 'Bearer $token',
        },
      );
      if (response.statusCode == 200) {
        return response.bodyBytes;
      }
      throw ApiException('Image load failed: ${response.statusCode}', response.statusCode);
    } on SocketException {
      throw ApiException('No internet connection', 0);
    }
  }

  /// GET raw bytes without auth (for public images)
  Future<Uint8List> getRaw(String url) async {
    try {
      final response = await http.get(Uri.parse(url));
      if (response.statusCode == 200) {
        return response.bodyBytes;
      }
      throw ApiException('Image load failed: ${response.statusCode}', response.statusCode);
    } on SocketException {
      throw ApiException('No internet connection', 0);
    }
  }

  /// Handle HTTP response - parse JSON or throw
  dynamic _handleResponse(http.Response response) {
    if (response.statusCode >= 200 && response.statusCode < 300) {
      if (response.body.isEmpty) return null;
      return jsonDecode(response.body);
    }
    // Try to parse error message from body
    String message = 'Request failed with status ${response.statusCode}';
    try {
      final body = jsonDecode(response.body);
      if (body is Map && body.containsKey('error')) {
        message = body['error'].toString();
      }
    } catch (_) {}
    throw ApiException(message, response.statusCode);
  }
}

/// Custom API exception with status code
class ApiException implements Exception {
  final String message;
  final int statusCode;
  ApiException(this.message, this.statusCode);

  @override
  String toString() => 'ApiException: $message (status: $statusCode)';
}
