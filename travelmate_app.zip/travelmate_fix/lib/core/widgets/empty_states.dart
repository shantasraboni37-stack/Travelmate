import 'package:flutter/material.dart';

class EmptyStateWidget extends StatelessWidget {
  final IconData icon;
  final String title;
  final String subtitle;
  final String? actionLabel;
  final VoidCallback? onAction;

  const EmptyStateWidget({
    super.key,
    required this.icon,
    required this.title,
    required this.subtitle,
    this.actionLabel,
    this.onAction,
  });

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(32),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(
              icon,
              size: 64,
              color: Theme.of(context).colorScheme.primary.withOpacity(0.5),
            ),
            const SizedBox(height: 16),
            Text(
              title,
              style: Theme.of(context).textTheme.titleLarge?.copyWith(
                    fontWeight: FontWeight.w700,
                  ),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 8),
            Text(
              subtitle,
              style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                    color: Colors.grey[600],
                  ),
              textAlign: TextAlign.center,
            ),
            if (actionLabel != null && onAction != null) ...[
              const SizedBox(height: 24),
              ElevatedButton(
                onPressed: onAction,
                child: Text(actionLabel!),
              ),
            ],
          ],
        ),
      ),
    );
  }
}

class EmptyBuddyFeed extends StatelessWidget {
  final VoidCallback? onPostTrip;
  const EmptyBuddyFeed({super.key, this.onPostTrip});

  @override
  Widget build(BuildContext context) => EmptyStateWidget(
        icon: Icons.travel_explore_outlined,
        title: 'No Trips Posted Yet',
        subtitle: 'Be the first to share your travel plans and find a buddy.',
        actionLabel: 'Post a Trip',
        onAction: onPostTrip,
      );
}

class EmptyCommunityFeed extends StatelessWidget {
  final VoidCallback? onShare;
  const EmptyCommunityFeed({super.key, this.onShare});

  @override
  Widget build(BuildContext context) => EmptyStateWidget(
        icon: Icons.public_outlined,
        title: 'Nothing Here Yet',
        subtitle: 'Share your travel experiences with the community.',
        actionLabel: 'Share Experience',
        onAction: onShare,
      );
}

class EmptyChatInbox extends StatelessWidget {
  final VoidCallback? onFindBuddy;
  const EmptyChatInbox({super.key, this.onFindBuddy});

  @override
  Widget build(BuildContext context) => EmptyStateWidget(
        icon: Icons.chat_bubble_outline,
        title: 'No Conversations Yet',
        subtitle: 'Start chatting with your travel buddies.',
        actionLabel: 'Find a Buddy',
        onAction: onFindBuddy,
      );
}

class EmptyNotifications extends StatelessWidget {
  const EmptyNotifications({super.key});

  @override
  Widget build(BuildContext context) => const EmptyStateWidget(
        icon: Icons.notifications_none_outlined,
        title: 'No Notifications',
        subtitle: 'You\'ll see activity from your buddies here.',
      );
}

class EmptyPackages extends StatelessWidget {
  const EmptyPackages({super.key});

  @override
  Widget build(BuildContext context) => const EmptyStateWidget(
        icon: Icons.card_travel_outlined,
        title: 'No Packages Available',
        subtitle: 'Check back later for new travel packages.',
      );
}
