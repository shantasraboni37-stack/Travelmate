import 'package:flutter/material.dart';

enum MessageStatus { sending, sent, delivered, seen }

class MessageTick extends StatelessWidget {
  final MessageStatus status;
  final Color? color;
  const MessageTick({super.key, required this.status, this.color});

  @override
  Widget build(BuildContext context) {
    final tickColor = status == MessageStatus.seen
        ? const Color(0xFF1B4D8E)
        : (color ?? Colors.grey);

    switch (status) {
      case MessageStatus.sending:
        return Icon(Icons.access_time, size: 14, color: tickColor);
      case MessageStatus.sent:
        return Icon(Icons.done, size: 14, color: tickColor);
      case MessageStatus.delivered:
        return Icon(Icons.done_all, size: 14, color: tickColor);
      case MessageStatus.seen:
        return Icon(Icons.done_all, size: 14, color: tickColor);
    }
  }
}
