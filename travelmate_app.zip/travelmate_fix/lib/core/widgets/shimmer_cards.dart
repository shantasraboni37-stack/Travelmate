import 'package:flutter/material.dart';
import 'package:shimmer/shimmer.dart';

Widget _box(double w, double h, {double r = 8}) => Container(
      width: w,
      height: h,
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(r),
      ),
    );

Widget shimmerWrap(Widget child) => Shimmer.fromColors(
      baseColor: const Color(0xFFE8E8E8),
      highlightColor: const Color(0xFFF5F5F5),
      child: child,
    );

class BuddyCardSkeleton extends StatelessWidget {
  const BuddyCardSkeleton({super.key});

  @override
  Widget build(BuildContext context) => shimmerWrap(
        Container(
          margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(18),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(children: [
                _box(52, 52, r: 26),
                const SizedBox(width: 12),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    _box(140, 14),
                    const SizedBox(height: 6),
                    _box(100, 11),
                  ],
                ),
              ]),
              const SizedBox(height: 14),
              _box(double.infinity, 13),
              const SizedBox(height: 6),
              _box(200, 13),
              const SizedBox(height: 12),
              _box(double.infinity, 160, r: 12),
              const SizedBox(height: 12),
              Row(children: [
                _box(80, 11),
                const SizedBox(width: 8),
                _box(80, 11),
              ]),
            ],
          ),
        ),
      );
}

class PackageCardSkeleton extends StatelessWidget {
  const PackageCardSkeleton({super.key});

  @override
  Widget build(BuildContext context) => shimmerWrap(
        Container(
          margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(18),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              _box(double.infinity, 200, r: 18),
              Padding(
                padding: const EdgeInsets.all(14),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    _box(220, 16),
                    const SizedBox(height: 8),
                    _box(140, 12),
                    const SizedBox(height: 8),
                    _box(100, 12),
                  ],
                ),
              ),
            ],
          ),
        ),
      );
}

class ChatCardSkeleton extends StatelessWidget {
  const ChatCardSkeleton({super.key});

  @override
  Widget build(BuildContext context) => shimmerWrap(
        Container(
          margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
          padding: const EdgeInsets.all(12),
          child: Row(children: [
            _box(52, 52, r: 26),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  _box(140, 14),
                  const SizedBox(height: 6),
                  _box(double.infinity, 11),
                ],
              ),
            ),
            _box(40, 11),
          ]),
        ),
      );
}

class SkeletonFeedList extends StatelessWidget {
  final Widget Function() cardBuilder;
  final int count;
  const SkeletonFeedList({
    super.key,
    required this.cardBuilder,
    this.count = 4,
  });

  @override
  Widget build(BuildContext context) => ListView.builder(
        itemCount: count,
        physics: const NeverScrollableScrollPhysics(),
        shrinkWrap: true,
        itemBuilder: (_, __) => cardBuilder(),
      );
}
