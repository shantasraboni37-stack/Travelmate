import 'dart:typed_data';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import '../services/api_client.dart';

/// Loads images from Worker proxy URLs with Firebase auth header.
/// For private R2 images that require authentication.
class AuthNetworkImage extends StatefulWidget {
  final String? imageUrl;
  final double? width;
  final double? height;
  final BoxFit fit;
  final BorderRadius? borderRadius;
  final Widget? placeholder;
  final Widget? errorWidget;

  const AuthNetworkImage({
    super.key,
    required this.imageUrl,
    this.width,
    this.height,
    this.fit = BoxFit.cover,
    this.borderRadius,
    this.placeholder,
    this.errorWidget,
  });

  @override
  State<AuthNetworkImage> createState() => _AuthNetworkImageState();
}

class _AuthNetworkImageState extends State<AuthNetworkImage> {
  Uint8List? _bytes;
  bool _loading = true;
  bool _error = false;

  @override
  void initState() {
    super.initState();
    _loadImage();
  }

  @override
  void didUpdateWidget(AuthNetworkImage old) {
    super.didUpdateWidget(old);
    if (old.imageUrl != widget.imageUrl) {
      _loadImage();
    }
  }

  Future<void> _loadImage() async {
    if (widget.imageUrl == null || widget.imageUrl!.isEmpty) {
      setState(() {
        _loading = false;
        _error = true;
      });
      return;
    }

    try {
      final user = FirebaseAuth.instance.currentUser;
      if (user == null) {
        setState(() {
          _loading = false;
          _error = true;
        });
        return;
      }
      final token = await user.getIdToken();
      final response = await ApiClient.instance.getAuthenticated(
        widget.imageUrl!,
        token: token,
      );
      setState(() {
        _bytes = response;
        _loading = false;
        _error = false;
      });
    } catch (e) {
      // Fallback: try loading without auth header (public images)
      try {
        final response = await ApiClient.instance.getRaw(widget.imageUrl!);
        setState(() {
          _bytes = response;
          _loading = false;
          _error = false;
        });
      } catch (_) {
        setState(() {
          _loading = false;
          _error = true;
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) {
      return SizedBox(
        width: widget.width,
        height: widget.height,
        child: widget.placeholder ??
            const Center(child: CircularProgressIndicator(strokeWidth: 2)),
      );
    }

    if (_error || _bytes == null) {
      return SizedBox(
        width: widget.width,
        height: widget.height,
        child: widget.errorWidget ??
            Container(
              color: Colors.grey[300],
              child: const Icon(Icons.broken_image, color: Colors.grey),
            ),
      );
    }

    final image = Image.memory(
      _bytes!,
      width: widget.width,
      height: widget.height,
      fit: widget.fit,
    );

    if (widget.borderRadius != null) {
      return ClipRRect(
        borderRadius: widget.borderRadius!,
        child: image,
      );
    }

    return image;
  }
}

/// Simpler CircleAvatar that loads auth-required profile images
class AuthCircleAvatar extends StatefulWidget {
  final String? imageUrl;
  final double radius;
  final String fallbackText;

  const AuthCircleAvatar({
    super.key,
    this.imageUrl,
    this.radius = 24,
    required this.fallbackText,
  });

  @override
  State<AuthCircleAvatar> createState() => _AuthCircleAvatarState();
}

class _AuthCircleAvatarState extends State<AuthCircleAvatar> {
  Uint8List? _bytes;

  @override
  void initState() {
    super.initState();
    _loadImage();
  }

  @override
  void didUpdateWidget(AuthCircleAvatar old) {
    super.didUpdateWidget(old);
    if (old.imageUrl != widget.imageUrl) {
      _loadImage();
    }
  }

  Future<void> _loadImage() async {
    if (widget.imageUrl == null || widget.imageUrl!.isEmpty) return;
    try {
      final user = FirebaseAuth.instance.currentUser;
      if (user == null) return;
      final token = await user.getIdToken();
      final bytes = await ApiClient.instance.getAuthenticated(
        widget.imageUrl!,
        token: token,
      );
      if (mounted) {
        setState(() => _bytes = bytes);
      }
    } catch (_) {
      // Silently fail - will show fallback
    }
  }

  @override
  Widget build(BuildContext context) {
    if (_bytes != null) {
      return CircleAvatar(
        radius: widget.radius,
        backgroundImage: MemoryImage(_bytes!),
      );
    }
    return CircleAvatar(
      radius: widget.radius,
      child: Text(
        widget.fallbackText.isNotEmpty
            ? widget.fallbackText[0].toUpperCase()
            : '?',
        style: TextStyle(
          fontSize: widget.radius * 0.6,
          fontWeight: FontWeight.w600,
        ),
      ),
    );
  }
}
