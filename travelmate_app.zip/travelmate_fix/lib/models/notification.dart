import 'package:cloud_firestore/cloud_firestore.dart';

class NotificationModel {
  final String notifId;
  final String type;
  final String fromUid;
  final String fromName;
  final String? fromPhotoUrl;
  final String? postId;
  final String? chatId;
  final bool isRead;
  final Timestamp? createdAt;

  NotificationModel({
    required this.notifId,
    required this.type,
    required this.fromUid,
    required this.fromName,
    this.fromPhotoUrl,
    this.postId,
    this.chatId,
    this.isRead = false,
    this.createdAt,
  });

  factory NotificationModel.fromMap(Map<String, dynamic> map) {
    return NotificationModel(
      notifId: map['notifId'] ?? '',
      type: map['type'] ?? '',
      fromUid: map['fromUid'] ?? '',
      fromName: map['fromName'] ?? '',
      fromPhotoUrl: map['fromPhotoUrl'],
      postId: map['postId'],
      chatId: map['chatId'],
      isRead: map['isRead'] ?? false,
      createdAt: map['createdAt'],
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'notifId': notifId,
      'type': type,
      'fromUid': fromUid,
      'fromName': fromName,
      'fromPhotoUrl': fromPhotoUrl,
      'postId': postId,
      'chatId': chatId,
      'isRead': isRead,
      'createdAt': createdAt,
    };
  }
}
