import 'package:cloud_firestore/cloud_firestore.dart';

enum FollowStatus { notFollowing, pending, friends, blocked }

class Follow {
  final String followId;
  final String followerUid;
  final String followedUid;
  final FollowStatus status;
  final Timestamp? createdAt;
  final Timestamp? acceptedAt;

  Follow({
    required this.followId,
    required this.followerUid,
    required this.followedUid,
    this.status = FollowStatus.pending,
    this.createdAt,
    this.acceptedAt,
  });

  factory Follow.fromMap(Map<String, dynamic> map) {
    FollowStatus parseStatus(String? s) {
      switch (s) {
        case 'accepted':
          return FollowStatus.friends;
        case 'pending':
          return FollowStatus.pending;
        case 'blocked':
          return FollowStatus.blocked;
        default:
          return FollowStatus.notFollowing;
      }
    }

    return Follow(
      followId: map['followId'] ?? '',
      followerUid: map['followerUid'] ?? '',
      followedUid: map['followedUid'] ?? '',
      status: parseStatus(map['status']),
      createdAt: map['createdAt'],
      acceptedAt: map['acceptedAt'],
    );
  }

  Map<String, dynamic> toMap() {
    String statusStr;
    switch (status) {
      case FollowStatus.friends:
        statusStr = 'accepted';
        break;
      case FollowStatus.pending:
        statusStr = 'pending';
        break;
      case FollowStatus.blocked:
        statusStr = 'blocked';
        break;
      default:
        statusStr = 'not_following';
    }
    return {
      'followId': followId,
      'followerUid': followerUid,
      'followedUid': followedUid,
      'status': statusStr,
      'createdAt': createdAt,
      'acceptedAt': acceptedAt,
    };
  }
}
