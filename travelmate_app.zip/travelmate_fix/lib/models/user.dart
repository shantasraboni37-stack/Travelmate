import 'package:cloud_firestore/cloud_firestore.dart';

class UserModel {
  final String uid;
  final String displayName;
  final String? email;
  final String? phone;
  final String? profilePicUrl;
  final String? coverPicUrl;
  final bool hasProfilePic;
  final bool hasCoverPic;
  final String bio;
  final String? gender;
  final Timestamp? birthday;
  final GeoPoint? location;
  final String? country;
  final List<String> languages;
  final List<String> interests;
  final List<String> visitedPlaces;
  final bool setupComplete;
  final bool isGuide;
  final String? guidePinnedPostId;
  final int friendCount;
  final int followerCount;
  final int followingCount;
  final List<String> profileViews;
  final List<String> blockedUsers;
  final String activeStatus;
  final String messageRequests;
  final bool readReceipts;
  final bool typingIndicator;
  final String darkMode;
  final String? fcmToken;
  final Timestamp? createdAt;

  UserModel({
    required this.uid,
    required this.displayName,
    this.email,
    this.phone,
    this.profilePicUrl,
    this.coverPicUrl,
    this.hasProfilePic = false,
    this.hasCoverPic = false,
    this.bio = '',
    this.gender,
    this.birthday,
    this.location,
    this.country,
    this.languages = const [],
    this.interests = const [],
    this.visitedPlaces = const [],
    this.setupComplete = false,
    this.isGuide = false,
    this.guidePinnedPostId,
    this.friendCount = 0,
    this.followerCount = 0,
    this.followingCount = 0,
    this.profileViews = const [],
    this.blockedUsers = const [],
    this.activeStatus = 'public',
    this.messageRequests = 'inbox',
    this.readReceipts = true,
    this.typingIndicator = true,
    this.darkMode = 'system',
    this.fcmToken,
    this.createdAt,
  });

  factory UserModel.fromMap(Map<String, dynamic> map) {
    return UserModel(
      uid: map['uid'] ?? '',
      displayName: map['displayName'] ?? '',
      email: map['email'],
      phone: map['phone'],
      profilePicUrl: map['profilePicUrl'],
      coverPicUrl: map['coverPicUrl'],
      hasProfilePic: map['hasProfilePic'] ?? false,
      hasCoverPic: map['hasCoverPic'] ?? false,
      bio: map['bio'] ?? '',
      gender: map['gender'],
      birthday: map['birthday'],
      location: map['location'],
      country: map['country'],
      languages: List<String>.from(map['languages'] ?? []),
      interests: List<String>.from(map['interests'] ?? []),
      visitedPlaces: List<String>.from(map['visitedPlaces'] ?? []),
      setupComplete: map['setupComplete'] ?? false,
      isGuide: map['isGuide'] ?? false,
      guidePinnedPostId: map['guidePinnedPostId'],
      friendCount: map['friendCount'] ?? 0,
      followerCount: map['followerCount'] ?? 0,
      followingCount: map['followingCount'] ?? 0,
      profileViews: List<String>.from(map['profileViews'] ?? []),
      blockedUsers: List<String>.from(map['blockedUsers'] ?? []),
      activeStatus: map['activeStatus'] ?? 'public',
      messageRequests: map['messageRequests'] ?? 'inbox',
      readReceipts: map['readReceipts'] ?? true,
      typingIndicator: map['typingIndicator'] ?? true,
      darkMode: map['darkMode'] ?? 'system',
      fcmToken: map['fcmToken'],
      createdAt: map['createdAt'],
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'uid': uid,
      'displayName': displayName,
      'email': email,
      'phone': phone,
      'profilePicUrl': profilePicUrl,
      'coverPicUrl': coverPicUrl,
      'hasProfilePic': hasProfilePic,
      'hasCoverPic': hasCoverPic,
      'bio': bio,
      'gender': gender,
      'birthday': birthday,
      'location': location,
      'country': country,
      'languages': languages,
      'interests': interests,
      'visitedPlaces': visitedPlaces,
      'setupComplete': setupComplete,
      'isGuide': isGuide,
      'guidePinnedPostId': guidePinnedPostId,
      'friendCount': friendCount,
      'followerCount': followerCount,
      'followingCount': followingCount,
      'profileViews': profileViews,
      'blockedUsers': blockedUsers,
      'activeStatus': activeStatus,
      'messageRequests': messageRequests,
      'readReceipts': readReceipts,
      'typingIndicator': typingIndicator,
      'darkMode': darkMode,
      'fcmToken': fcmToken,
      'createdAt': createdAt,
    };
  }

  UserModel copyWith({
    String? displayName,
    String? bio,
    String? profilePicUrl,
    String? coverPicUrl,
    bool? hasProfilePic,
    bool? hasCoverPic,
    String? gender,
    List<String>? interests,
    List<String>? visitedPlaces,
    bool? setupComplete,
    String? fcmToken,
    String? darkMode,
  }) {
    return UserModel(
      uid: uid,
      displayName: displayName ?? this.displayName,
      email: email,
      phone: phone,
      profilePicUrl: profilePicUrl ?? this.profilePicUrl,
      coverPicUrl: coverPicUrl ?? this.coverPicUrl,
      hasProfilePic: hasProfilePic ?? this.hasProfilePic,
      hasCoverPic: hasCoverPic ?? this.hasCoverPic,
      bio: bio ?? this.bio,
      gender: gender ?? this.gender,
      birthday: birthday,
      location: location,
      country: country,
      languages: languages,
      interests: interests ?? this.interests,
      visitedPlaces: visitedPlaces ?? this.visitedPlaces,
      setupComplete: setupComplete ?? this.setupComplete,
      isGuide: isGuide,
      guidePinnedPostId: guidePinnedPostId,
      friendCount: friendCount,
      followerCount: followerCount,
      followingCount: followingCount,
      profileViews: profileViews,
      blockedUsers: blockedUsers,
      activeStatus: activeStatus,
      messageRequests: messageRequests,
      readReceipts: readReceipts,
      typingIndicator: typingIndicator,
      darkMode: darkMode ?? this.darkMode,
      fcmToken: fcmToken ?? this.fcmToken,
      createdAt: createdAt,
    );
  }
}
