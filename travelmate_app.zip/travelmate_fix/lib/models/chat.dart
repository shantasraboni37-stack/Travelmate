import 'package:cloud_firestore/cloud_firestore.dart';

class Chat {
  final String chatId;
  final String type;
  final List<String> members;
  final List<String> admins;
  final String? groupName;
  final String? groupPhotoUrl;
  final String? lastMessage;
  final Timestamp? lastMessageTime;
  final String? lastMessageSenderId;
  final Map<String, dynamic> unreadCounts;
  final Timestamp? createdAt;

  Chat({
    required this.chatId,
    required this.type,
    required this.members,
    this.admins = const [],
    this.groupName,
    this.groupPhotoUrl,
    this.lastMessage,
    this.lastMessageTime,
    this.lastMessageSenderId,
    this.unreadCounts = const {},
    this.createdAt,
  });

  factory Chat.fromMap(Map<String, dynamic> map) {
    return Chat(
      chatId: map['chatId'] ?? '',
      type: map['type'] ?? 'individual',
      members: List<String>.from(map['members'] ?? []),
      admins: List<String>.from(map['admins'] ?? []),
      groupName: map['groupName'],
      groupPhotoUrl: map['groupPhotoUrl'],
      lastMessage: map['lastMessage'],
      lastMessageTime: map['lastMessageTime'],
      lastMessageSenderId: map['lastMessageSenderId'],
      unreadCounts: Map<String, dynamic>.from(map['unreadCounts'] ?? {}),
      createdAt: map['createdAt'],
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'chatId': chatId,
      'type': type,
      'members': members,
      'admins': admins,
      'groupName': groupName,
      'groupPhotoUrl': groupPhotoUrl,
      'lastMessage': lastMessage,
      'lastMessageTime': lastMessageTime,
      'lastMessageSenderId': lastMessageSenderId,
      'unreadCounts': unreadCounts,
      'createdAt': createdAt,
    };
  }
}

class Message {
  final String messageId;
  final String senderId;
  final String content;
  final String type;
  final String? mediaUrl;
  final String status;
  final List<String> readBy;
  final Timestamp? createdAt;
  final String? replyToMessageId;
  final String? replyToContent;

  Message({
    required this.messageId,
    required this.senderId,
    required this.content,
    this.type = 'text',
    this.mediaUrl,
    this.status = 'sent',
    this.readBy = const [],
    this.createdAt,
    this.replyToMessageId,
    this.replyToContent,
  });

  factory Message.fromMap(Map<String, dynamic> map) {
    return Message(
      messageId: map['messageId'] ?? '',
      senderId: map['senderId'] ?? '',
      content: map['content'] ?? '',
      type: map['type'] ?? 'text',
      mediaUrl: map['mediaUrl'],
      status: map['status'] ?? 'sent',
      readBy: List<String>.from(map['readBy'] ?? []),
      createdAt: map['createdAt'],
      replyToMessageId: map['replyToMessageId'],
      replyToContent: map['replyToContent'],
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'messageId': messageId,
      'senderId': senderId,
      'content': content,
      'type': type,
      'mediaUrl': mediaUrl,
      'status': status,
      'readBy': readBy,
      'createdAt': createdAt,
      'replyToMessageId': replyToMessageId,
      'replyToContent': replyToContent,
    };
  }
}
