import 'package:cloud_firestore/cloud_firestore.dart';

class Expense {
  final String expenseId;
  final String paidBy;
  final String paidByName;
  final double amount;
  final String description;
  final Timestamp? createdAt;

  Expense({
    required this.expenseId,
    required this.paidBy,
    required this.paidByName,
    required this.amount,
    required this.description,
    this.createdAt,
  });

  factory Expense.fromMap(Map<String, dynamic> map) {
    return Expense(
      expenseId: map['expenseId'] ?? '',
      paidBy: map['paidBy'] ?? '',
      paidByName: map['paidByName'] ?? '',
      amount: (map['amount'] ?? 0).toDouble(),
      description: map['description'] ?? '',
      createdAt: map['createdAt'],
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'expenseId': expenseId,
      'paidBy': paidBy,
      'paidByName': paidByName,
      'amount': amount,
      'description': description,
      'createdAt': createdAt,
    };
  }
}

class Settlement {
  final String from;
  final String to;
  final double amount;

  Settlement({required this.from, required this.to, required this.amount});

  factory Settlement.fromMap(Map<String, dynamic> map) {
    return Settlement(
      from: map['from'] ?? '',
      to: map['to'] ?? '',
      amount: (map['amount'] ?? 0).toDouble(),
    );
  }

  Map<String, dynamic> toMap() {
    return {'from': from, 'to': to, 'amount': amount};
  }
}

class SplitterRoom {
  final String roomId;
  final String roomName;
  final String createdBy;
  final List<String> members;
  final List<String> memberNames;
  final Timestamp? createdAt;

  SplitterRoom({
    required this.roomId,
    required this.roomName,
    required this.createdBy,
    required this.members,
    required this.memberNames,
    this.createdAt,
  });

  factory SplitterRoom.fromMap(Map<String, dynamic> map) {
    return SplitterRoom(
      roomId: map['roomId'] ?? '',
      roomName: map['roomName'] ?? '',
      createdBy: map['createdBy'] ?? '',
      members: List<String>.from(map['members'] ?? []),
      memberNames: List<String>.from(map['memberNames'] ?? []),
      createdAt: map['createdAt'],
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'roomId': roomId,
      'roomName': roomName,
      'createdBy': createdBy,
      'members': members,
      'memberNames': memberNames,
      'createdAt': createdAt,
    };
  }
}
