import 'package:cloud_firestore/cloud_firestore.dart';

class Booking {
  final String bookingId;
  final String userId;
  final String packageId;
  final String packageName;
  final int participants;
  final double totalAmountUsd;
  final String stripePaymentIntentId;
  final String status;
  final String? guideUid;
  final Timestamp? createdAt;

  Booking({
    required this.bookingId,
    required this.userId,
    required this.packageId,
    required this.packageName,
    required this.participants,
    required this.totalAmountUsd,
    required this.stripePaymentIntentId,
    this.status = 'confirmed',
    this.guideUid,
    this.createdAt,
  });

  factory Booking.fromMap(Map<String, dynamic> map) {
    return Booking(
      bookingId: map['bookingId'] ?? '',
      userId: map['userId'] ?? '',
      packageId: map['packageId'] ?? '',
      packageName: map['packageName'] ?? '',
      participants: map['participants'] ?? 1,
      totalAmountUsd: (map['totalAmountUsd'] ?? 0).toDouble(),
      stripePaymentIntentId: map['stripePaymentIntentId'] ?? '',
      status: map['status'] ?? 'confirmed',
      guideUid: map['guideUid'],
      createdAt: map['createdAt'],
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'bookingId': bookingId,
      'userId': userId,
      'packageId': packageId,
      'packageName': packageName,
      'participants': participants,
      'totalAmountUsd': totalAmountUsd,
      'stripePaymentIntentId': stripePaymentIntentId,
      'status': status,
      'guideUid': guideUid,
      'createdAt': createdAt,
    };
  }
}
