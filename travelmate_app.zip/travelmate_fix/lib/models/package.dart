import 'package:cloud_firestore/cloud_firestore.dart';

class Package {
  final String packageId;
  final String title;
  final String location;
  final String country;
  final double priceUsd;
  final int durationNights;
  final int durationDays;
  final double rating;
  final String videoUrl;
  final List<String> heroImageUrls;
  final List<String> galleryImageUrls;
  final List<String> itinerary;
  final List<Review> reviews;
  final Timestamp? createdAt;

  Package({
    required this.packageId,
    required this.title,
    required this.location,
    required this.country,
    required this.priceUsd,
    required this.durationNights,
    required this.durationDays,
    required this.rating,
    required this.videoUrl,
    required this.heroImageUrls,
    required this.galleryImageUrls,
    required this.itinerary,
    this.reviews = const [],
    this.createdAt,
  });

  factory Package.fromMap(Map<String, dynamic> map) {
    return Package(
      packageId: map['packageId'] ?? '',
      title: map['title'] ?? '',
      location: map['location'] ?? '',
      country: map['country'] ?? '',
      priceUsd: (map['priceUsd'] ?? 0).toDouble(),
      durationNights: map['durationNights'] ?? 0,
      durationDays: map['durationDays'] ?? 0,
      rating: (map['rating'] ?? 0).toDouble(),
      videoUrl: map['videoUrl'] ?? '',
      heroImageUrls: List<String>.from(map['heroImageUrls'] ?? []),
      galleryImageUrls: List<String>.from(map['galleryImageUrls'] ?? []),
      itinerary: List<String>.from(map['itinerary'] ?? []),
      reviews: (map['reviews'] as List<dynamic>? ?? [])
          .map((r) => Review.fromMap(r as Map<String, dynamic>))
          .toList(),
      createdAt: map['createdAt'],
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'packageId': packageId,
      'title': title,
      'location': location,
      'country': country,
      'priceUsd': priceUsd,
      'durationNights': durationNights,
      'durationDays': durationDays,
      'rating': rating,
      'videoUrl': videoUrl,
      'heroImageUrls': heroImageUrls,
      'galleryImageUrls': galleryImageUrls,
      'itinerary': itinerary,
      'reviews': reviews.map((r) => r.toMap()).toList(),
      'createdAt': createdAt,
    };
  }
}

class Review {
  final String reviewerName;
  final String? reviewerPhotoUrl;
  final String reviewerCountry;
  final double rating;
  final String comment;
  final Timestamp? createdAt;

  Review({
    required this.reviewerName,
    this.reviewerPhotoUrl,
    required this.reviewerCountry,
    required this.rating,
    required this.comment,
    this.createdAt,
  });

  factory Review.fromMap(Map<String, dynamic> map) {
    return Review(
      reviewerName: map['reviewerName'] ?? '',
      reviewerPhotoUrl: map['reviewerPhotoUrl'],
      reviewerCountry: map['reviewerCountry'] ?? '',
      rating: (map['rating'] ?? 0).toDouble(),
      comment: map['comment'] ?? '',
      createdAt: map['createdAt'],
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'reviewerName': reviewerName,
      'reviewerPhotoUrl': reviewerPhotoUrl,
      'reviewerCountry': reviewerCountry,
      'rating': rating,
      'comment': comment,
      'createdAt': createdAt,
    };
  }
}
