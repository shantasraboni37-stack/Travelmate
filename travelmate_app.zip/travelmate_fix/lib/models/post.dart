import 'package:cloud_firestore/cloud_firestore.dart';

class Post {
  final String postId;
  final String authorUid;
  final String authorName;
  final String? authorPhotoUrl;
  final String postType;
  final String text;
  final List<String> mediaUrls;
  final List<String> mediaTypes;
  final String? location;
  final Timestamp? tripDate;
  final bool isFlexibleDate;
  final String? budget;
  final String? duration;
  final String? travelingWith;
  final String? country;
  final List<String> interests;
  final Map<String, int> reactionsCount;
  final int commentsCount;
  final int savedCount;
  final bool isPinned;
  final String? guideCountry;
  final Timestamp? createdAt;
  final Timestamp? updatedAt;

  Post({
    required this.postId,
    required this.authorUid,
    required this.authorName,
    this.authorPhotoUrl,
    required this.postType,
    required this.text,
    this.mediaUrls = const [],
    this.mediaTypes = const [],
    this.location,
    this.tripDate,
    this.isFlexibleDate = false,
    this.budget,
    this.duration,
    this.travelingWith,
    this.country,
    this.interests = const [],
    this.reactionsCount = const {},
    this.commentsCount = 0,
    this.savedCount = 0,
    this.isPinned = false,
    this.guideCountry,
    this.createdAt,
    this.updatedAt,
  });

  factory Post.fromMap(Map<String, dynamic> map) {
    return Post(
      postId: map['postId'] ?? '',
      authorUid: map['authorUid'] ?? '',
      authorName: map['authorName'] ?? '',
      authorPhotoUrl: map['authorPhotoUrl'],
      postType: map['postType'] ?? 'community',
      text: map['text'] ?? '',
      mediaUrls: List<String>.from(map['mediaUrls'] ?? []),
      mediaTypes: List<String>.from(map['mediaTypes'] ?? []),
      location: map['location'],
      tripDate: map['tripDate'],
      isFlexibleDate: map['isFlexibleDate'] ?? false,
      budget: map['budget'],
      duration: map['duration'],
      travelingWith: map['travelingWith'],
      country: map['country'],
      interests: List<String>.from(map['interests'] ?? []),
      reactionsCount: Map<String, int>.from(map['reactionsCount'] ?? {}),
      commentsCount: map['commentsCount'] ?? 0,
      savedCount: map['savedCount'] ?? 0,
      isPinned: map['isPinned'] ?? false,
      guideCountry: map['guideCountry'],
      createdAt: map['createdAt'],
      updatedAt: map['updatedAt'],
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'postId': postId,
      'authorUid': authorUid,
      'authorName': authorName,
      'authorPhotoUrl': authorPhotoUrl,
      'postType': postType,
      'text': text,
      'mediaUrls': mediaUrls,
      'mediaTypes': mediaTypes,
      'location': location,
      'tripDate': tripDate,
      'isFlexibleDate': isFlexibleDate,
      'budget': budget,
      'duration': duration,
      'travelingWith': travelingWith,
      'country': country,
      'interests': interests,
      'reactionsCount': reactionsCount,
      'commentsCount': commentsCount,
      'savedCount': savedCount,
      'isPinned': isPinned,
      'guideCountry': guideCountry,
      'createdAt': createdAt,
      'updatedAt': updatedAt,
    };
  }
}
