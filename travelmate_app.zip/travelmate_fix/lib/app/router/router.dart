import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:firebase_auth/firebase_auth.dart';
import '../../features/auth/screens/auth_page.dart';
import '../../features/auth/screens/login_page.dart';
import '../../features/auth/screens/signup_page.dart';
import '../../features/auth/screens/phone_login_page.dart';
import '../../features/auth/screens/otp_page.dart';
import '../../features/auth/screens/forgot_password_page.dart';
import '../../features/setup/screens/setup_wizard_screen.dart';
import '../../features/buddies/screens/buddy_finder_screen.dart';
import '../../features/community/screens/community_screen.dart';
import '../../features/chats/screens/chat_inbox_screen.dart';
import '../../features/chats/screens/chat_detail_screen.dart';
import '../../features/packages/screens/packages_screen.dart';
import '../../features/packages/screens/package_detail_screen.dart';
import '../../features/packages/screens/bookings_screen.dart';
import '../../features/profile/screens/profile_screen.dart';
import '../../features/profile/screens/edit_profile_screen.dart';
import '../../features/settings/screens/settings_screen.dart';
import '../../features/notifications/screens/notifications_screen.dart';
import '../../features/cost_splitter/screens/cost_splitter_screen.dart';
import '../../features/cost_splitter/screens/splitter_room_screen.dart';
import '../../features/auth/providers/auth_provider.dart';

/// Router with auth guards and safe navigation
final routerProvider = Provider<GoRouter>((ref) {
  final authState = ref.watch(authStateProvider);
  final authNotifier = ref.watch(authNotifierProvider);

  return GoRouter(
    initialLocation: '/auth',
    debugLogDiagnostics: false,
    // Global error handler for navigation
    errorBuilder: (context, state) => Scaffold(
      body: Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Icon(Icons.error_outline, size: 64, color: Colors.grey),
            const SizedBox(height: 16),
            Text('Page not found', style: Theme.of(context).textTheme.headlineSmall),
            const SizedBox(height: 16),
            ElevatedButton(
              onPressed: () => context.go('/buddies'),
              child: const Text('Go Home'),
            ),
          ],
        ),
      ),
    ),
    redirect: (context, state) {
      final user = authState.valueOrNull;
      final status = authNotifier.status;

      final publicRoutes = ['/auth', '/login', '/signup', '/phone', '/otp', '/forgot'];
      final isPublicRoute = publicRoutes.contains(state.matchedLocation);

      // FIX 9: During initial loading state, don't redirect anywhere - show loading
      if (status == AuthStatus.initial || status == AuthStatus.loading) {
        // If we're on a public route, stay there while auth resolves
        if (isPublicRoute) return null;
        // For protected routes during initial state, redirect to auth
        // (user will be seamlessly redirected back once auth resolves)
        return '/auth';
      }

      // Explicitly unauthenticated -> must go to auth
      if ((user == null || status == AuthStatus.unauthenticated) && !isPublicRoute) {
        return '/auth';
      }

      // Logged in but needs setup -> go to setup
      if (user != null && status == AuthStatus.needsSetup && state.matchedLocation != '/setup') {
        return '/setup';
      }

      // Logged in + setup complete -> don't allow public routes
      if (user != null && status == AuthStatus.authenticated && isPublicRoute) {
        return '/buddies';
      }

      // No redirect needed
      return null;
    },
    routes: [
      // Auth routes (public)
      GoRoute(path: '/auth', builder: (_, __) => const AuthPage()),
      GoRoute(path: '/login', builder: (_, __) => const LoginPage()),
      GoRoute(path: '/signup', builder: (_, __) => const SignUpPage()),
      GoRoute(path: '/phone', builder: (_, __) => const PhoneLoginPage()),
      GoRoute(
        path: '/otp',
        builder: (_, state) {
          final vid = state.uri.queryParameters['vid'] ?? '';
          return OtpPage(verificationId: vid);
        },
      ),
      GoRoute(path: '/forgot', builder: (_, __) => const ForgotPasswordPage()),
      // Setup (auth required)
      GoRoute(path: '/setup', builder: (_, __) => const SetupWizardScreen()),
      // Main shell route with bottom nav
      ShellRoute(
        builder: (context, state, child) => ScaffoldWithNav(child: child),
        routes: [
          GoRoute(path: '/buddies', builder: (_, __) => const BuddyFinderScreen()),
          GoRoute(path: '/community', builder: (_, __) => const CommunityScreen()),
          GoRoute(path: '/chats', builder: (_, __) => const ChatInboxScreen()),
          GoRoute(path: '/packages', builder: (_, __) => const PackagesScreen()),
          GoRoute(path: '/profile', builder: (_, __) => const ProfileScreen()),
        ],
      ),
      // Detail routes (auth required)
      GoRoute(
        path: '/chat/:chatId',
        builder: (_, state) {
          final chatId = state.pathParameters['chatId'] ?? '';
          if (chatId.isEmpty) return const _ErrorScreen(message: 'Invalid chat ID');
          return ChatDetailScreen(chatId: chatId);
        },
      ),
      GoRoute(
        path: '/package/:packageId',
        builder: (_, state) {
          final packageId = state.pathParameters['packageId'] ?? '';
          if (packageId.isEmpty) return const _ErrorScreen(message: 'Invalid package ID');
          return PackageDetailScreen(packageId: packageId);
        },
      ),
      GoRoute(path: '/bookings', builder: (_, __) => const BookingsScreen()),
      GoRoute(path: '/edit-profile', builder: (_, __) => const EditProfileScreen()),
      GoRoute(path: '/settings', builder: (_, __) => const SettingsScreen()),
      GoRoute(path: '/notifications', builder: (_, __) => const NotificationsScreen()),
      GoRoute(path: '/cost-splitter', builder: (_, __) => const CostSplitterScreen()),
      GoRoute(
        path: '/splitter-room/:roomId',
        builder: (_, state) {
          final roomId = state.pathParameters['roomId'] ?? '';
          if (roomId.isEmpty) return const _ErrorScreen(message: 'Invalid room ID');
          return SplitterRoomScreen(roomId: roomId);
        },
      ),
    ],
  );
});

/// Error screen for invalid routes
class _ErrorScreen extends StatelessWidget {
  final String message;
  const _ErrorScreen({required this.message});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(),
      body: Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Icon(Icons.error_outline, size: 64, color: Colors.grey),
            const SizedBox(height: 16),
            Text(message),
            const SizedBox(height: 16),
            ElevatedButton(
              onPressed: () => context.go('/buddies'),
              child: const Text('Go Home'),
            ),
          ],
        ),
      ),
    );
  }
}

/// Scaffold with bottom navigation - fixed index
class ScaffoldWithNav extends StatelessWidget {
  final Widget child;
  const ScaffoldWithNav({super.key, required this.child});

  int _currentIndex(String location) {
    if (location.startsWith('/buddies')) return 0;
    if (location.startsWith('/community')) return 1;
    if (location.startsWith('/chats')) return 2;
    if (location.startsWith('/packages')) return 3;
    if (location.startsWith('/profile')) return 4;
    return 0;
  }

  void _onTap(int index, BuildContext context) {
    const routes = ['/buddies', '/community', '/chats', '/packages', '/profile'];
    context.go(routes[index]);
  }

  @override
  Widget build(BuildContext context) {
    final location = GoRouterState.of(context).matchedLocation;
    final idx = _currentIndex(location);

    return Scaffold(
      body: child,
      bottomNavigationBar: NavigationBar(
        selectedIndex: idx,
        onDestinationSelected: (i) => _onTap(i, context),
        destinations: const [
          NavigationDestination(
            icon: Icon(Icons.travel_explore_outlined),
            selectedIcon: Icon(Icons.travel_explore),
            label: 'Buddies',
          ),
          NavigationDestination(
            icon: Icon(Icons.groups_outlined),
            selectedIcon: Icon(Icons.groups),
            label: 'Community',
          ),
          NavigationDestination(
            icon: Icon(Icons.chat_bubble_outline),
            selectedIcon: Icon(Icons.chat_bubble),
            label: 'Chats',
          ),
          NavigationDestination(
            icon: Icon(Icons.card_travel_outlined),
            selectedIcon: Icon(Icons.card_travel),
            label: 'Packages',
          ),
          NavigationDestination(
            icon: Icon(Icons.person_outline),
            selectedIcon: Icon(Icons.person),
            label: 'Profile',
          ),
        ],
      ),
    );
  }
}
