import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

const _primary = Color(0xFFB0213F);
const _onPrimary = Color(0xFFFFFFFF);
const _surface = Color(0xFFF2F3F3);
const _cardBg = Color(0xFFFFFFFF);
const _dark = Color(0xFF1A1C1C);
const _textSub = Color(0xFF594042);
const _border = Color(0xFFE1BEC0);
const _primarySoft = Color(0xFFFFF0F2);
const _error = Color(0xFFBA1A1A);

ThemeData get lightTheme => ThemeData(
  useMaterial3: true,
  brightness: Brightness.light,
  colorScheme: ColorScheme.fromSeed(
    seedColor: _primary,
    primary: _primary,
    onPrimary: _onPrimary,
    surface: _surface,
    onSurface: _dark,
    error: _error,
    onError: Colors.white,
  ),
  scaffoldBackgroundColor: _surface,
  fontFamily: GoogleFonts.manrope().fontFamily,
  appBarTheme: AppBarTheme(
    backgroundColor: _cardBg,
    foregroundColor: _primary,
    elevation: 0,
    surfaceTintColor: Colors.transparent,
    centerTitle: true,
    titleTextStyle: GoogleFonts.manrope(
      fontSize: 22, fontWeight: FontWeight.w900, color: _primary,
    ),
  ),
  cardTheme: CardTheme(
    color: _cardBg,
    elevation: 0,
    shape: RoundedRectangleBorder(
      borderRadius: BorderRadius.circular(18),
      side: const BorderSide(color: _border, width: 1.5),
    ),
    margin: const EdgeInsets.symmetric(vertical: 6),
  ),
  inputDecorationTheme: InputDecorationTheme(
    filled: true,
    fillColor: _cardBg,
    contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
    border: OutlineInputBorder(
      borderRadius: BorderRadius.circular(14),
      borderSide: const BorderSide(color: _border, width: 1.5),
    ),
    enabledBorder: OutlineInputBorder(
      borderRadius: BorderRadius.circular(14),
      borderSide: const BorderSide(color: _border, width: 1.5),
    ),
    focusedBorder: OutlineInputBorder(
      borderRadius: BorderRadius.circular(14),
      borderSide: const BorderSide(color: _primary, width: 2),
    ),
    labelStyle: const TextStyle(color: _textSub),
    hintStyle: TextStyle(color: _textSub.withOpacity(0.6)),
  ),
  elevatedButtonTheme: ElevatedButtonThemeData(
    style: ElevatedButton.styleFrom(
      backgroundColor: _primary,
      foregroundColor: _onPrimary,
      minimumSize: const Size(double.infinity, 52),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
      textStyle: GoogleFonts.manrope(fontSize: 16, fontWeight: FontWeight.w700),
    ),
  ),
  outlinedButtonTheme: OutlinedButtonThemeData(
    style: OutlinedButton.styleFrom(
      foregroundColor: _primary,
      side: const BorderSide(color: _primary, width: 1.5),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
    ),
  ),
  textButtonTheme: TextButtonThemeData(
    style: TextButton.styleFrom(foregroundColor: _primary),
  ),
  tabBarTheme: TabBarTheme(
    labelColor: _primary,
    unselectedLabelColor: _textSub,
    indicatorColor: _primary,
    indicatorSize: TabBarIndicatorSize.tab,
    labelStyle: GoogleFonts.manrope(fontSize: 13, fontWeight: FontWeight.w700),
    unselectedLabelStyle: GoogleFonts.manrope(fontSize: 13, fontWeight: FontWeight.w500),
  ),
  chipTheme: ChipThemeData(
    backgroundColor: _surface,
    selectedColor: _primarySoft,
    side: const BorderSide(color: _border),
    labelStyle: GoogleFonts.manrope(fontSize: 13, fontWeight: FontWeight.w600),
    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
    shape: const StadiumBorder(),
  ),
  bottomSheetTheme: const BottomSheetThemeData(
    backgroundColor: _cardBg,
    shape: RoundedRectangleBorder(
      borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
    ),
  ),
  snackBarTheme: SnackBarThemeData(
    backgroundColor: _dark,
    contentTextStyle: GoogleFonts.manrope(color: Colors.white, fontSize: 13),
    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
    behavior: SnackBarBehavior.floating,
  ),
  dividerTheme: const DividerThemeData(color: _border, thickness: 1),
);

// Dark theme
ThemeData get darkTheme => ThemeData(
  useMaterial3: true,
  brightness: Brightness.dark,
  colorScheme: ColorScheme.fromSeed(
    seedColor: _primary,
    primary: _primary,
    onPrimary: _onPrimary,
    surface: const Color(0xFF2A2C2C),
    onSurface: Colors.white,
    error: _error,
    onError: Colors.white,
    brightness: Brightness.dark,
  ),
  scaffoldBackgroundColor: const Color(0xFF1E2020),
  fontFamily: GoogleFonts.manrope().fontFamily,
  appBarTheme: AppBarTheme(
    backgroundColor: const Color(0xFF2A2C2C),
    foregroundColor: _primary,
    elevation: 0,
    surfaceTintColor: Colors.transparent,
    centerTitle: true,
    titleTextStyle: GoogleFonts.manrope(
      fontSize: 22, fontWeight: FontWeight.w900, color: _primary,
    ),
  ),
  cardTheme: CardTheme(
    color: const Color(0xFF2A2C2C),
    elevation: 0,
    shape: RoundedRectangleBorder(
      borderRadius: BorderRadius.circular(18),
      side: const BorderSide(color: Color(0xFF3A3C3C), width: 1.5),
    ),
    margin: const EdgeInsets.symmetric(vertical: 6),
  ),
  inputDecorationTheme: InputDecorationTheme(
    filled: true,
    fillColor: const Color(0xFF2A2C2C),
    contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
    border: OutlineInputBorder(
      borderRadius: BorderRadius.circular(14),
      borderSide: const BorderSide(color: Color(0xFF3A3C3C), width: 1.5),
    ),
    enabledBorder: OutlineInputBorder(
      borderRadius: BorderRadius.circular(14),
      borderSide: const BorderSide(color: Color(0xFF3A3C3C), width: 1.5),
    ),
    focusedBorder: OutlineInputBorder(
      borderRadius: BorderRadius.circular(14),
      borderSide: const BorderSide(color: _primary, width: 2),
    ),
  ),
  elevatedButtonTheme: ElevatedButtonThemeData(
    style: ElevatedButton.styleFrom(
      backgroundColor: _primary,
      foregroundColor: _onPrimary,
      minimumSize: const Size(double.infinity, 52),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
      textStyle: GoogleFonts.manrope(fontSize: 16, fontWeight: FontWeight.w700),
    ),
  ),
  chipTheme: ChipThemeData(
    backgroundColor: const Color(0xFF3A3C3C),
    selectedColor: _primarySoft,
    side: const BorderSide(color: Color(0xFF4A4C4C)),
    labelStyle: GoogleFonts.manrope(fontSize: 13, fontWeight: FontWeight.w600),
    shape: const StadiumBorder(),
  ),
  bottomSheetTheme: const BottomSheetThemeData(
    backgroundColor: Color(0xFF2A2C2C),
    shape: RoundedRectangleBorder(
      borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
    ),
  ),
);
