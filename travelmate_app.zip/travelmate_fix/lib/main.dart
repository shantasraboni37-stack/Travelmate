import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_stripe/flutter_stripe.dart';
import 'app/router/router.dart';
import 'app/theme/app_theme.dart';
import 'core/constants/app_constants.dart';
import 'core/services/fcm_service.dart';
import 'firebase_options.dart';

/// Background FCM handler - MUST be top-level function
@pragma('vm:entry-point')
Future<void> _firebaseMessagingBackgroundHandler(RemoteMessage message) async {
  // Ensure Firebase is initialized in background isolate
  await Firebase.initializeApp(
    options: DefaultFirebaseOptions.currentPlatform,
  );
  // Handle background message silently - local notifications
  // will be shown by FcmService when app comes foreground
}

void main() async {
  // Ensure Flutter binding is initialized before any platform calls
  WidgetsFlutterBinding.ensureInitialized();

  // Lock to portrait orientation
  await SystemChrome.setPreferredOrientations([
    DeviceOrientation.portraitUp,
    DeviceOrientation.portraitDown,
  ]);

  // Status bar style
  SystemChrome.setSystemUIOverlayStyle(
    const SystemUiOverlayStyle(
      statusBarColor: Colors.transparent,
      statusBarIconBrightness: Brightness.dark,
      statusBarBrightness: Brightness.light,
    ),
  );

  // Initialize Firebase with error handling
  try {
    await Firebase.initializeApp(
      options: DefaultFirebaseOptions.currentPlatform,
    );
  } catch (e) {
    debugPrint('Firebase initialization error: $e');
    // Run app anyway - auth guards will handle unauthenticated state
  }

  // Register FCM background handler BEFORE runApp
  FirebaseMessaging.onBackgroundMessage(_firebaseMessagingBackgroundHandler);

  // Initialize Stripe
  Stripe.publishableKey = AppConstants.stripePublishableKey;

  runApp(const ProviderScope(child: TravelMateApp()));
}

class TravelMateApp extends ConsumerStatefulWidget {
  const TravelMateApp({super.key});

  @override
  ConsumerState<TravelMateApp> createState() => _TravelMateAppState();
}

class _TravelMateAppState extends ConsumerState<TravelMateApp> {
  @override
  void initState() {
    super.initState();
    // Initialize FCM after first frame when context is available
    WidgetsBinding.instance.addPostFrameCallback((_) async {
      try {
        await FcmService.initialize(ref);
      } catch (e) {
        debugPrint('FCM initialization error: $e');
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    final router = ref.watch(routerProvider);

    return MaterialApp.router(
      title: 'TravelMate',
      debugShowCheckedModeBanner: false,
      theme: lightTheme,
      darkTheme: darkTheme,
      themeMode: ThemeMode.system,
      routerConfig: router,
    );
  }
}
