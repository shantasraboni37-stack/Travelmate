import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../core/repositories/package_repository.dart';
import '../../../models/package.dart';

class PackagesState {
  final List<Package> packages;
  final bool isLoading;
  final String? error;

  const PackagesState({
    this.packages = const [],
    this.isLoading = false,
    this.error,
  });

  PackagesState copyWith({
    List<Package>? packages,
    bool? isLoading,
    String? error,
  }) {
    return PackagesState(
      packages: packages ?? this.packages,
      isLoading: isLoading ?? this.isLoading,
      error: error ?? this.error,
    );
  }
}

class PackagesNotifier extends StateNotifier<PackagesState> {
  final PackageRepository _repository;

  PackagesNotifier(this._repository) : super(const PackagesState(isLoading: true));

  void loadPackages() {
    try {
      state = state.copyWith(isLoading: true, error: null);
      _repository.getPackages().listen(
        (packages) {
          if (mounted) state = state.copyWith(packages: packages, isLoading: false);
        },
        onError: (e) {
          if (mounted) state = state.copyWith(error: e.toString(), isLoading: false);
        },
      );
    } catch (e) {
      state = state.copyWith(error: e.toString(), isLoading: false);
    }
  }
}

final packagesProvider = StateNotifierProvider<PackagesNotifier, PackagesState>((ref) {
  return PackagesNotifier(PackageRepository())..loadPackages();
});

// Single package detail provider
final packageDetailProvider = StreamProvider.family<Package?, String>((ref, packageId) {
  return PackageRepository().getPackageStream(packageId);
});
