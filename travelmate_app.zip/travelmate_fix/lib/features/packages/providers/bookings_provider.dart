import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../core/repositories/booking_repository.dart';
import '../../../models/booking.dart';

class BookingsState {
  final List<Booking> bookings;
  final bool isLoading;
  final String? error;

  const BookingsState({
    this.bookings = const [],
    this.isLoading = false,
    this.error,
  });

  BookingsState copyWith({
    List<Booking>? bookings,
    bool? isLoading,
    String? error,
  }) {
    return BookingsState(
      bookings: bookings ?? this.bookings,
      isLoading: isLoading ?? this.isLoading,
      error: error ?? this.error,
    );
  }
}

class BookingsNotifier extends StateNotifier<BookingsState> {
  final BookingRepository _repository;

  BookingsNotifier(this._repository) : super(const BookingsState(isLoading: true));

  void loadBookings() {
    try {
      state = state.copyWith(isLoading: true, error: null);
      _repository.getUserBookings().listen(
        (bookings) {
          if (mounted) state = state.copyWith(bookings: bookings, isLoading: false);
        },
        onError: (e) {
          if (mounted) state = state.copyWith(error: e.toString(), isLoading: false);
        },
      );
    } catch (e) {
      state = state.copyWith(error: e.toString(), isLoading: false);
    }
  }
}

final bookingsProvider = StateNotifierProvider<BookingsNotifier, BookingsState>((ref) {
  return BookingsNotifier(BookingRepository())..loadBookings();
});
