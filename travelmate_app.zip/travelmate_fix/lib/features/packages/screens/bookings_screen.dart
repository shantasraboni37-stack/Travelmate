import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../core/utils/error_handler.dart';
import '../../../core/utils/helpers.dart';
import '../../../core/widgets/empty_states.dart';
import '../providers/bookings_provider.dart';

class BookingsScreen extends ConsumerWidget {
  const BookingsScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final state = ref.watch(bookingsProvider);

    if (state.error != null) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        showErrorSnack(context, state.error);
      });
    }

    return Scaffold(
      appBar: AppBar(title: const Text('My Bookings')),
      body: state.isLoading
          ? const Center(child: CircularProgressIndicator())
          : state.bookings.isEmpty
              ? const EmptyStateWidget(
                  icon: Icons.receipt_long_outlined,
                  title: 'No Bookings Yet',
                  subtitle: 'Your travel bookings will appear here.')
              : ListView.builder(
                  itemCount: state.bookings.length,
                  itemBuilder: (context, index) {
                    final booking = state.bookings[index];
                    return _BookingCard(booking: booking);
                  },
                ),
    );
  }
}

class _BookingCard extends StatelessWidget {
  final dynamic booking;
  const _BookingCard({required this.booking});

  @override
  Widget build(BuildContext context) {
    return Card(
      child: ListTile(
        contentPadding: const EdgeInsets.all(16),
        title: Text(booking.packageName, style: const TextStyle(fontWeight: FontWeight.w700)),
        subtitle: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const SizedBox(height: 8),
          Text('Participants: ${booking.participants}'),
          Text('Total: ${Helpers.formatCurrency(booking.totalAmountUsd)}'),
          const SizedBox(height: 8),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
            decoration: BoxDecoration(
              color: booking.status == 'confirmed'
                  ? Colors.green.withOpacity(0.1) : Colors.orange.withOpacity(0.1),
              borderRadius: BorderRadius.circular(8)),
            child: Text(booking.status.toUpperCase(),
              style: TextStyle(
                color: booking.status == 'confirmed' ? Colors.green : Colors.orange,
                fontWeight: FontWeight.w700, fontSize: 12)),
          ),
        ]),
      ),
    );
  }
}
