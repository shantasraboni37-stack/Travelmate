import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_stripe/flutter_stripe.dart';
import '../../../core/services/worker_api_service.dart';
import '../../../core/utils/error_handler.dart';
import '../../../core/services/r2_service.dart';
import '../providers/packages_provider.dart';

class PackageDetailScreen extends ConsumerStatefulWidget {
  final String packageId;
  const PackageDetailScreen({super.key, required this.packageId});

  @override
  ConsumerState<PackageDetailScreen> createState() => _PackageDetailScreenState();
}

class _PackageDetailScreenState extends ConsumerState<PackageDetailScreen> {
  int _participants = 1;
  bool _isBooking = false;

  Future<void> _bookNow(double price, String packageName) async {
    final total = price * _participants;
    setState(() => _isBooking = true);

    try {
      // Step 1: Create payment intent via WorkerApiService (with auth token)
      final clientSecret = await WorkerApiService.createPaymentIntent(
        amountUsd: total,
        packageName: packageName,
        bookingType: 'package',
      );
      if (clientSecret.isEmpty) {
        throw Exception('Failed to create payment intent');
      }

      // Step 2: Present Stripe payment sheet
      await Stripe.instance.initPaymentSheet(
        paymentSheetParameters: SetupPaymentSheetParameters(
          paymentIntentClientSecret: clientSecret,
          merchantDisplayName: 'TravelMate',
          style: ThemeMode.system,
        ),
      );
      await Stripe.instance.presentPaymentSheet();

      // Step 3: Confirm booking on backend via WorkerApiService
      final piId = clientSecret.split('_secret').first;
      await WorkerApiService.confirmBooking(
        paymentIntentId: piId,
        packageId: widget.packageId,
        packageName: packageName,
        participants: _participants,
        totalAmountUsd: total,
        bookingType: 'package',
      );

      if (mounted) {
        showSuccessSnack(context, 'Booking confirmed!');
      }
    } on StripeException catch (e) {
      if (mounted) showErrorSnack(context, 'Payment cancelled: ${e.error.localizedMessage}');
    } catch (e) {
      if (mounted) showErrorSnack(context, e);
    } finally {
      if (mounted) setState(() => _isBooking = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final asyncPackage = ref.watch(packageDetailProvider(widget.packageId));

    // FIX 16: Single Scaffold wrapping all states
    return Scaffold(
      body: asyncPackage.when(
        data: (package) {
          if (package == null) {
            return const Center(child: Text('Package not found'));
          }
          return CustomScrollView(slivers: [
            SliverAppBar(
              expandedHeight: 250, pinned: true,
              flexibleSpace: FlexibleSpaceBar(
                background: _buildHeroGallery(package.heroImageUrls),
              ),
            ),
            SliverPadding(
              padding: const EdgeInsets.all(16),
              sliver: SliverList(
                delegate: SliverChildListDelegate([
                  _buildHeader(package),
                  const SizedBox(height: 16),
                  _buildDetails(package),
                  const SizedBox(height: 16),
                  if (package.itinerary.isNotEmpty) _buildItinerary(package),
                  if (package.reviews.isNotEmpty) _buildReviews(package),
                  const SizedBox(height: 16),
                  _buildBookingSection(package),
                ]),
              ),
            ),
          ]);
        },
        loading: () => const Center(child: CircularProgressIndicator()),
        error: (err, _) {
          WidgetsBinding.instance.addPostFrameCallback((_) {
            showErrorSnack(context, err);
          });
          return Center(child: Column(mainAxisSize: MainAxisSize.min, children: [
            const Icon(Icons.error_outline, size: 64, color: Colors.grey),
            const SizedBox(height: 16),
            Text('Error: $err'),
          ]));
        },
      ),
    );
  }

  Widget _buildHeroGallery(List<String> images) {
    if (images.isEmpty) return Container(color: Colors.grey[300], child: const Icon(Icons.image, size: 64));
    return PageView.builder(
      itemCount: images.length,
      itemBuilder: (context, index) => Image.network(
        images[index], fit: BoxFit.cover,
        errorBuilder: (_, __, ___) => Container(color: Colors.grey[300], child: const Icon(Icons.broken_image, size: 64)),
      ),
    );
  }

  Widget _buildHeader(dynamic package) {
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Text(package.title, style: Theme.of(context).textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.w800)),
      const SizedBox(height: 8),
      Row(children: [
        const Icon(Icons.location_on, size: 16, color: Color(0xFFB0213F)),
        const SizedBox(width: 4),
        Text(package.country),
        const SizedBox(width: 16),
        const Icon(Icons.star, size: 16, color: Colors.amber),
        Text('${package.rating}'),
      ]),
    ]);
  }

  Widget _buildDetails(dynamic package) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Row(mainAxisAlignment: MainAxisAlignment.spaceAround, children: [
          _DetailItem(icon: Icons.nightlight_round, label: '${package.durationNights} Nights'),
          _DetailItem(icon: Icons.wb_sunny, label: '${package.durationDays} Days'),
          _DetailItem(icon: Icons.attach_money, label: '\$${package.priceUsd.toStringAsFixed(0)}'),
        ]),
      ),
    );
  }

  Widget _buildItinerary(dynamic package) {
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Text('Itinerary', style: Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.w800)),
      const SizedBox(height: 12),
      ...package.itinerary.asMap().entries.map((entry) => ListTile(
        leading: CircleAvatar(
          backgroundColor: const Color(0xFFB0213F).withOpacity(0.1),
          child: Text('${entry.key + 1}')),
        title: Text(entry.value),
      )),
    ]);
  }

  Widget _buildReviews(dynamic package) {
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Text('Reviews', style: Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.w800)),
      const SizedBox(height: 12),
      ...package.reviews.map((r) => _ReviewCard(review: r)),
    ]);
  }

  Widget _buildBookingSection(dynamic package) {
    final total = package.priceUsd * _participants;
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Text('Book This Trip', style: Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.w800)),
      const SizedBox(height: 12),
      Row(children: [
        const Text('Participants:'), const Spacer(),
        IconButton(
          icon: const Icon(Icons.remove_circle_outline),
          onPressed: _participants > 1 ? () => setState(() => _participants--) : null),
        Text('$_participants', style: const TextStyle(fontWeight: FontWeight.w700)),
        IconButton(
          icon: const Icon(Icons.add_circle_outline),
          onPressed: () => setState(() => _participants++)),
      ]),
      const SizedBox(height: 8),
      Row(children: [
        const Text('Total:', style: TextStyle(fontSize: 16)), const Spacer(),
        Text('\$${total.toStringAsFixed(2)}',
          style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w800, color: Color(0xFFB0213F))),
      ]),
      const SizedBox(height: 16),
      if (_isBooking)
        const Center(child: CircularProgressIndicator())
      else
        ElevatedButton(
          onPressed: () => _bookNow(package.priceUsd, package.title),
          child: const Text('Book Now'),
        ),
    ]);
  }
}

class _DetailItem extends StatelessWidget {
  final IconData icon;
  final String label;
  const _DetailItem({required this.icon, required this.label});

  @override
  Widget build(BuildContext context) {
    return Column(children: [
      Icon(icon, color: const Color(0xFFB0213F)),
      const SizedBox(height: 4),
      Text(label, style: const TextStyle(fontWeight: FontWeight.w600)),
    ]);
  }
}

class _ReviewCard extends StatelessWidget {
  final dynamic review;
  const _ReviewCard({required this.review});

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [
            Text(review.reviewerName ?? '', style: const TextStyle(fontWeight: FontWeight.w700)),
            const Spacer(),
            Row(children: List.generate(5, (i) {
              return Icon(i < (review.rating ?? 0) ? Icons.star : Icons.star_border,
                size: 14, color: Colors.amber);
            })),
          ]),
          const SizedBox(height: 8),
          Text(review.comment ?? ''),
        ]),
      ),
    );
  }
}
      const SizedBox(height: 8),
          Text(review.comment ?? ''),
        ]),
      ),
    );
  }
}
