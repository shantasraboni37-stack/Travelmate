import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import '../../../core/utils/error_handler.dart';
import '../../../core/widgets/empty_states.dart';
import '../../../core/widgets/shimmer_cards.dart';
import '../providers/packages_provider.dart';

class PackagesScreen extends ConsumerWidget {
  const PackagesScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final state = ref.watch(packagesProvider);

    if (state.error != null) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        showErrorSnack(context, state.error);
      });
    }

    return Scaffold(
      appBar: AppBar(
        title: const Text('Packages'),
        actions: [
          IconButton(
            icon: const Icon(Icons.shopping_bag_outlined),
            onPressed: () => context.push('/bookings'),
          ),
        ],
      ),
      body: state.isLoading
          ? const SkeletonFeedList(cardBuilder: PackageCardSkeleton.new)
          : state.packages.isEmpty
              ? const EmptyPackages()
              : ListView.builder(
                  itemCount: state.packages.length,
                  itemBuilder: (context, index) {
                    final pkg = state.packages[index];
                    return _PackageCard(package: pkg);
                  },
                ),
    );
  }
}

class _PackageCard extends StatelessWidget {
  final dynamic package;
  const _PackageCard({required this.package});

  @override
  Widget build(BuildContext context) {
    return Card(
      clipBehavior: Clip.antiAlias,
      child: InkWell(
        onTap: () => context.push('/package/${package.packageId}'),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          if (package.heroImageUrls.isNotEmpty)
            Image.network(
              package.heroImageUrls.first,
              height: 200, width: double.infinity, fit: BoxFit.cover,
              errorBuilder: (_, __, ___) => Container(
                height: 200, color: Colors.grey[300],
                child: const Icon(Icons.image, size: 48)),
            ),
          Padding(
            padding: const EdgeInsets.all(16),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Row(children: [
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                  decoration: BoxDecoration(
                    color: const Color(0xFFB0213F).withOpacity(0.1),
                    borderRadius: BorderRadius.circular(8)),
                  child: Text(package.country.toUpperCase(),
                    style: const TextStyle(color: Color(0xFFB0213F), fontSize: 11, fontWeight: FontWeight.w700)),
                ),
                const Spacer(),
                const Icon(Icons.star, size: 16, color: Colors.amber),
                const SizedBox(width: 4),
                Text(package.rating.toStringAsFixed(1),
                  style: const TextStyle(fontWeight: FontWeight.w700)),
              ]),
              const SizedBox(height: 8),
              Text(package.title,
                style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w700)),
              const SizedBox(height: 8),
              Row(children: [
                Icon(Icons.nightlight_round, size: 14, color: Colors.grey[600]),
                const SizedBox(width: 4),
                Text('${package.durationNights} nights', style: TextStyle(fontSize: 13, color: Colors.grey[600])),
                const SizedBox(width: 16),
                Icon(Icons.wb_sunny_outlined, size: 14, color: Colors.grey[600]),
                const SizedBox(width: 4),
                Text('${package.durationDays} days', style: TextStyle(fontSize: 13, color: Colors.grey[600])),
                const Spacer(),
                Text('\$${package.priceUsd.toStringAsFixed(0)}',
                  style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800, color: Color(0xFFB0213F))),
              ]),
            ]),
          ),
        ]),
      ),
    );
  }
}
