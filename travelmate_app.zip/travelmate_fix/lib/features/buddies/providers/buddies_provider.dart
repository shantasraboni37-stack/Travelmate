import 'dart:async';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../core/repositories/post_repository.dart';
import '../../../core/services/worker_api_service.dart';
import '../../../models/post.dart';

/// State for buddies feed
class BuddiesState {
  final List<Post> posts;
  final bool isLoading;
  final String? error;
  final bool isCreating;

  const BuddiesState({
    this.posts = const [],
    this.isLoading = false,
    this.error,
    this.isCreating = false,
  });

  BuddiesState copyWith({
    List<Post>? posts,
    bool? isLoading,
    String? error,
    bool? isCreating,
  }) {
    return BuddiesState(
      posts: posts ?? this.posts,
      isLoading: isLoading ?? this.isLoading,
      error: error ?? this.error,
      isCreating: isCreating ?? this.isCreating,
    );
  }
}

class BuddiesNotifier extends StateNotifier<BuddiesState> {
  final PostRepository _repository;
  StreamSubscription<List<Post>>? _postsSub;

  BuddiesNotifier(this._repository) : super(const BuddiesState(isLoading: true));

  /// Load buddy finder posts - with Worker feed ranking for personalization
  void loadPosts() {
    try {
      state = state.copyWith(isLoading: true, error: null);
      _postsSub?.cancel(); // Cancel previous subscription before creating new one
      _postsSub = _repository.getBuddyFinderPosts().listen(
        (posts) async {
          if (!mounted) return;

          // Get current user data for ranking
          final uid = FirebaseAuth.instance.currentUser?.uid;
          if (uid != null && posts.isNotEmpty) {
            try {
              final userDoc = await FirebaseFirestore.instance
                  .collection('users')
                  .doc(uid)
                  .get();
              final userData = userDoc.data();
              final viewerCountry = userData?['country'] as String? ?? '';
              final viewerInterests = List<String>.from(userData?['interests'] ?? []);

              // Call Worker API to rank feed
              final postMaps = posts.map((p) => {
                'postId': p.postId,
                'authorUid': p.authorUid,
                'text': p.text,
                'country': p.country ?? '',
                'interests': p.interests ?? [],
                'createdAt': p.createdAt?.millisecondsSinceEpoch ?? 0,
              }).toList();

              final ranked = await WorkerApiService.rankFeed(
                posts: postMaps,
                viewerCountry: viewerCountry,
                viewerInterests: viewerInterests,
              );

              // Sort posts based on ranked order
              final rankedIds = ranked.map((r) => r['postId'] as String).toList();
              final sortedPosts = List<Post>.from(posts)
                ..sort((a, b) {
                  final aIndex = rankedIds.indexOf(a.postId);
                  final bIndex = rankedIds.indexOf(b.postId);
                  if (aIndex == -1 && bIndex == -1) return 0;
                  if (aIndex == -1) return 1;
                  if (bIndex == -1) return -1;
                  return aIndex.compareTo(bIndex);
                });

              if (mounted) {
                state = state.copyWith(posts: sortedPosts, isLoading: false);
              }
            } catch (e) {
              // If ranking fails, fall back to raw Firestore order
              if (mounted) {
                state = state.copyWith(posts: posts, isLoading: false);
              }
            }
          } else {
            // No user or no posts - use raw order
            if (mounted) {
              state = state.copyWith(posts: posts, isLoading: false);
            }
          }
        },
        onError: (e) {
          if (mounted) {
            state = state.copyWith(error: e.toString(), isLoading: false);
          }
        },
      );
    } catch (e) {
      state = state.copyWith(error: e.toString(), isLoading: false);
    }
  }

  /// Create a buddy finder post
  Future<bool> createPost({
    required String text,
    String? location,
    String? budget,
    bool isFlexibleDate = false,
  }) async {
    try {
      state = state.copyWith(isCreating: true, error: null);
      final uid = FirebaseAuth.instance.currentUser?.uid;
      if (uid == null) throw Exception('Not logged in');

      final userDoc = await FirebaseFirestore.instance
          .collection('users')
          .doc(uid)
          .get();
      final userData = userDoc.data();

      final post = Post(
        postId: '',
        authorUid: uid,
        authorName: userData?['displayName'] ?? 'Unknown',
        authorPhotoUrl: userData?['profilePicUrl'],
        postType: 'buddy_finder',
        text: text,
        location: location,
        budget: budget,
        isFlexibleDate: isFlexibleDate,
        country: userData?['country'],
        interests: List<String>.from(userData?['interests'] ?? []),
      );

      await _repository.createPost(post);
      state = state.copyWith(isCreating: false);
      return true;
    } catch (e) {
      state = state.copyWith(error: e.toString(), isCreating: false);
      return false;
    }
  }

  /// Toggle like on a post
  Future<void> toggleLike(String postId) async {
    try {
      final uid = FirebaseAuth.instance.currentUser?.uid;
      if (uid == null) return;
      await _repository.toggleLike(postId, uid);
    } catch (e) {
      state = state.copyWith(error: e.toString());
    }
  }

  @override
  void dispose() {
    _postsSub?.cancel();
    super.dispose();
  }
}

final buddiesProvider = StateNotifierProvider<BuddiesNotifier, BuddiesState>((ref) {
  return BuddiesNotifier(PostRepository())..loadPosts();
});
