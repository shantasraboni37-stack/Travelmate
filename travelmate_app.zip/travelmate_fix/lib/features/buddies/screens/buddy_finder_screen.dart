import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:timeago/timeago.dart' as timeago;
import '../../../core/utils/error_handler.dart';
import '../../../core/widgets/auth_image.dart';
import '../../../core/widgets/empty_states.dart';
import '../../../core/widgets/shimmer_cards.dart';
import '../providers/buddies_provider.dart';

class BuddyFinderScreen extends ConsumerWidget {
  const BuddyFinderScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final state = ref.watch(buddiesProvider);

    // Show error if any
    if (state.error != null) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        showErrorSnack(context, state.error);
      });
    }

    return Scaffold(
      appBar: AppBar(
        title: const Text('Find a Buddy'),
        actions: [
          IconButton(
            icon: const Icon(Icons.add_circle_outline),
            onPressed: () => _showCreatePost(context, ref),
          ),
        ],
      ),
      body: state.isLoading
          ? const SkeletonFeedList(cardBuilder: BuddyCardSkeleton.new)
          : state.posts.isEmpty
              ? EmptyBuddyFeed(onPostTrip: () => _showCreatePost(context, ref))
              : ListView.builder(
                  itemCount: state.posts.length,
                  itemBuilder: (context, index) {
                    final post = state.posts[index];
                    return _BuddyPostCard(post: post);
                  },
                ),
    );
  }

  void _showCreatePost(BuildContext context, WidgetRef ref) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      builder: (_) => _CreateBuddyPostSheet(ref: ref),
    );
  }
}

class _BuddyPostCard extends StatelessWidget {
  final dynamic post;
  const _BuddyPostCard({required this.post});

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(children: [
              AuthCircleAvatar(
                imageUrl: post.authorPhotoUrl,
                radius: 20,
                fallbackText: post.authorName.isNotEmpty ? post.authorName[0].toUpperCase() : '?',
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(post.authorName, style: const TextStyle(fontWeight: FontWeight.w700)),
                    Text(
                      post.createdAt != null ? timeago.format(post.createdAt!.toDate()) : '',
                      style: TextStyle(fontSize: 12, color: Colors.grey[600]),
                    ),
                  ],
                ),
              ),
            ]),
            const SizedBox(height: 12),
            Text(post.text),
            if (post.location != null) ...[
              const SizedBox(height: 8),
              Row(children: [
                const Icon(Icons.location_on, size: 16, color: Colors.grey),
                const SizedBox(width: 4),
                Text('${post.location}', style: TextStyle(color: Colors.grey[600], fontSize: 13)),
              ]),
            ],
            if (post.budget != null && post.budget!.isNotEmpty) ...[
              const SizedBox(height: 4),
              Row(children: [
                const Icon(Icons.attach_money, size: 16, color: Colors.grey),
                const SizedBox(width: 4),
                Text('Budget: ${post.budget}', style: TextStyle(color: Colors.grey[600], fontSize: 13)),
              ]),
            ]),
            if (post.isFlexibleDate) ...[
              const SizedBox(height: 4),
              Row(children: [
                const Icon(Icons.calendar_today, size: 16, color: Colors.grey),
                const SizedBox(width: 4),
                Text('Flexible dates', style: TextStyle(color: Colors.grey[600], fontSize: 13)),
              ]),
            ],
            const SizedBox(height: 12),
            Row(children: [
              _ActionButton(
                icon: Icons.favorite_border,
                label: '${post.reactionsCount['like'] ?? 0}',
                onTap: () {},
              ),
              const SizedBox(width: 16),
              _ActionButton(icon: Icons.comment_outlined, label: '${post.commentsCount}', onTap: () {}),
              const SizedBox(width: 16),
              _ActionButton(icon: Icons.bookmark_border, label: '${post.savedCount}', onTap: () {}),
            ]),
          ],
        ),
      ),
    );
  }
}

class _ActionButton extends StatelessWidget {
  final IconData icon;
  final String label;
  final VoidCallback onTap;
  const _ActionButton({required this.icon, required this.label, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(8),
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
        child: Row(mainAxisSize: MainAxisSize.min, children: [
          Icon(icon, size: 18, color: Colors.grey[600]),
          const SizedBox(width: 4),
          Text(label, style: TextStyle(color: Colors.grey[600], fontSize: 13)),
        ]),
      ),
    );
  }
}

class _CreateBuddyPostSheet extends ConsumerStatefulWidget {
  final WidgetRef ref;
  const _CreateBuddyPostSheet({required this.ref});

  @override
  ConsumerState<_CreateBuddyPostSheet> createState() => _CreateBuddyPostSheetState();
}

class _CreateBuddyPostSheetState extends ConsumerState<_CreateBuddyPostSheet> {
  final _textCtrl = TextEditingController();
  final _locationCtrl = TextEditingController();
  final _budgetCtrl = TextEditingController();
  bool _isFlexible = false;

  @override
  void dispose() {
    _textCtrl.dispose();
    _locationCtrl.dispose();
    _budgetCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final state = ref.watch(buddiesProvider);

    return Padding(
      padding: EdgeInsets.only(
        bottom: MediaQuery.of(context).viewInsets.bottom,
        left: 24, right: 24, top: 24,
      ),
      child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text('Post a Trip', style: Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.w800)),
        const SizedBox(height: 16),
        TextField(controller: _textCtrl, maxLines: 3,
          decoration: const InputDecoration(hintText: 'Describe your trip plan...')),
        const SizedBox(height: 12),
        TextField(controller: _locationCtrl,
          decoration: const InputDecoration(hintText: 'Destination', prefixIcon: Icon(Icons.location_on_outlined))),
        const SizedBox(height: 12),
        TextField(controller: _budgetCtrl, keyboardType: TextInputType.number,
          decoration: const InputDecoration(hintText: 'Budget (USD)', prefixIcon: Icon(Icons.attach_money))),
        SwitchListTile(
          title: const Text('Flexible dates'),
          value: _isFlexible,
          onChanged: (v) => setState(() => _isFlexible = v),
        ),
        const SizedBox(height: 16),
        if (state.isCreating)
          const Center(child: CircularProgressIndicator())
        else
          ElevatedButton(
            onPressed: () async {
              if (_textCtrl.text.trim().isEmpty) return;
              final success = await ref.read(buddiesProvider.notifier).createPost(
                text: _textCtrl.text.trim(),
                location: _locationCtrl.text.trim(),
                budget: _budgetCtrl.text.trim(),
                isFlexibleDate: _isFlexible,
              );
              if (success && mounted) {
                Navigator.pop(context);
                showSuccessSnack(context, 'Trip posted!');
              }
            },
            child: const Text('Post'),
          ),
        const SizedBox(height: 24),
      ]),
    );
  }
}
