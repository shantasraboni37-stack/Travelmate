import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import '../../../core/repositories/auth_repository.dart';

/// Auth state stream provider - single source of truth for Firebase Auth state
final authStateProvider = StreamProvider<User?>((ref) {
  return FirebaseAuth.instance.authStateChanges();
});

enum AuthStatus { initial, loading, authenticated, needsSetup, error, unauthenticated }

class AuthState {
  final AuthStatus status;
  final User? user;
  final String? errorMessage;

  const AuthState({
    this.status = AuthStatus.initial,
    this.user,
    this.errorMessage,
  });

  AuthState copyWith({
    AuthStatus? status,
    User? user,
    String? errorMessage,
  }) {
    return AuthState(
      status: status ?? this.status,
      user: user ?? this.user,
      errorMessage: errorMessage ?? this.errorMessage,
    );
  }
}

class AuthNotifier extends StateNotifier<AuthState> {
  final AuthRepository _repository;

  AuthNotifier(this._repository) : super(const AuthState()) {
    _init();
  }

  void _init() {
    _repository.authStateChanges.listen((user) async {
      if (user == null) {
        state = const AuthState(status: AuthStatus.unauthenticated);
      } else {
        try {
          final doc = await _repository.getUserDoc(user.uid);
          final setupComplete = doc.data()?['setupComplete'] ?? false;
          state = AuthState(
            status: setupComplete ? AuthStatus.authenticated : AuthStatus.needsSetup,
            user: user,
          );
        } catch (e) {
          state = AuthState(status: AuthStatus.error, errorMessage: e.toString());
        }
      }
    });
  }

  Future<void> signInWithGoogle() async {
    state = state.copyWith(status: AuthStatus.loading, errorMessage: null);
    try {
      final cred = await _repository.signInWithGoogle();
      if (cred == null) {
        state = state.copyWith(status: AuthStatus.unauthenticated);
        return;
      }
      await _handlePostAuth(cred);
    } on FirebaseAuthException catch (e) {
      state = AuthState(status: AuthStatus.error, errorMessage: _parseAuthError(e));
    } catch (e) {
      state = AuthState(status: AuthStatus.error, errorMessage: e.toString());
    }
  }

  Future<void> signInWithEmail(String email, String password) async {
    state = state.copyWith(status: AuthStatus.loading, errorMessage: null);
    try {
      final cred = await _repository.signInWithEmail(email, password);
      await _handlePostAuth(cred);
    } on FirebaseAuthException catch (e) {
      state = AuthState(status: AuthStatus.error, errorMessage: _parseAuthError(e));
    }
  }

  Future<void> signUpWithEmail(String email, String password) async {
    state = state.copyWith(status: AuthStatus.loading, errorMessage: null);
    try {
      final cred = await _repository.signUpWithEmail(email, password);
      await _repository.createUserDoc(cred.user!.uid, {
        'uid': cred.user!.uid,
        'email': cred.user!.email,
        'displayName': cred.user!.displayName ?? '',
        'profilePicUrl': cred.user!.photoURL,
        'setupComplete': false,
        'createdAt': FieldValue.serverTimestamp(),
      });
      state = state.copyWith(status: AuthStatus.needsSetup, user: cred.user);
    } on FirebaseAuthException catch (e) {
      state = AuthState(status: AuthStatus.error, errorMessage: _parseAuthError(e));
    }
  }

  Future<void> verifyPhone(
    String phoneNumber, {
    required Function(String) onCodeSent,
    required Function(FirebaseAuthException) onError,
  }) async {
    await _repository.verifyPhone(
      phoneNumber: phoneNumber,
      onCodeSent: onCodeSent,
      onError: onError,
      onCompleted: (cred) async {
        final userCred = await _repository.signInWithCredential(cred);
        await _handlePostAuth(userCred);
      },
    );
  }

  Future<void> verifyOtp(String verificationId, String smsCode) async {
    state = state.copyWith(status: AuthStatus.loading, errorMessage: null);
    try {
      final cred = await _repository.verifyOtp(verificationId, smsCode);
      await _handlePostAuth(cred);
    } on FirebaseAuthException catch (e) {
      state = AuthState(status: AuthStatus.error, errorMessage: _parseAuthError(e));
    }
  }

  Future<void> resetPassword(String email) async {
    try {
      await _repository.resetPassword(email);
    } catch (e) {
      state = state.copyWith(errorMessage: e.toString());
    }
  }

  Future<void> changePassword(String currentPassword, String newPassword) async {
    try {
      await _repository.changePassword(currentPassword, newPassword);
    } catch (e) {
      state = state.copyWith(errorMessage: e.toString());
    }
  }

  Future<void> changeEmail(String newEmail, String password) async {
    try {
      await _repository.changeEmail(newEmail, password);
    } catch (e) {
      state = state.copyWith(errorMessage: e.toString());
    }
  }

  Future<void> deleteAccount(String password) async {
    try {
      await _repository.deleteAccount(password);
      state = const AuthState(status: AuthStatus.unauthenticated);
    } catch (e) {
      state = state.copyWith(errorMessage: e.toString());
    }
  }

  Future<void> signOut() async {
    try {
      await _repository.signOut();
      state = const AuthState(status: AuthStatus.unauthenticated);
    } catch (e) {
      state = state.copyWith(errorMessage: e.toString());
    }
  }

  Future<void> _handlePostAuth(UserCredential cred) async {
    try {
      final doc = await _repository.getUserDoc(cred.user!.uid);
      if (!doc.exists) {
        await _repository.createUserDoc(cred.user!.uid, {
          'uid': cred.user!.uid,
          'email': cred.user!.email,
          'phone': cred.user!.phoneNumber,
          'displayName': cred.user!.displayName ?? '',
          'profilePicUrl': cred.user!.photoURL,
          'setupComplete': false,
          'createdAt': FieldValue.serverTimestamp(),
        });
        state = AuthState(status: AuthStatus.needsSetup, user: cred.user);
      } else {
        final setupDone = doc.data()?['setupComplete'] ?? false;
        state = AuthState(
          status: setupDone ? AuthStatus.authenticated : AuthStatus.needsSetup,
          user: cred.user,
        );
      }
    } catch (e) {
      state = AuthState(status: AuthStatus.error, errorMessage: e.toString());
    }
  }

  String _parseAuthError(FirebaseAuthException e) {
    switch (e.code) {
      case 'user-not-found':
        return 'No account found with this email.';
      case 'wrong-password':
        return 'Incorrect password. Please try again.';
      case 'email-already-in-use':
        return 'An account already exists with this email.';
      case 'invalid-email':
        return 'Please enter a valid email address.';
      case 'weak-password':
        return 'Password is too weak. Use at least 6 characters.';
      case 'invalid-verification-code':
        return 'Invalid OTP code. Please try again.';
      case 'invalid-phone-number':
        return 'Invalid phone number format.';
      case 'too-many-requests':
        return 'Too many attempts. Please try again later.';
      case 'network-request-failed':
        return 'Network error. Please check your connection.';
      case 'requires-recent-login':
        return 'Please login again to perform this action.';
      default:
        return e.message ?? 'An error occurred. Please try again.';
    }
  }
}

final authNotifierProvider = StateNotifierProvider<AuthNotifier, AuthState>((ref) {
  return AuthNotifier(AuthRepository());
});

// Simple provider for current user ID
final currentUserIdProvider = Provider<String?>((ref) {
  final auth = ref.watch(authNotifierProvider);
  return auth.user?.uid;
});
