import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import '../../../core/utils/error_handler.dart';
import '../../../core/utils/validators.dart';
import '../providers/auth_provider.dart';

class SignUpPage extends ConsumerStatefulWidget {
  const SignUpPage({super.key});

  @override
  ConsumerState<SignUpPage> createState() => _SignUpPageState();
}

class _SignUpPageState extends ConsumerState<SignUpPage> {
  final _emailCtrl = TextEditingController();
  final _passwordCtrl = TextEditingController();
  final _confirmCtrl = TextEditingController();
  final _formKey = GlobalKey<FormState>();
  bool _obscure = true;
  bool _obscureConfirm = true;

  @override
  void dispose() {
    _emailCtrl.dispose();
    _passwordCtrl.dispose();
    _confirmCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final auth = ref.watch(authNotifierProvider);

    ref.listen(authNotifierProvider, (prev, next) {
      if (next.status == AuthStatus.needsSetup) context.go('/setup');
      else if (next.status == AuthStatus.error && next.errorMessage != null) {
        showErrorSnack(context, next.errorMessage!);
      }
    });

    return Scaffold(
      appBar: AppBar(title: const Text('Create Account')),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(24),
        child: Form(
          key: _formKey,
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text('Join TravelMate', style: Theme.of(context).textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.w800)),
            const SizedBox(height: 8),
            Text('Create an account to start your travel journey.', style: Theme.of(context).textTheme.bodyMedium?.copyWith(color: Colors.grey[600])),
            const SizedBox(height: 24),
            TextFormField(controller: _emailCtrl, keyboardType: TextInputType.emailAddress,
              decoration: const InputDecoration(labelText: 'Email', hintText: 'your@email.com',
                prefixIcon: Icon(Icons.email_outlined)),
              validator: Validators.email),
            const SizedBox(height: 16),
            TextFormField(controller: _passwordCtrl, obscureText: _obscure,
              decoration: InputDecoration(labelText: 'Password', hintText: 'Min 6 characters',
                prefixIcon: const Icon(Icons.lock_outline),
                suffixIcon: IconButton(icon: Icon(_obscure ? Icons.visibility_off : Icons.visibility),
                  onPressed: () => setState(() => _obscure = !_obscure))),
              validator: Validators.password),
            const SizedBox(height: 16),
            TextFormField(controller: _confirmCtrl, obscureText: _obscureConfirm,
              decoration: InputDecoration(labelText: 'Confirm Password', hintText: 'Repeat your password',
                prefixIcon: const Icon(Icons.lock_outline),
                suffixIcon: IconButton(icon: Icon(_obscureConfirm ? Icons.visibility_off : Icons.visibility),
                  onPressed: () => setState(() => _obscureConfirm = !_obscureConfirm))),
              validator: (v) => Validators.confirmPassword(v, _passwordCtrl.text)),
            const SizedBox(height: 24),
            if (auth.status == AuthStatus.loading)
              const Center(child: CircularProgressIndicator())
            else
              ElevatedButton(
                onPressed: () {
                  if (_formKey.currentState!.validate()) {
                    ref.read(authNotifierProvider.notifier).signUpWithEmail(
                      _emailCtrl.text.trim(), _passwordCtrl.text);
                  }
                },
                child: const Text('Create Account')),
            const SizedBox(height: 16),
            Center(child: TextButton(
              onPressed: () { context.pop(); context.push('/login'); },
              child: const Text('Already have an account? Sign In'))),
          ]),
        ),
      ),
    );
  }
}
