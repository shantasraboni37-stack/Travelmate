import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:country_picker/country_picker.dart';
import '../../../core/utils/error_handler.dart';
import '../providers/auth_provider.dart';

class PhoneLoginPage extends ConsumerStatefulWidget {
  const PhoneLoginPage({super.key});

  @override
  ConsumerState<PhoneLoginPage> createState() => _PhoneLoginPageState();
}

class _PhoneLoginPageState extends ConsumerState<PhoneLoginPage> {
  final _phoneCtrl = TextEditingController();
  Country _selectedCountry = CountryParser.parseCountryCode('US');
  bool _isLoading = false;

  @override
  void dispose() {
    _phoneCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Phone Sign In')),
      body: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text('Enter your phone number', style: Theme.of(context).textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.w800)),
          const SizedBox(height: 8),
          Text('We\'ll send you a verification code.', style: Theme.of(context).textTheme.bodyMedium?.copyWith(color: Colors.grey[600])),
          const SizedBox(height: 32),
          Row(children: [
            InkWell(
              onTap: () => showCountryPicker(context: context, showPhoneCode: true,
                onSelect: (c) => setState(() => _selectedCountry = c)),
              borderRadius: BorderRadius.circular(14),
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
                decoration: BoxDecoration(
                  border: Border.all(color: Theme.of(context).inputDecorationTheme.border!.borderSide.color),
                  borderRadius: BorderRadius.circular(14)),
                child: Row(mainAxisSize: MainAxisSize.min, children: [
                  Text(_selectedCountry.flagEmoji),
                  const SizedBox(width: 8),
                  Text('+${_selectedCountry.phoneCode}'),
                  const Icon(Icons.arrow_drop_down),
                ]),
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: TextField(
                controller: _phoneCtrl, keyboardType: TextInputType.phone,
                decoration: const InputDecoration(labelText: 'Phone Number', hintText: '1234567890')),
            ),
          ]),
          const SizedBox(height: 32),
          if (_isLoading)
            const Center(child: CircularProgressIndicator())
          else
            ElevatedButton(
              onPressed: () async {
                final phone = _phoneCtrl.text.trim();
                if (phone.isEmpty) return;
                setState(() => _isLoading = true);
                await ref.read(authNotifierProvider.notifier).verifyPhone(
                  '+${_selectedCountry.phoneCode}$phone',
                  onCodeSent: (vid) {
                    setState(() => _isLoading = false);
                    context.push('/otp?vid=$vid');
                  },
                  onError: (e) {
                    setState(() => _isLoading = false);
                    showErrorSnack(context, e.message ?? 'Failed to send code');
                  },
                );
              },
              child: const Text('Send Verification Code')),
        ]),
      ),
    );
  }
}
