import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:google_fonts/google_fonts.dart';
import '../../../core/utils/error_handler.dart';
import '../../../core/utils/validators.dart';
import '../providers/auth_provider.dart';

class LoginPage extends ConsumerStatefulWidget {
  const LoginPage({super.key});

  @override
  ConsumerState<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends ConsumerState<LoginPage> {
  final _emailCtrl = TextEditingController();
  final _passwordCtrl = TextEditingController();
  final _formKey = GlobalKey<FormState>();
  bool _obscure = true;

  @override
  void dispose() {
    _emailCtrl.dispose();
    _passwordCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final auth = ref.watch(authNotifierProvider);

    ref.listen(authNotifierProvider, (prev, next) {
      if (next.status == AuthStatus.needsSetup) context.go('/setup');
      else if (next.status == AuthStatus.authenticated) context.go('/buddies');
      else if (next.status == AuthStatus.error && next.errorMessage != null) {
        showErrorSnack(context, next.errorMessage!);
      }
    });

    return Scaffold(
      appBar: AppBar(title: const Text('Sign In')),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(24),
        child: Form(
          key: _formKey,
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            _LogoBanner(),
            const SizedBox(height: 32),
            TextFormField(
              controller: _emailCtrl, keyboardType: TextInputType.emailAddress,
              decoration: const InputDecoration(labelText: 'Email', hintText: 'your@email.com',
                prefixIcon: Icon(Icons.email_outlined)),
              validator: Validators.email,
            ),
            const SizedBox(height: 16),
            TextFormField(
              controller: _passwordCtrl, obscureText: _obscure,
              decoration: InputDecoration(
                labelText: 'Password', hintText: 'Enter your password',
                prefixIcon: const Icon(Icons.lock_outline),
                suffixIcon: IconButton(
                  icon: Icon(_obscure ? Icons.visibility_off : Icons.visibility),
                  onPressed: () => setState(() => _obscure = !_obscure)),
              ),
              validator: Validators.password,
            ),
            const SizedBox(height: 8),
            Align(alignment: Alignment.centerRight,
              child: TextButton(onPressed: () => context.push('/forgot'), child: const Text('Forgot Password?'))),
            const SizedBox(height: 16),
            if (auth.status == AuthStatus.loading)
              const Center(child: CircularProgressIndicator())
            else
              ElevatedButton(
                onPressed: () {
                  if (_formKey.currentState!.validate()) {
                    ref.read(authNotifierProvider.notifier).signInWithEmail(
                      _emailCtrl.text.trim(), _passwordCtrl.text);
                  }
                },
                child: const Text('Sign In'),
              ),
            const SizedBox(height: 16),
            Center(child: TextButton(
              onPressed: () { context.pop(); context.push('/signup'); },
              child: const Text('Don\'t have an account? Sign Up'))),
          ]),
        ),
      ),
    );
  }
}

class _LogoBanner extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.symmetric(vertical: 16, horizontal: 20),
      decoration: BoxDecoration(color: const Color(0xFFB0213F), borderRadius: BorderRadius.circular(20)),
      child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
        Container(
          width: 44, height: 44,
          decoration: BoxDecoration(color: Colors.white.withOpacity(0.15), borderRadius: BorderRadius.circular(12)),
          child: ClipRRect(
            borderRadius: BorderRadius.circular(11),
            child: Image.asset('assets/images/travelmate_logo_main.png', fit: BoxFit.contain,
              errorBuilder: (_, __, ___) => const Icon(Icons.explore_rounded, color: Colors.white, size: 26)),
          ),
        ),
        const SizedBox(width: 12),
        Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisSize: MainAxisSize.min, children: [
          Text('Travelmate', style: GoogleFonts.manrope(fontSize: 22, fontWeight: FontWeight.w800, color: Colors.white, height: 1)),
          const SizedBox(height: 3),
          Text('YOUR TRAVEL COMPANION', style: GoogleFonts.manrope(
            fontSize: 8, fontWeight: FontWeight.w600, color: Colors.white.withOpacity(0.65), letterSpacing: 1.8)),
        ]),
      ]),
    );
  }
}
