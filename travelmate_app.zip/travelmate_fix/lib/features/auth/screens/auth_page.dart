import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:go_router/go_router.dart';
import 'package:google_fonts/google_fonts.dart';
import '../../../core/utils/error_handler.dart';
import '../providers/auth_provider.dart';

class AuthPage extends ConsumerWidget {
  const AuthPage({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final auth = ref.watch(authNotifierProvider);
    final isDark = Theme.of(context).brightness == Brightness.dark;

    ref.listen(authNotifierProvider, (prev, next) {
      if (next.status == AuthStatus.needsSetup) {
        context.go('/setup');
      } else if (next.status == AuthStatus.authenticated) {
        context.go('/buddies');
      } else if (next.status == AuthStatus.error && next.errorMessage != null) {
        showErrorSnack(context, next.errorMessage!);
      }
    });

    return Scaffold(
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(children: [
            const Spacer(),
            Image.asset('assets/images/travelmate_logo_main.png',
              width: 80, height: 80,
              errorBuilder: (_, __, ___) => const Icon(Icons.explore_rounded, size: 80, color: Color(0xFFB0213F))),
            const SizedBox(height: 16),
            Text('TravelMate', style: GoogleFonts.manrope(
              fontSize: 28, fontWeight: FontWeight.w900, color: Theme.of(context).colorScheme.primary)),
            const SizedBox(height: 8),
            Text('YOUR TRAVEL COMPANION', style: GoogleFonts.manrope(
              fontSize: 10, fontWeight: FontWeight.w600, letterSpacing: 2, color: Colors.grey)),
            const SizedBox(height: 32),
            Image.asset(isDark ? 'assets/images/auth_image_night.png' : 'assets/images/auth_image.png',
              height: 240, fit: BoxFit.contain,
              errorBuilder: (_, __, ___) => Icon(Icons.travel_explore,
                size: 120, color: Theme.of(context).colorScheme.primary.withOpacity(0.3))),
            const Spacer(),
            if (auth.status == AuthStatus.loading)
              const CircularProgressIndicator()
            else ...[
              ElevatedButton.icon(
                onPressed: () => ref.read(authNotifierProvider.notifier).signInWithGoogle(),
                icon: SvgPicture.asset('assets/icons/google_colored.svg', width: 24, height: 24,
                  placeholderBuilder: (_) => const Icon(Icons.g_mobiledata, color: Colors.white)),
                label: const Text('Continue with Google'),
              ),
              const SizedBox(height: 12),
              ElevatedButton.icon(
                onPressed: () => context.push('/login'),
                icon: const Icon(Icons.email_outlined),
                label: const Text('Sign in with Email'),
              ),
              const SizedBox(height: 12),
              OutlinedButton.icon(
                onPressed: () => context.push('/phone'),
                icon: const Icon(Icons.phone_outlined),
                label: const Text('Sign in with Phone'),
              ),
              const SizedBox(height: 16),
              TextButton(
                onPressed: () => context.push('/signup'),
                child: const Text('Don\'t have an account? Sign Up'),
              ),
            ],
          ]),
        ),
      ),
    );
  }
}
