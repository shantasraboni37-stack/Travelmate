import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import '../../../core/utils/error_handler.dart';
import '../../../core/utils/validators.dart';
import '../providers/auth_provider.dart';

class OtpPage extends ConsumerStatefulWidget {
  final String verificationId;
  const OtpPage({super.key, required this.verificationId});

  @override
  ConsumerState<OtpPage> createState() => _OtpPageState();
}

class _OtpPageState extends ConsumerState<OtpPage> {
  final _otpCtrl = TextEditingController();
  final _formKey = GlobalKey<FormState>();

  @override
  void dispose() {
    _otpCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final auth = ref.watch(authNotifierProvider);

    ref.listen(authNotifierProvider, (prev, next) {
      if (next.status == AuthStatus.needsSetup) context.go('/setup');
      else if (next.status == AuthStatus.authenticated) context.go('/buddies');
      else if (next.status == AuthStatus.error && next.errorMessage != null) {
        showErrorSnack(context, next.errorMessage!);
      }
    });

    return Scaffold(
      appBar: AppBar(title: const Text('Verify Phone')),
      body: Padding(
        padding: const EdgeInsets.all(24),
        child: Form(
          key: _formKey,
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text('Enter verification code', style: Theme.of(context).textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.w800)),
            const SizedBox(height: 8),
            const Text('We sent a 6-digit code to your phone.'),
            const SizedBox(height: 32),
            TextFormField(
              controller: _otpCtrl, keyboardType: TextInputType.number, maxLength: 6,
              textAlign: TextAlign.center,
              style: const TextStyle(fontSize: 24, letterSpacing: 16, fontWeight: FontWeight.w700),
              decoration: const InputDecoration(hintText: '000000', counterText: ''),
              validator: Validators.otp,
            ),
            const SizedBox(height: 32),
            if (auth.status == AuthStatus.loading)
              const Center(child: CircularProgressIndicator())
            else
              ElevatedButton(
                onPressed: () {
                  if (_formKey.currentState!.validate()) {
                    ref.read(authNotifierProvider.notifier).verifyOtp(
                      widget.verificationId, _otpCtrl.text.trim());
                  }
                },
                child: const Text('Verify')),
          ]),
        ),
      ),
    );
  }
}
