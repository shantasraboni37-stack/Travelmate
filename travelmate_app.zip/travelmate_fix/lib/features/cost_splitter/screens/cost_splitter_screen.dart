import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import '../../../core/utils/error_handler.dart';
import '../providers/cost_splitter_provider.dart';

class CostSplitterScreen extends ConsumerWidget {
  const CostSplitterScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final state = ref.watch(costSplitterProvider);

    if (state.error != null) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        showErrorSnack(context, state.error);
      });
    }

    return Scaffold(
      appBar: AppBar(title: const Text('Cost Splitter')),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => _showCreateRoom(context, ref),
        icon: const Icon(Icons.add), label: const Text('New Room'),
      ),
      body: state.isLoading
          ? const Center(child: CircularProgressIndicator())
          : state.rooms.isEmpty
              ? Center(child: Column(mainAxisSize: MainAxisSize.min, children: [
                  const Icon(Icons.account_balance_wallet_outlined, size: 64, color: Colors.grey),
                  const SizedBox(height: 16),
                  const Text('No Rooms Yet', style: TextStyle(fontWeight: FontWeight.w700)),
                  const SizedBox(height: 8),
                  const Text('Create a room to split expenses.'),
                  const SizedBox(height: 16),
                  ElevatedButton(
                    onPressed: () => _showCreateRoom(context, ref),
                    child: const Text('Create Room')),
                ]))
              : ListView.builder(
                  itemCount: state.rooms.length,
                  itemBuilder: (context, index) {
                    final room = state.rooms[index];
                    return _RoomCard(room: room);
                  },
                ),
    );
  }

  void _showCreateRoom(BuildContext context, WidgetRef ref) {
    final nameCtrl = TextEditingController();
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('New Room'),
        content: TextField(
          controller: nameCtrl,
          decoration: const InputDecoration(labelText: 'Room Name', hintText: 'e.g. Bali Trip 2026')),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Cancel')),
          ElevatedButton(
            onPressed: () async {
              if (nameCtrl.text.trim().isEmpty) return;
              final success = await ref.read(costSplitterProvider.notifier).createRoom(nameCtrl.text.trim());
              if (success && ctx.mounted) {
                Navigator.pop(ctx);
                showSuccessSnack(context, 'Room created!');
              }
            },
            child: const Text('Create')),
        ],
      ),
    );
  }
}

class _RoomCard extends StatelessWidget {
  final Map<String, dynamic> room;
  const _RoomCard({required this.room});

  @override
  Widget build(BuildContext context) {
    final roomId = room['roomId'] as String? ?? '';
    final roomName = room['roomName'] as String? ?? '';
    final memberCount = (room['members'] as List<dynamic>?)?.length ?? 0;

    return Card(
      child: ListTile(
        leading: CircleAvatar(
          backgroundColor: const Color(0xFFB0213F).withOpacity(0.1),
          child: const Icon(Icons.account_balance_wallet, color: Color(0xFFB0213F))),
        title: Text(roomName, style: const TextStyle(fontWeight: FontWeight.w700)),
        subtitle: Text('$memberCount members'),
        trailing: const Icon(Icons.chevron_right),
        onTap: () => context.push('/splitter-room/$roomId'),
      ),
    );
  }
}
