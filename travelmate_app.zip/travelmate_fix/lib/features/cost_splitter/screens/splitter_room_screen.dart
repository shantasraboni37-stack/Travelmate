import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../core/utils/error_handler.dart';
import '../../../core/utils/helpers.dart';
import '../../../models/expense.dart';
import '../providers/cost_splitter_provider.dart';

class SplitterRoomScreen extends ConsumerStatefulWidget {
  final String roomId;
  const SplitterRoomScreen({super.key, required this.roomId});

  @override
  ConsumerState<SplitterRoomScreen> createState() => _SplitterRoomScreenState();
}

class _SplitterRoomScreenState extends ConsumerState<SplitterRoomScreen> {
  final _amountCtrl = TextEditingController();
  final _descCtrl = TextEditingController();
  int _selectedPayer = 0;

  @override
  void initState() {
    super.initState();
    // Load expenses for this room
    WidgetsBinding.instance.addPostFrameCallback((_) {
      ref.read(costSplitterProvider.notifier).loadExpenses(widget.roomId);
    });
  }

  @override
  void dispose() {
    _amountCtrl.dispose();
    _descCtrl.dispose();
    super.dispose();
  }

  Future<void> _addExpense(List<String> members, List<String> memberNames) async {
    final amount = double.tryParse(_amountCtrl.text);
    if (amount == null || amount <= 0) {
      showErrorSnack(context, 'Enter a valid amount');
      return;
    }
    if (_descCtrl.text.trim().isEmpty) {
      showErrorSnack(context, 'Enter a description');
      return;
    }

    final expense = Expense(
      expenseId: '',
      paidBy: members[_selectedPayer],
      paidByName: memberNames[_selectedPayer],
      amount: amount,
      description: _descCtrl.text.trim(),
    );

    final success = await ref.read(costSplitterProvider.notifier).addExpense(widget.roomId, expense);
    if (success && mounted) {
      _amountCtrl.clear();
      _descCtrl.clear();
      showSuccessSnack(context, 'Expense added');
    } else if (mounted) {
      final error = ref.read(costSplitterProvider).error;
      if (error != null) showErrorSnack(context, error);
    }
  }

  @override
  Widget build(BuildContext context) {
    final state = ref.watch(costSplitterProvider);

    if (state.error != null) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        showErrorSnack(context, state.error);
      });
    }

    // Find current room data
    final room = state.rooms.firstWhere(
      (r) => r['roomId'] == widget.roomId,
      orElse: () => {},
    );
    if (room.isEmpty) {
      return const Scaffold(body: Center(child: CircularProgressIndicator()));
    }

    final members = List<String>.from(room['members'] ?? []);
    final memberNames = List<String>.from(room['memberNames'] ?? []);

    return Scaffold(
      appBar: AppBar(title: Text(room['roomName'] ?? 'Room')),
      body: Column(children: [
        Expanded(
          child: CustomScrollView(slivers: [
            SliverToBoxAdapter(child: _buildSummary(state.expenses, members, memberNames)),
            if (state.expenses.isNotEmpty)
              SliverToBoxAdapter(child: _buildSettlements(state.expenses, members, memberNames)),
            SliverPadding(
              padding: const EdgeInsets.all(16),
              sliver: SliverList(
                delegate: SliverChildBuilderDelegate(
                  (context, index) => _ExpenseCard(expense: state.expenses[index]),
                  childCount: state.expenses.length,
                ),
              ),
            ),
          ]),
        ),
        _buildAddExpense(members, memberNames),
      ]),
    );
  }

  Widget _buildSummary(List<Expense> expenses, List<String> members, List<String> memberNames) {
    final total = expenses.fold<double>(0, (s, e) => s + e.amount);
    final perPerson = members.isNotEmpty ? total / members.length : 0;

    return Container(
      margin: const EdgeInsets.all(16), padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: const Color(0xFFB0213F).withOpacity(0.05), borderRadius: BorderRadius.circular(16)),
      child: Row(mainAxisAlignment: MainAxisAlignment.spaceAround, children: [
        _SummaryItem(label: 'Total', value: '\$${total.toStringAsFixed(2)}'),
        _SummaryItem(label: 'Per Person', value: '\$${perPerson.toStringAsFixed(2)}'),
        _SummaryItem(label: 'Expenses', value: '${expenses.length}'),
      ]),
    );
  }

  Widget _buildSettlements(List<Expense> expenses, List<String> members, List<String> memberNames) {
    final balances = <String, double>{};
    for (var i = 0; i < members.length; i++) balances[members[i]] = 0;
    for (final exp in expenses) balances[exp.paidBy] = (balances[exp.paidBy] ?? 0) + exp.amount;
    final total = expenses.fold<double>(0, (s, e) => s + e.amount);
    final fairShare = total / members.length;

    final settlements = <Map<String, dynamic>>[];
    final debtors = <String, double>{};
    final creditors = <String, double>{};

    for (final entry in balances.entries) {
      final diff = entry.value - fairShare;
      if (diff > 0.01) creditors[entry.key] = diff;
      else if (diff < -0.01) debtors[entry.key] = -diff;
    }

    for (final debtor in debtors.entries) {
      double remaining = debtor.value;
      for (final creditor in creditors.entries) {
        if (remaining <= 0.01) break;
        if (creditor.value <= 0.01) continue;
        final amount = remaining < creditor.value ? remaining : creditor.value;
        remaining -= amount;
        creditors[creditor.key] = creditor.value - amount;
        final dIdx = members.indexOf(debtor.key);
        final cIdx = members.indexOf(creditor.key);
        settlements.add({
          'from': dIdx >= 0 ? memberNames[dIdx] : debtor.key,
          'to': cIdx >= 0 ? memberNames[cIdx] : creditor.key,
          'amount': amount,
        });
      }
    }

    if (settlements.isEmpty) return const SizedBox.shrink();

    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 16),
      child: Card(
        child: ExpansionTile(
          title: const Text('Settlements', style: TextStyle(fontWeight: FontWeight.w700)),
          children: settlements.map((s) => ListTile(
            leading: const Icon(Icons.swap_horiz, color: Color(0xFFB0213F)),
            title: Text('${s['from']} pays ${s['to']}'),
            trailing: Text('\$${(s['amount'] as double).toStringAsFixed(2)}',
              style: const TextStyle(fontWeight: FontWeight.w700, color: Color(0xFFB0213F))),
          )).toList(),
        ),
      ),
    );
  }

  Widget _buildAddExpense(List<String> members, List<String> memberNames) {
    final state = ref.watch(costSplitterProvider);
    return SafeArea(
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: Theme.of(context).cardColor,
          border: Border(top: BorderSide(color: Theme.of(context).dividerColor))),
        child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Text('Add Expense', style: TextStyle(fontWeight: FontWeight.w700)),
          const SizedBox(height: 8),
          Row(children: [
            Expanded(flex: 2,
              child: TextField(controller: _descCtrl,
                decoration: const InputDecoration(hintText: 'Description',
                  contentPadding: EdgeInsets.symmetric(horizontal: 12, vertical: 10)))),
            const SizedBox(width: 8),
            Expanded(
              child: TextField(controller: _amountCtrl, keyboardType: TextInputType.number,
                decoration: const InputDecoration(hintText: 'Amount', prefixText: '\$',
                  contentPadding: EdgeInsets.symmetric(horizontal: 12, vertical: 10)))),
          ]),
          const SizedBox(height: 8),
          DropdownButtonFormField<int>(
            value: _selectedPayer,
            items: members.asMap().entries.map((entry) => DropdownMenuItem(
              value: entry.key, child: Text(memberNames[entry.key]))).toList(),
            onChanged: (v) => setState(() => _selectedPayer = v ?? 0),
            decoration: const InputDecoration(labelText: 'Paid by')),
          const SizedBox(height: 12),
          if (state.isAddingExpense)
            const Center(child: CircularProgressIndicator())
          else
            ElevatedButton(
              onPressed: () => _addExpense(members, memberNames),
              child: const Text('Add Expense')),
        ]),
      ),
    );
  }
}

class _SummaryItem extends StatelessWidget {
  final String label;
  final String value;
  const _SummaryItem({required this.label, required this.value});

  @override
  Widget build(BuildContext context) {
    return Column(children: [
      Text(value, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800, color: Color(0xFFB0213F))),
      Text(label, style: TextStyle(fontSize: 12, color: Colors.grey[600])),
    ]);
  }
}

class _ExpenseCard extends StatelessWidget {
  final Expense expense;
  const _ExpenseCard({required this.expense});

  @override
  Widget build(BuildContext context) {
    return Card(
      child: ListTile(
        leading: CircleAvatar(child: Text(expense.paidByName[0].toUpperCase())),
        title: Text(expense.description),
        subtitle: Text('Paid by ${expense.paidByName}'),
        trailing: Text('\$${expense.amount.toStringAsFixed(2)}',
          style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 16)),
      ),
    );
  }
}
