import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../core/repositories/cost_splitter_repository.dart';
import '../../../models/expense.dart';

class CostSplitterState {
  final List<Map<String, dynamic>> rooms;
  final List<Expense> expenses;
  final bool isLoading;
  final bool isCreatingRoom;
  final bool isAddingExpense;
  final String? error;

  const CostSplitterState({
    this.rooms = const [],
    this.expenses = const [],
    this.isLoading = false,
    this.isCreatingRoom = false,
    this.isAddingExpense = false,
    this.error,
  });

  CostSplitterState copyWith({
    List<Map<String, dynamic>>? rooms,
    List<Expense>? expenses,
    bool? isLoading,
    bool? isCreatingRoom,
    bool? isAddingExpense,
    String? error,
  }) {
    return CostSplitterState(
      rooms: rooms ?? this.rooms,
      expenses: expenses ?? this.expenses,
      isLoading: isLoading ?? this.isLoading,
      isCreatingRoom: isCreatingRoom ?? this.isCreatingRoom,
      isAddingExpense: isAddingExpense ?? this.isAddingExpense,
      error: error ?? this.error,
    );
  }
}

class CostSplitterNotifier extends StateNotifier<CostSplitterState> {
  final CostSplitterRepository _repository;

  CostSplitterNotifier(this._repository) : super(const CostSplitterState(isLoading: true));

  void loadRooms() {
    try {
      state = state.copyWith(isLoading: true, error: null);
      _repository.getUserRooms().listen(
        (rooms) {
          if (mounted) state = state.copyWith(rooms: rooms, isLoading: false);
        },
        onError: (e) {
          if (mounted) state = state.copyWith(error: e.toString(), isLoading: false);
        },
      );
    } catch (e) {
      state = state.copyWith(error: e.toString(), isLoading: false);
    }
  }

  void loadExpenses(String roomId) {
    try {
      state = state.copyWith(error: null);
      _repository.getRoomExpenses(roomId).listen(
        (expenses) {
          if (mounted) state = state.copyWith(expenses: expenses);
        },
        onError: (e) {
          if (mounted) state = state.copyWith(error: e.toString());
        },
      );
    } catch (e) {
      state = state.copyWith(error: e.toString());
    }
  }

  Future<bool> createRoom(String roomName) async {
    try {
      state = state.copyWith(isCreatingRoom: true, error: null);
      await _repository.createRoom(roomName);
      state = state.copyWith(isCreatingRoom: false);
      return true;
    } catch (e) {
      state = state.copyWith(error: e.toString(), isCreatingRoom: false);
      return false;
    }
  }

  Future<bool> addExpense(String roomId, Expense expense) async {
    try {
      state = state.copyWith(isAddingExpense: true, error: null);
      await _repository.addExpense(roomId, expense);
      state = state.copyWith(isAddingExpense: false);
      return true;
    } catch (e) {
      state = state.copyWith(error: e.toString(), isAddingExpense: false);
      return false;
    }
  }
}

final costSplitterProvider = StateNotifierProvider<CostSplitterNotifier, CostSplitterState>((ref) {
  return CostSplitterNotifier(CostSplitterRepository())..loadRooms();
});
