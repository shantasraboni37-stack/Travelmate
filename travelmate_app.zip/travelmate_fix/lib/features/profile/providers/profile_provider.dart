import 'dart:io';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../core/repositories/user_repository.dart';
import '../../../models/user.dart';

class ProfileState {
  final UserModel? user;
  final bool isLoading;
  final bool isUpdating;
  final String? error;

  const ProfileState({
    this.user,
    this.isLoading = false,
    this.isUpdating = false,
    this.error,
  });

  ProfileState copyWith({
    UserModel? user,
    bool? isLoading,
    bool? isUpdating,
    String? error,
  }) {
    return ProfileState(
      user: user ?? this.user,
      isLoading: isLoading ?? this.isLoading,
      isUpdating: isUpdating ?? this.isUpdating,
      error: error ?? this.error,
    );
  }
}

class ProfileNotifier extends StateNotifier<ProfileState> {
  final UserRepository _repository;

  ProfileNotifier(this._repository) : super(const ProfileState(isLoading: true));

  void loadProfile() {
    try {
      state = state.copyWith(isLoading: true, error: null);
      _repository.getCurrentUserStream().listen(
        (user) {
          if (mounted) state = state.copyWith(user: user, isLoading: false);
        },
        onError: (e) {
          if (mounted) state = state.copyWith(error: e.toString(), isLoading: false);
        },
      );
    } catch (e) {
      state = state.copyWith(error: e.toString(), isLoading: false);
    }
  }

  Future<bool> updateProfile({
    String? displayName,
    String? bio,
    List<String>? interests,
    File? profilePic,
    File? coverPic,
  }) async {
    try {
      state = state.copyWith(isUpdating: true, error: null);
      await _repository.updateProfile(
        displayName: displayName,
        bio: bio,
        interests: interests,
        profilePic: profilePic,
        coverPic: coverPic,
      );
      state = state.copyWith(isUpdating: false);
      return true;
    } catch (e) {
      state = state.copyWith(error: e.toString(), isUpdating: false);
      return false;
    }
  }

  Future<void> updateSetting(String field, dynamic value) async {
    try {
      await _repository.updateSetting(field, value);
    } catch (e) {
      state = state.copyWith(error: e.toString());
    }
  }
}

final profileProvider = StateNotifierProvider<ProfileNotifier, ProfileState>((ref) {
  return ProfileNotifier(UserRepository())..loadProfile();
});
