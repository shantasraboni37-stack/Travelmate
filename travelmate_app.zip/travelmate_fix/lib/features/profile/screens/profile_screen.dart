import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import '../../../core/utils/error_handler.dart';
import '../../../core/utils/helpers.dart';
import '../../../core/services/r2_service.dart';
import '../../../core/widgets/auth_image.dart';
import '../../packages/providers/bookings_provider.dart';
import '../providers/profile_provider.dart';

class ProfileScreen extends ConsumerWidget {
  const ProfileScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final state = ref.watch(profileProvider);

    if (state.error != null) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        showErrorSnack(context, state.error);
      });
    }

    if (state.isLoading) {
      return const Scaffold(body: Center(child: CircularProgressIndicator()));
    }

    final user = state.user;
    if (user == null) {
      return Scaffold(
        appBar: AppBar(title: const Text('Profile')),
        body: const Center(child: Text('Not logged in')),
      );
    }

    return Scaffold(
      body: CustomScrollView(slivers: [
        SliverToBoxAdapter(child: _ProfileHeader(user: user)),
        SliverToBoxAdapter(child: _ProfileStats(user: user)),
        SliverPadding(
          padding: const EdgeInsets.all(16),
          sliver: SliverList(
            delegate: SliverChildListDelegate([
              _ProfileInfo(user: user),
              const SizedBox(height: 16),
              _ProfileInterests(user: user),
              const SizedBox(height: 16),
              _ActionButtons(),
            ]),
          ),
        ),
      ]),
    );
  }
}

class _ProfileHeader extends StatelessWidget {
  final dynamic user;
  const _ProfileHeader({required this.user});

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    return Stack(clipBehavior: Clip.none, children: [
      // Cover photo - uses AuthNetworkImage with clip instead of DecorationImage
      SizedBox(
        height: 160,
        width: double.infinity,
        child: user.hasCoverPic
            ? AuthNetworkImage(
                imageUrl: R2Service.coverPicUrl(user.uid),
                width: double.infinity,
                height: 160,
                fit: BoxFit.cover,
                placeholder: Container(
                  color: isDark ? const Color(0xFF3A3C3C) : Colors.grey[300],
                  child: const Center(child: Icon(Icons.image, size: 48)),
                ),
              )
            : Container(
                color: isDark ? const Color(0xFF3A3C3C) : Colors.grey[300],
                child: const Center(child: Icon(Icons.image, size: 48)),
              ),
      ),
      Positioned(
        bottom: -40, left: 16,
        child: Container(
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            border: Border.all(color: Theme.of(context).scaffoldBackgroundColor, width: 4)),
          child: AuthCircleAvatar(
            imageUrl: user.hasProfilePic ? R2Service.profilePicUrl(user.uid) : null,
            radius: 48,
            fallbackText: Helpers.getInitials(user.displayName),
          ),
        ),
      ),
      Positioned(
        top: 120, right: 16,
        child: FloatingActionButton.small(
          onPressed: () => context.push('/edit-profile'),
          child: const Icon(Icons.edit)),
      ),
    ]);
  }
}

class _ProfileStats extends StatelessWidget {
  final dynamic user;
  const _ProfileStats({required this.user});

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(top: 48, left: 16, right: 16, bottom: 8),
      padding: const EdgeInsets.all(16),
      child: Row(mainAxisAlignment: MainAxisAlignment.spaceAround, children: [
        _StatItem(label: 'Friends', value: user.friendCount),
        _StatItem(label: 'Followers', value: user.followerCount),
        _StatItem(label: 'Following', value: user.followingCount),
      ]),
    );
  }
}

class _StatItem extends StatelessWidget {
  final String label;
  final int value;
  const _StatItem({required this.label, required this.value});

  @override
  Widget build(BuildContext context) {
    return Column(children: [
      Text(Helpers.formatNumber(value), style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
      Text(label, style: TextStyle(fontSize: 13, color: Colors.grey[600])),
    ]);
  }
}

class _ProfileInfo extends StatelessWidget {
  final dynamic user;
  const _ProfileInfo({required this.user});

  @override
  Widget build(BuildContext context) {
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Text(user.displayName,
        style: Theme.of(context).textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.w800)),
      if (user.bio.isNotEmpty) ...[
        const SizedBox(height: 8),
        Text(user.bio),
      ],
      const SizedBox(height: 8),
      Wrap(spacing: 16, children: [
        if (user.country != null)
          _InfoChip(icon: Icons.location_on, label: user.country),
        if (user.gender != null)
          _InfoChip(icon: Icons.person, label: user.gender),
      ]),
    ]);
  }
}

class _InfoChip extends StatelessWidget {
  final IconData icon;
  final String? label;
  const _InfoChip({required this.icon, this.label});

  @override
  Widget build(BuildContext context) {
    if (label == null || label.isEmpty) return const SizedBox.shrink();
    return Row(mainAxisSize: MainAxisSize.min, children: [
      Icon(icon, size: 14, color: Colors.grey[600]),
      const SizedBox(width: 4),
      Text(label, style: TextStyle(color: Colors.grey[600], fontSize: 13)),
    ]);
  }
}

class _ProfileInterests extends StatelessWidget {
  final dynamic user;
  const _ProfileInterests({required this.user});

  @override
  Widget build(BuildContext context) {
    if (user.interests.isEmpty) return const SizedBox.shrink();
    return Wrap(spacing: 8, runSpacing: 8,
      children: user.interests.map<Widget>((i) => Chip(
        label: Text(i), avatar: const Icon(Icons.favorite, size: 14))).toList());
  }
}

class _ActionButtons extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Column(children: [
      ListTile(
        leading: const Icon(Icons.settings_outlined),
        title: const Text('Settings'),
        trailing: const Icon(Icons.chevron_right),
        onTap: () => context.push('/settings'),
      ),
      ListTile(
        leading: const Icon(Icons.shopping_bag_outlined),
        title: const Text('My Bookings'),
        trailing: const Icon(Icons.chevron_right),
        onTap: () => context.push('/bookings'),
      ),
      ListTile(
        leading: const Icon(Icons.account_balance_wallet_outlined),
        title: const Text('Cost Splitter'),
        trailing: const Icon(Icons.chevron_right),
        onTap: () => context.push('/cost-splitter'),
      ),
    ]);
  }
}
