import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:image_picker/image_picker.dart';
import '../../../core/constants/app_constants.dart';
import '../../../core/services/r2_service.dart';
import '../../../core/utils/error_handler.dart';
import '../../../core/utils/validators.dart';
import '../../../core/widgets/auth_image.dart';
import '../providers/profile_provider.dart';

class EditProfileScreen extends ConsumerStatefulWidget {
  const EditProfileScreen({super.key});

  @override
  ConsumerState<EditProfileScreen> createState() => _EditProfileScreenState();
}

class _EditProfileScreenState extends ConsumerState<EditProfileScreen> {
  final _nameCtrl = TextEditingController();
  final _bioCtrl = TextEditingController();
  final _formKey = GlobalKey<FormState>();
  File? _newProfilePic;
  File? _newCoverPic;
  List<String> _interests = [];

  @override
  void initState() {
    super.initState();
    final user = ref.read(profileProvider).user;
    if (user != null) {
      _nameCtrl.text = user.displayName;
      _bioCtrl.text = user.bio;
      _interests = List.from(user.interests);
    }
  }

  Future<void> _pickImage(bool isProfile) async {
    final picker = ImagePicker();
    final picked = await picker.pickImage(source: ImageSource.gallery);
    if (picked != null) {
      setState(() {
        if (isProfile) _newProfilePic = File(picked.path);
        else _newCoverPic = File(picked.path);
      });
    }
  }

  Future<void> _save() async {
    if (!_formKey.currentState!.validate()) return;
    final success = await ref.read(profileProvider.notifier).updateProfile(
      displayName: _nameCtrl.text.trim(),
      bio: _bioCtrl.text.trim(),
      interests: _interests,
      profilePic: _newProfilePic,
      coverPic: _newCoverPic,
    );
    if (success && mounted) {
      showSuccessSnack(context, 'Profile updated');
      Navigator.pop(context);
    } else if (mounted) {
      final error = ref.read(profileProvider).error;
      if (error != null) showErrorSnack(context, error);
    }
  }

  @override
  void dispose() {
    _nameCtrl.dispose();
    _bioCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final state = ref.watch(profileProvider);
    final user = state.user;

    return Scaffold(
      appBar: AppBar(title: const Text('Edit Profile')),
      body: state.isUpdating
          ? const Center(child: CircularProgressIndicator())
          : user == null
              ? const Center(child: Text('Not logged in'))
              : SingleChildScrollView(
                  padding: const EdgeInsets.all(24),
                  child: Form(
                    key: _formKey,
                    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      GestureDetector(
                        onTap: () => _pickImage(false),
                        child: ClipRRect(
                          borderRadius: BorderRadius.circular(16),
                          child: Container(
                            height: 120,
                            width: double.infinity,
                            color: Colors.grey[300],
                            child: _newCoverPic != null
                                ? Image.file(_newCoverPic!, fit: BoxFit.cover)
                                : user.hasCoverPic
                                    ? AuthNetworkImage(
                                        imageUrl: R2Service.coverPicUrl(user.uid),
                                        width: double.infinity,
                                        height: 120,
                                        fit: BoxFit.cover,
                                      )
                                    : const Center(child: Icon(Icons.camera_alt, color: Colors.white)),
                          ),
                        ),
                      ),
                      const SizedBox(height: 16),
                      Center(
                        child: GestureDetector(
                          onTap: () => _pickImage(true),
                          child: _newProfilePic != null
                              ? CircleAvatar(
                                  radius: 50,
                                  backgroundImage: FileImage(_newProfilePic!),
                                )
                              : AuthCircleAvatar(
                                  imageUrl: user.hasProfilePic
                                      ? R2Service.profilePicUrl(user.uid)
                                      : null,
                                  radius: 50,
                                  fallbackText: '',
                                ),
                        ),
                      ),
                      const SizedBox(height: 24),
                      TextFormField(controller: _nameCtrl,
                        decoration: const InputDecoration(labelText: 'Display Name'),
                        validator: Validators.displayName),
                      const SizedBox(height: 16),
                      TextFormField(controller: _bioCtrl, maxLines: 3, maxLength: 200,
                        decoration: const InputDecoration(labelText: 'Bio', hintText: 'Tell us about yourself...'),
                        validator: Validators.bio),
                      const SizedBox(height: 16),
                      Text('Interests', style: Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w700)),
                      const SizedBox(height: 8),
                      Wrap(spacing: 8, runSpacing: 8,
                        children: AppConstants.travelInterests.map((interest) {
                          final isSelected = _interests.contains(interest);
                          return FilterChip(
                            label: Text(interest), selected: isSelected,
                            onSelected: (sel) => setState(() {
                              if (sel) _interests.add(interest);
                              else _interests.remove(interest);
                            }),
                          );
                        }).toList()),
                      const SizedBox(height: 32),
                      ElevatedButton(onPressed: _save, child: const Text('Save Changes')),
                    ]),
                  ),
                ),
    );
  }
}
