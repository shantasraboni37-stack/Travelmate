import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../core/repositories/notification_repository.dart';
import '../../../models/notification.dart';

class NotificationsState {
  final List<NotificationModel> notifications;
  final bool isLoading;
  final String? error;
  final int unreadCount;

  const NotificationsState({
    this.notifications = const [],
    this.isLoading = false,
    this.error,
    this.unreadCount = 0,
  });

  NotificationsState copyWith({
    List<NotificationModel>? notifications,
    bool? isLoading,
    String? error,
    int? unreadCount,
  }) {
    return NotificationsState(
      notifications: notifications ?? this.notifications,
      isLoading: isLoading ?? this.isLoading,
      error: error ?? this.error,
      unreadCount: unreadCount ?? this.unreadCount,
    );
  }
}

class NotificationsNotifier extends StateNotifier<NotificationsState> {
  final NotificationRepository _repository;

  NotificationsNotifier(this._repository) : super(const NotificationsState(isLoading: true));

  void loadNotifications() {
    try {
      state = state.copyWith(isLoading: true, error: null);
      _repository.getNotifications().listen(
        (notifications) {
          if (mounted) {
            final unread = notifications.where((n) => !n.isRead).length;
            state = state.copyWith(
              notifications: notifications,
              unreadCount: unread,
              isLoading: false,
            );
          }
        },
        onError: (e) {
          if (mounted) state = state.copyWith(error: e.toString(), isLoading: false);
        },
      );
    } catch (e) {
      state = state.copyWith(error: e.toString(), isLoading: false);
    }
  }

  Future<void> markAsRead(String notifId) async {
    try {
      await _repository.markAsRead(notifId);
    } catch (e) {
      state = state.copyWith(error: e.toString());
    }
  }

  Future<void> markAllAsRead() async {
    try {
      await _repository.markAllAsRead();
    } catch (e) {
      state = state.copyWith(error: e.toString());
    }
  }

  Future<void> deleteNotification(String notifId) async {
    try {
      await _repository.deleteNotification(notifId);
    } catch (e) {
      state = state.copyWith(error: e.toString());
    }
  }
}

final notificationsProvider = StateNotifierProvider<NotificationsNotifier, NotificationsState>((ref) {
  return NotificationsNotifier(NotificationRepository())..loadNotifications();
});

// Simple unread count provider for badges
final unreadCountProvider = Provider<int>((ref) {
  final state = ref.watch(notificationsProvider);
  return state.unreadCount;
});
