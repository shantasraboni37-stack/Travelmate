import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:timeago/timeago.dart' as timeago;
import '../../../core/utils/error_handler.dart';
import '../../../core/widgets/empty_states.dart';
import '../providers/notifications_provider.dart';

class NotificationsScreen extends ConsumerWidget {
  const NotificationsScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final state = ref.watch(notificationsProvider);

    if (state.error != null) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        showErrorSnack(context, state.error);
      });
    }

    return Scaffold(
      appBar: AppBar(
        title: const Text('Notifications'),
        actions: [
          TextButton(
            onPressed: () => ref.read(notificationsProvider.notifier).markAllAsRead(),
            child: const Text('Mark All Read'),
          ),
        ],
      ),
      body: state.isLoading
          ? const Center(child: CircularProgressIndicator())
          : state.notifications.isEmpty
              ? const EmptyNotifications()
              : ListView.builder(
                  itemCount: state.notifications.length,
                  itemBuilder: (context, index) {
                    final notif = state.notifications[index];
                    return _NotificationTile(notification: notif);
                  },
                ),
    );
  }
}

class _NotificationTile extends StatelessWidget {
  final dynamic notification;
  const _NotificationTile({required this.notification});

  @override
  Widget build(BuildContext context) {
    final (icon, color) = _getIconAndColor(notification.type);

    return Dismissible(
      key: Key(notification.notifId),
      direction: DismissDirection.endToStart,
      background: Container(
        alignment: Alignment.centerRight, padding: const EdgeInsets.only(right: 16),
        color: Colors.red, child: const Icon(Icons.delete, color: Colors.white)),
      onDismissed: (_) {},
      child: ListTile(
        leading: CircleAvatar(
          backgroundColor: color.withOpacity(0.1),
          child: Icon(icon, color: color, size: 20)),
        title: Text(notification.fromName,
          style: TextStyle(fontWeight: notification.isRead ? FontWeight.normal : FontWeight.w700)),
        subtitle: Text(_getText(notification.type)),
        trailing: notification.createdAt != null
            ? Text(timeago.format(notification.createdAt!.toDate()),
                style: TextStyle(fontSize: 11, color: Colors.grey[500]))
            : null,
        tileColor: notification.isRead ? null : const Color(0xFFFFF0F2),
      ),
    );
  }

  (IconData, Color) _getIconAndColor(String type) {
    switch (type) {
      case 'follow': return (Icons.person_add, Colors.blue);
      case 'friend_request': return (Icons.person_add_alt_1, Colors.green);
      case 'like': return (Icons.favorite, const Color(0xFFB0213F));
      case 'comment': return (Icons.comment, Colors.orange);
      case 'new_message': return (Icons.message, Colors.purple);
      case 'booking_confirmed': return (Icons.check_circle, Colors.green);
      default: return (Icons.notifications, Colors.grey);
    }
  }

  String _getText(String type) {
    switch (type) {
      case 'follow': return 'started following you';
      case 'friend_request': return 'sent you a friend request';
      case 'like': return 'liked your post';
      case 'comment': return 'commented on your post';
      case 'new_message': return 'sent you a message';
      case 'booking_confirmed': return 'Your booking is confirmed';
      default: return 'sent you a notification';
    }
  }
}
