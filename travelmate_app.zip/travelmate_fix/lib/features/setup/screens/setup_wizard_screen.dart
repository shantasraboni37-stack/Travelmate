import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:geocoding/geocoding.dart';
import 'package:geolocator/geolocator.dart';
import 'package:go_router/go_router.dart';
import 'package:image_picker/image_picker.dart';
import 'package:image_cropper/image_cropper.dart';
import 'package:crop_your_image/crop_your_image.dart';
import 'package:path_provider/path_provider.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../../../core/constants/app_constants.dart';
import '../../../core/services/r2_service.dart';
import '../../../core/utils/permission_helper.dart';
import '../../../core/utils/validators.dart';

class SetupWizardScreen extends ConsumerStatefulWidget {
  const SetupWizardScreen({super.key});

  @override
  ConsumerState<SetupWizardScreen> createState() => _SetupWizardScreenState();
}

class _SetupWizardScreenState extends ConsumerState<SetupWizardScreen> {
  int _step = 1;
  String _displayName = '';
  String? _gender;
  List<String> _interests = [];
  File? _profilePic;
  File? _coverPic;
  bool _locationGranted = false;
  String? _country;
  GeoPoint? _location;
  bool _isLoading = false;

  @override
  void initState() {
    super.initState();
    _loadPartialProgress();
  }

  Future<void> _loadPartialProgress() async {
    final prefs = await SharedPreferences.getInstance();
    final saved = prefs.getString('setup_partial');
    if (saved != null) {
      final map = jsonDecode(saved) as Map<String, dynamic>;
      setState(() {
        _step = map['step'] ?? 1;
        _displayName = map['displayName'] ?? '';
        _gender = map['gender'];
        _interests = List<String>.from(map['interests'] ?? []);
      });
    }
  }

  Future<void> _savePartialProgress() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(
      'setup_partial',
      jsonEncode({
        'step': _step,
        'displayName': _displayName,
        'gender': _gender,
        'interests': _interests,
      }),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Step $_step of 6'),
        automaticallyImplyLeading: false,
      ),
      body: _buildStep(),
    );
  }

  Widget _buildStep() {
    switch (_step) {
      case 1:
        return _StepDisplayName(
          initialValue: _displayName,
          onNext: (val) async {
            setState(() => _displayName = val);
            setState(() => _step++);
            await _savePartialProgress();
          },
        );
      case 2:
        return _StepLocation(
          onNext: (granted, country, loc) async {
            setState(() {
              _locationGranted = granted;
              _country = country;
              _location = loc;
            });
            setState(() => _step++);
            await _savePartialProgress();
          },
        );
      case 3:
        return _StepGender(
          initialValue: _gender,
          onNext: (val) async {
            setState(() => _gender = val);
            setState(() => _step++);
            await _savePartialProgress();
          },
        );
      case 4:
        return _StepInterests(
          initialValue: _interests,
          onNext: (val) async {
            setState(() => _interests = val);
            setState(() => _step++);
            await _savePartialProgress();
          },
        );
      case 5:
        return _StepProfilePic(
          initialImage: _profilePic,
          onNext: (val) {
            setState(() {
              _profilePic = val;
              _step++;
            });
          },
        );
      case 6:
        return _StepCoverPic(
          initialImage: _coverPic,
          onFinish: (val) async {
            setState(() => _coverPic = val);
            await _finishSetup();
          },
          isLoading: _isLoading,
        );
      default:
        return const SizedBox.shrink();
    }
  }

  Future<void> _finishSetup() async {
    setState(() => _isLoading = true);
    try {
      final uid = FirebaseAuth.instance.currentUser!.uid;
      String? profileUrl;
      String? coverUrl;

      if (_profilePic != null) {
        profileUrl = await R2Service.uploadPrivate(
          file: _profilePic!,
          key: 'users/profile/$uid/profile.jpg',
          contentType: 'image/jpeg',
        );
      }
      if (_coverPic != null) {
        coverUrl = await R2Service.uploadPrivate(
          file: _coverPic!,
          key: 'users/profile/$uid/cover.jpg',
          contentType: 'image/jpeg',
        );
      }

      await FirebaseFirestore.instance.collection('users').doc(uid).update({
        'displayName': _displayName,
        if (_gender != null) 'gender': _gender,
        'interests': _interests,
        'locationGranted': _locationGranted,
        if (_country != null) 'country': _country,
        if (_location != null) 'location': _location,
        if (profileUrl != null) 'profilePicUrl': profileUrl,
        if (profileUrl != null) 'hasProfilePic': true,
        if (coverUrl != null) 'coverPicUrl': coverUrl,
        if (coverUrl != null) 'hasCoverPic': true,
        'setupComplete': true,
        'updatedAt': FieldValue.serverTimestamp(),
      });

      // Clear partial progress
      final prefs = await SharedPreferences.getInstance();
      await prefs.remove('setup_partial');

      if (mounted) context.go('/buddies');
    } catch (e) {
      setState(() => _isLoading = false);
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Setup failed: $e')),
      );
    }
  }
}

// Step 1: Display Name
class _StepDisplayName extends StatefulWidget {
  final String initialValue;
  final Function(String) onNext;
  const _StepDisplayName({required this.initialValue, required this.onNext});

  @override
  State<_StepDisplayName> createState() => _StepDisplayNameState();
}

class _StepDisplayNameState extends State<_StepDisplayName> {
  late final _ctrl = TextEditingController(text: widget.initialValue);
  final _formKey = GlobalKey<FormState>();

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(24),
      child: Form(
        key: _formKey,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'What should we call you?',
              style: Theme.of(context)
                  .textTheme
                  .headlineSmall
                  ?.copyWith(fontWeight: FontWeight.w800),
            ),
            const SizedBox(height: 8),
            Text(
              'This name will be visible to other travelers.',
              style: TextStyle(color: Colors.grey[600]),
            ),
            const SizedBox(height: 24),
            TextFormField(
              controller: _ctrl,
              decoration: const InputDecoration(
                labelText: 'Display Name',
                hintText: 'e.g. Traveler Joe',
              ),
              validator: Validators.displayName,
            ),
            const Spacer(),
            ElevatedButton(
              onPressed: () {
                if (_formKey.currentState!.validate()) {
                  widget.onNext(_ctrl.text.trim());
                }
              },
              child: const Text('Next'),
            ),
          ],
        ),
      ),
    );
  }
}

// Step 2: Location
class _StepLocation extends StatelessWidget {
  final Function(bool granted, String? country, GeoPoint? loc) onNext;
  const _StepLocation({required this.onNext});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(24),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Enable location?',
            style: Theme.of(context)
                .textTheme
                .headlineSmall
                ?.copyWith(fontWeight: FontWeight.w800),
          ),
          const SizedBox(height: 8),
          Text(
            'We use your location to show nearby travel buddies and rank posts for your area.',
            style: TextStyle(color: Colors.grey[600]),
          ),
          const Spacer(),
          ElevatedButton(
            onPressed: () async {
              final granted = await PermissionHelper.requestLocation(context);
              if (granted) {
                try {
                  final pos = await Geolocator.getCurrentPosition();
                  final placemarks = await placemarkFromCoordinates(
                    pos.latitude,
                    pos.longitude,
                  );
                  final country = placemarks.first.isoCountryCode;
                  onNext(
                    true,
                    country,
                    GeoPoint(pos.latitude, pos.longitude),
                  );
                } catch (_) {
                  onNext(true, null, null);
                }
              } else {
                onNext(false, null, null);
              }
            },
            child: const Text('Enable Location'),
          ),
          const SizedBox(height: 12),
          OutlinedButton(
            onPressed: () => onNext(false, null, null),
            child: const Text('Skip'),
          ),
        ],
      ),
    );
  }
}

// Step 3: Gender
class _StepGender extends StatefulWidget {
  final String? initialValue;
  final Function(String?) onNext;
  const _StepGender({required this.initialValue, required this.onNext});

  @override
  State<_StepGender> createState() => _StepGenderState();
}

class _StepGenderState extends State<_StepGender> {
  String? _selected;

  @override
  void initState() {
    super.initState();
    _selected = widget.initialValue;
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(24),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'What\'s your gender?',
            style: Theme.of(context)
                .textTheme
                .headlineSmall
                ?.copyWith(fontWeight: FontWeight.w800),
          ),
          const SizedBox(height: 8),
          Text(
            'This helps us personalize your experience.',
            style: TextStyle(color: Colors.grey[600]),
          ),
          const SizedBox(height: 24),
          Wrap(
            spacing: 12,
            runSpacing: 12,
            children: AppConstants.genderOptions.map((g) {
              final isSelected = _selected == g;
              return ChoiceChip(
                label: Text(g),
                selected: isSelected,
                onSelected: (_) => setState(() => _selected = g),
              );
            }).toList(),
          ),
          const Spacer(),
          ElevatedButton(
            onPressed: () => widget.onNext(_selected),
            child: const Text('Next'),
          ),
          const SizedBox(height: 8),
          TextButton(
            onPressed: () => widget.onNext(null),
            child: const Text('Prefer not to say'),
          ),
        ],
      ),
    );
  }
}

// Step 4: Interests
class _StepInterests extends StatefulWidget {
  final List<String> initialValue;
  final Function(List<String>) onNext;
  const _StepInterests({required this.initialValue, required this.onNext});

  @override
  State<_StepInterests> createState() => _StepInterestsState();
}

class _StepInterestsState extends State<_StepInterests> {
  late List<String> _selected;

  @override
  void initState() {
    super.initState();
    _selected = List.from(widget.initialValue);
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(24),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Travel Interests',
            style: Theme.of(context)
                .textTheme
                .headlineSmall
                ?.copyWith(fontWeight: FontWeight.w800),
          ),
          const SizedBox(height: 8),
          Text(
            'Select what you love. This helps us find the best content for you.',
            style: TextStyle(color: Colors.grey[600]),
          ),
          const SizedBox(height: 16),
          Wrap(
            spacing: 10,
            runSpacing: 10,
            children: AppConstants.travelInterests.map((interest) {
              final isSelected = _selected.contains(interest);
              return FilterChip(
                label: Text(interest),
                selected: isSelected,
                onSelected: (sel) {
                  setState(() {
                    if (sel) {
                      _selected.add(interest);
                    } else {
                      _selected.remove(interest);
                    }
                  });
                },
              );
            }).toList(),
          ),
          const Spacer(),
          ElevatedButton(
            onPressed: () => widget.onNext(_selected),
            child: const Text('Next'),
          ),
          const SizedBox(height: 8),
          TextButton(
            onPressed: () => widget.onNext([]),
            child: const Text('Skip for now'),
          ),
        ],
      ),
    );
  }
}

// Step 5: Profile Picture
class _StepProfilePic extends StatelessWidget {
  final File? initialImage;
  final Function(File?) onNext;
  const _StepProfilePic({required this.initialImage, required this.onNext});

  @override
  Widget build(BuildContext context) {
    return _PhotoStep(
      title: 'Add a profile picture',
      subtitle: 'Let others see who they\'re traveling with.',
      aspectRatio: 1,
      isCircle: true,
      initialImage: initialImage,
      onNext: onNext,
    );
  }
}

// Step 6: Cover Picture
class _StepCoverPic extends StatelessWidget {
  final File? initialImage;
  final Function(File?) onFinish;
  final bool isLoading;
  const _StepCoverPic({
    required this.initialImage,
    required this.onFinish,
    required this.isLoading,
  });

  @override
  Widget build(BuildContext context) {
    return _PhotoStep(
      title: 'Add a cover photo',
      subtitle: 'Show off your favorite travel moment.',
      aspectRatio: 16 / 9,
      isCircle: false,
      initialImage: initialImage,
      onNext: onFinish,
      isLastStep: true,
      isLoading: isLoading,
    );
  }
}

// Reusable photo step widget WITH cropping support
class _PhotoStep extends StatefulWidget {
  final String title;
  final String subtitle;
  final double aspectRatio;
  final bool isCircle;
  final File? initialImage;
  final Function(File?) onNext;
  final bool isLastStep;
  final bool isLoading;

  const _PhotoStep({
    required this.title,
    required this.subtitle,
    required this.aspectRatio,
    required this.isCircle,
    required this.initialImage,
    required this.onNext,
    this.isLastStep = false,
    this.isLoading = false,
  });

  @override
  State<_PhotoStep> createState() => _PhotoStepState();
}

class _PhotoStepState extends State<_PhotoStep> {
  File? _image;
  Uint8List? _imageBytes;
  final _cropController = CropController();
  bool _isCropping = false;

  @override
  void initState() {
    super.initState();
    _image = widget.initialImage;
  }

  Future<void> _pickImage() async {
    final picker = ImagePicker();
    final picked = await picker.pickImage(source: ImageSource.gallery);
    if (picked != null) {
      final bytes = await picked.readAsBytes();
      if (widget.isCircle) {
        // Use crop_your_image for circle profile pic (1:1)
        setState(() {
          _imageBytes = bytes;
          _isCropping = true;
        });
      } else {
        // Use image_cropper for cover photo (16:9)
        final cropped = await ImageCropper().cropImage(
          sourcePath: picked.path,
          aspectRatio: const CropAspectRatio(ratioX: 16, ratioY: 9),
          uiSettings: [
            AndroidUiSettings(
              toolbarTitle: 'Crop Cover Photo',
              toolbarColor: const Color(0xFFB0213F),
              toolbarWidgetColor: Colors.white,
              initAspectRatio: CropAspectRatioPreset.ratio16x9,
              lockAspectRatio: true,
            ),
            IOSUiSettings(
              title: 'Crop Cover Photo',
              aspectRatioLockEnabled: true,
            ),
          ],
        );
        if (cropped != null) {
          setState(() => _image = File(cropped.path));
        }
      }
    }
  }

  Future<void> _onCropDone(Uint8List croppedBytes) async {
    // Save cropped bytes to temp file
    final tempDir = await getTemporaryDirectory();
    final tempFile = File('${tempDir.path}/profile_cropped_${DateTime.now().millisecondsSinceEpoch}.jpg');
    await tempFile.writeAsBytes(croppedBytes);
    setState(() {
      _image = tempFile;
      _isCropping = false;
      _imageBytes = null;
    });
  }

  void _onCropCancel() {
    setState(() {
      _isCropping = false;
      _imageBytes = null;
    });
  }

  @override
  Widget build(BuildContext context) {
    // Show cropping UI when cropping profile pic
    if (_isCropping && _imageBytes != null) {
      return Column(
        children: [
          AppBar(
            title: const Text('Crop Profile Picture'),
            leading: IconButton(
              icon: const Icon(Icons.close),
              onPressed: _onCropCancel,
            ),
            actions: [
              TextButton(
                onPressed: () => _cropController.crop(),
                child: const Text('DONE', style: TextStyle(color: Colors.white)),
              ),
            ],
          ),
          Expanded(
            child: Crop(
              controller: _cropController,
              image: _imageBytes!,
              onCropped: _onCropDone,
              aspectRatio: 1,
              withCircleUi: true,
            ),
          ),
        ],
      );
    }

    return Padding(
      padding: const EdgeInsets.all(24),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            widget.title,
            style: Theme.of(context)
                .textTheme
                .headlineSmall
                ?.copyWith(fontWeight: FontWeight.w800),
          ),
          const SizedBox(height: 8),
          Text(
            widget.subtitle,
            style: TextStyle(color: Colors.grey[600]),
          ),
          const SizedBox(height: 32),
          Center(
            child: GestureDetector(
              onTap: _pickImage,
              child: widget.isCircle
                  ? CircleAvatar(
                      radius: 80,
                      backgroundImage:
                          _image != null ? FileImage(_image!) : null,
                      child: _image == null
                          ? const Icon(Icons.camera_alt, size: 40)
                          : null,
                    )
                  : ClipRRect(
                      borderRadius: BorderRadius.circular(18),
                      child: _image != null
                          ? Image.file(
                              _image!,
                              height: 160,
                              width: double.infinity,
                              fit: BoxFit.cover,
                            )
                          : Container(
                              height: 160,
                              width: double.infinity,
                              decoration: BoxDecoration(
                                color: Colors.grey[200],
                                borderRadius: BorderRadius.circular(18),
                              ),
                              child: const Icon(Icons.camera_alt, size: 40),
                            ),
                    ),
            ),
          ),
          const Spacer(),
          if (widget.isLoading)
            const Center(child: CircularProgressIndicator())
          else
            ElevatedButton(
              onPressed: () => widget.onNext(_image),
              child: Text(widget.isLastStep ? 'Finish' : 'Next'),
            ),
          const SizedBox(height: 8),
          if (!widget.isLastStep)
            TextButton(
              onPressed: () => widget.onNext(null),
              child: const Text('Skip'),
            ),
        ],
      ),
    );
  }
}
