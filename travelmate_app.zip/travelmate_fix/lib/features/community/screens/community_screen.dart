import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:timeago/timeago.dart' as timeago;
import '../../../core/utils/error_handler.dart';
import '../../../core/widgets/empty_states.dart';
import '../../../core/widgets/shimmer_cards.dart';
import '../providers/community_provider.dart';

class CommunityScreen extends ConsumerWidget {
  const CommunityScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final state = ref.watch(communityProvider);

    if (state.error != null) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        showErrorSnack(context, state.error);
      });
    }

    return Scaffold(
      appBar: AppBar(
        title: const Text('Community'),
        actions: [
          IconButton(
            icon: const Icon(Icons.add_circle_outline),
            onPressed: () => _showCreatePost(context, ref),
          ),
        ],
      ),
      body: state.isLoading
          ? const SkeletonFeedList(cardBuilder: BuddyCardSkeleton.new)
          : state.posts.isEmpty
              ? EmptyCommunityFeed(onShare: () => _showCreatePost(context, ref))
              : ListView.builder(
                  itemCount: state.posts.length,
                  itemBuilder: (context, index) {
                    final post = state.posts[index];
                    return _CommunityPostCard(post: post);
                  },
                ),
    );
  }

  void _showCreatePost(BuildContext context, WidgetRef ref) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      builder: (_) => _CreateCommunityPostSheet(ref: ref),
    );
  }
}

class _CommunityPostCard extends StatelessWidget {
  final dynamic post;
  const _CommunityPostCard({required this.post});

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [
            CircleAvatar(
              backgroundImage: post.authorPhotoUrl != null
                  ? NetworkImage(post.authorPhotoUrl!) : null,
              child: post.authorPhotoUrl == null
                  ? Text(post.authorName.isNotEmpty ? post.authorName[0].toUpperCase() : '?') : null,
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(post.authorName, style: const TextStyle(fontWeight: FontWeight.w700)),
                Text(
                  post.createdAt != null ? timeago.format(post.createdAt!.toDate()) : '',
                  style: TextStyle(fontSize: 12, color: Colors.grey[600]),
                ),
              ]),
            ),
          ]),
          const SizedBox(height: 12),
          Text(post.text),
          if (post.mediaUrls.isNotEmpty) ...[
            const SizedBox(height: 12),
            ClipRRect(
              borderRadius: BorderRadius.circular(12),
              child: Image.network(
                post.mediaUrls.first,
                height: 200,
                width: double.infinity,
                fit: BoxFit.cover,
                errorBuilder: (_, __, ___) => Container(
                  height: 200, color: Colors.grey[300],
                  child: const Icon(Icons.broken_image),
                ),
              ),
            ),
          ],
          const SizedBox(height: 12),
          Row(children: [
            _ReactionBtn(post: post),
            const SizedBox(width: 16),
            _ActionBtn(icon: Icons.comment_outlined, label: '${post.commentsCount}'),
            const SizedBox(width: 16),
            _ActionBtn(icon: Icons.bookmark_border, label: '${post.savedCount}'),
            const Spacer(),
            _ActionBtn(icon: Icons.share_outlined, label: ''),
          ]),
        ]),
      ),
    );
  }
}

class _ReactionBtn extends StatelessWidget {
  final dynamic post;
  const _ReactionBtn({required this.post});

  @override
  Widget build(BuildContext context) {
    final likes = post.reactionsCount['like'] ?? 0;
    return InkWell(
      onTap: () {},
      borderRadius: BorderRadius.circular(8),
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
        child: Row(mainAxisSize: MainAxisSize.min, children: [
          Icon(Icons.favorite_border, size: 18, color: Colors.grey[600]),
          const SizedBox(width: 4),
          Text('$likes', style: TextStyle(color: Colors.grey[600], fontSize: 13)),
        ]),
      ),
    );
  }
}

class _ActionBtn extends StatelessWidget {
  final IconData icon;
  final String label;
  const _ActionBtn({required this.icon, required this.label});

  @override
  Widget build(BuildContext context) {
    return InkWell(
      borderRadius: BorderRadius.circular(8),
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
        child: Row(mainAxisSize: MainAxisSize.min, children: [
          Icon(icon, size: 18, color: Colors.grey[600]),
          if (label.isNotEmpty) ...[const SizedBox(width: 4), Text(label, style: TextStyle(color: Colors.grey[600], fontSize: 13))],
        ]),
      ),
    );
  }
}

class _CreateCommunityPostSheet extends ConsumerStatefulWidget {
  final WidgetRef ref;
  const _CreateCommunityPostSheet({required this.ref});

  @override
  ConsumerState<_CreateCommunityPostSheet> createState() => _CreateCommunityPostSheetState();
}

class _CreateCommunityPostSheetState extends ConsumerState<_CreateCommunityPostSheet> {
  final _textCtrl = TextEditingController();

  @override
  void dispose() {
    _textCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final state = ref.watch(communityProvider);

    return Padding(
      padding: EdgeInsets.only(
        bottom: MediaQuery.of(context).viewInsets.bottom,
        left: 24, right: 24, top: 24,
      ),
      child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text('Share Experience', style: Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.w800)),
        const SizedBox(height: 16),
        TextField(controller: _textCtrl, maxLines: 4,
          decoration: const InputDecoration(hintText: 'Share your travel experience...')),
        const SizedBox(height: 16),
        if (state.isCreating)
          const Center(child: CircularProgressIndicator())
        else
          ElevatedButton(
            onPressed: () async {
              if (_textCtrl.text.trim().isEmpty) return;
              final success = await ref.read(communityProvider.notifier).createPost(
                text: _textCtrl.text.trim(),
              );
              if (success && mounted) {
                Navigator.pop(context);
                showSuccessSnack(context, 'Posted!');
              }
            },
            child: const Text('Share'),
          ),
        const SizedBox(height: 24),
      ]),
    );
  }
}
