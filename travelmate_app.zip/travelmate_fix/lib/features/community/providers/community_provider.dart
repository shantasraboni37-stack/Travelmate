import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../core/repositories/post_repository.dart';
import '../../../models/post.dart';

class CommunityState {
  final List<Post> posts;
  final bool isLoading;
  final String? error;
  final bool isCreating;

  const CommunityState({
    this.posts = const [],
    this.isLoading = false,
    this.error,
    this.isCreating = false,
  });

  CommunityState copyWith({
    List<Post>? posts,
    bool? isLoading,
    String? error,
    bool? isCreating,
  }) {
    return CommunityState(
      posts: posts ?? this.posts,
      isLoading: isLoading ?? this.isLoading,
      error: error ?? this.error,
      isCreating: isCreating ?? this.isCreating,
    );
  }
}

class CommunityNotifier extends StateNotifier<CommunityState> {
  final PostRepository _repository;

  CommunityNotifier(this._repository) : super(const CommunityState(isLoading: true));

  void loadPosts() {
    try {
      state = state.copyWith(isLoading: true, error: null);
      _repository.getCommunityPosts().listen(
        (posts) {
          if (mounted) {
            state = state.copyWith(posts: posts, isLoading: false);
          }
        },
        onError: (e) {
          if (mounted) {
            state = state.copyWith(error: e.toString(), isLoading: false);
          }
        },
      );
    } catch (e) {
      state = state.copyWith(error: e.toString(), isLoading: false);
    }
  }

  Future<bool> createPost({required String text, List<String>? mediaUrls}) async {
    try {
      state = state.copyWith(isCreating: true, error: null);
      final uid = FirebaseAuth.instance.currentUser?.uid;
      if (uid == null) throw Exception('Not logged in');

      final userDoc = await FirebaseFirestore.instance
          .collection('users')
          .doc(uid)
          .get();
      final userData = userDoc.data();

      final post = Post(
        postId: '',
        authorUid: uid,
        authorName: userData?['displayName'] ?? 'Unknown',
        authorPhotoUrl: userData?['profilePicUrl'],
        postType: 'community',
        text: text,
        mediaUrls: mediaUrls ?? [],
        country: userData?['country'],
        interests: List<String>.from(userData?['interests'] ?? []),
      );

      await _repository.createPost(post);
      state = state.copyWith(isCreating: false);
      return true;
    } catch (e) {
      state = state.copyWith(error: e.toString(), isCreating: false);
      return false;
    }
  }

  Future<void> toggleLike(String postId) async {
    try {
      final uid = FirebaseAuth.instance.currentUser?.uid;
      if (uid == null) return;
      await _repository.toggleLike(postId, uid);
    } catch (e) {
      state = state.copyWith(error: e.toString());
    }
  }
}

final communityProvider = StateNotifierProvider<CommunityNotifier, CommunityState>((ref) {
  return CommunityNotifier(PostRepository())..loadPosts();
});
