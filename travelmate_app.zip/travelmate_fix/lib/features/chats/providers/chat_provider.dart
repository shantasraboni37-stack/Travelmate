import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../core/repositories/chat_repository.dart';
import '../../../models/chat.dart';

class ChatState {
  final List<Chat> chats;
  final bool isLoading;
  final String? error;
  final bool isSending;

  const ChatState({
    this.chats = const [],
    this.isLoading = false,
    this.error,
    this.isSending = false,
  });

  ChatState copyWith({
    List<Chat>? chats,
    bool? isLoading,
    String? error,
    bool? isSending,
  }) {
    return ChatState(
      chats: chats ?? this.chats,
      isLoading: isLoading ?? this.isLoading,
      error: error ?? this.error,
      isSending: isSending ?? this.isSending,
    );
  }
}

class ChatNotifier extends StateNotifier<ChatState> {
  final ChatRepository _repository;

  ChatNotifier(this._repository) : super(const ChatState(isLoading: true));

  void loadChats() {
    final uid = FirebaseAuth.instance.currentUser?.uid;
    if (uid == null) {
      state = state.copyWith(isLoading: false);
      return;
    }
    try {
      state = state.copyWith(isLoading: true, error: null);
      _repository.getUserChats(uid).listen(
        (chats) {
          if (mounted) state = state.copyWith(chats: chats, isLoading: false);
        },
        onError: (e) {
          if (mounted) state = state.copyWith(error: e.toString(), isLoading: false);
        },
      );
    } catch (e) {
      state = state.copyWith(error: e.toString(), isLoading: false);
    }
  }

  Future<bool> sendMessage(String chatId, String content) async {
    try {
      state = state.copyWith(isSending: true, error: null);
      final uid = FirebaseAuth.instance.currentUser?.uid;
      if (uid == null) throw Exception('Not logged in');
      await _repository.sendMessage(
        chatId: chatId,
        senderId: uid,
        content: content,
      );
      state = state.copyWith(isSending: false);
      return true;
    } catch (e) {
      state = state.copyWith(error: e.toString(), isSending: false);
      return false;
    }
  }

  Future<void> markAsRead(String chatId) async {
    try {
      final uid = FirebaseAuth.instance.currentUser?.uid;
      if (uid == null) return;
      await _repository.markAsRead(chatId, uid);
    } catch (e) {
      state = state.copyWith(error: e.toString());
    }
  }

  Future<String> getOrCreateChat(String otherUserId) async {
    final uid = FirebaseAuth.instance.currentUser?.uid;
    if (uid == null) throw Exception('Not logged in');
    return await _repository.getOrCreateChat(uid, otherUserId);
  }
}

final chatProvider = StateNotifierProvider<ChatNotifier, ChatState>((ref) {
  return ChatNotifier(ChatRepository())..loadChats();
});

// Messages provider for a specific chat
final chatMessagesProvider = StreamProvider.family<List<Message>, String>((ref, chatId) {
  return ChatRepository().getChatMessages(chatId);
});
