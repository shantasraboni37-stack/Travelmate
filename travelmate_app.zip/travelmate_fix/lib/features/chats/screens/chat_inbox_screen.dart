import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:timeago/timeago.dart' as timeago;
import '../../../core/utils/error_handler.dart';
import '../../../core/widgets/auth_image.dart';
import '../../../core/widgets/empty_states.dart';
import '../../../core/widgets/shimmer_cards.dart';
import '../providers/chat_provider.dart';

/// Stream provider for online friends (only from friends list)
final onlineFriendsProvider = StreamProvider<List<Map<String, dynamic>>>((ref) {
  final myUid = FirebaseAuth.instance.currentUser?.uid;
  if (myUid == null) return Stream.value([]);

  // First get user's friends list from Firestore
  return FirebaseFirestore.instance
      .collection('users')
      .doc(myUid)
      .snapshots()
      .asyncMap((userDoc) async {
    final data = userDoc.data();
    final friends = List<String>.from(data?['friends'] ?? []);

    if (friends.isEmpty) return <Map<String, dynamic>>[];

    // Check online status from RTDB for friends only
    final onlineFriends = <Map<String, dynamic>>[];
    final statusRef = FirebaseDatabase.instance.ref('status');

    for (final friendUid in friends) {
      try {
        final snapshot = await statusRef.child('$friendUid/online').get();
        if (snapshot.exists && snapshot.value == true) {
          // Fetch user details (cached per friend)
          final friendDoc = await FirebaseFirestore.instance
              .collection('users')
              .doc(friendUid)
              .get(const GetOptions(source: Source.serverAndCache));
          final friendData = friendDoc.data();
          if (friendData != null) {
            onlineFriends.add({
              'uid': friendUid,
              'displayName': friendData['displayName'] ?? 'User',
              'profilePicUrl': friendData['profilePicUrl'],
            });
          }
        }
      } catch (_) {
        // Skip friends we can't fetch
      }
    }

    return onlineFriends;
  });
});

class ChatInboxScreen extends ConsumerWidget {
  const ChatInboxScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final state = ref.watch(chatProvider);
    final onlineFriendsAsync = ref.watch(onlineFriendsProvider);

    if (state.error != null) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        showErrorSnack(context, state.error);
      });
    }

    return Scaffold(
      appBar: AppBar(
        title: const Text('Messages'),
        actions: [
          IconButton(
            icon: const Icon(Icons.group_add_outlined),
            onPressed: () {},
          ),
        ],
      ),
      body: Column(
        children: [
          // Online Friends horizontal row
          onlineFriendsAsync.when(
            data: (friends) {
              if (friends.isEmpty) return const SizedBox.shrink();
              return _OnlineFriendsRow(friends: friends);
            },
            loading: () => const SizedBox.shrink(),
            error: (_, __) => const SizedBox.shrink(),
          ),
          // Chat list
          Expanded(
            child: state.isLoading
                ? SkeletonFeedList(cardBuilder: ChatCardSkeleton.new, count: 5)
                : state.chats.isEmpty
                    ? const EmptyChatInbox()
                    : ListView.builder(
                        itemCount: state.chats.length,
                        itemBuilder: (context, index) {
                          final chat = state.chats[index];
                          return _ChatTile(chat: chat);
                        },
                      ),
          ),
        ],
      ),
    );
  }
}

/// Horizontal scrollable row of online friends with green dot indicator
class _OnlineFriendsRow extends ConsumerWidget {
  final List<Map<String, dynamic>> friends;
  const _OnlineFriendsRow({required this.friends});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return Container(
      height: 90,
      padding: const EdgeInsets.symmetric(vertical: 8),
      child: ListView.builder(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.symmetric(horizontal: 12),
        itemCount: friends.length,
        itemBuilder: (context, index) {
          final friend = friends[index];
          return GestureDetector(
            onTap: () async {
              // Open chat with this friend
              final chatNotifier = ref.read(chatProvider.notifier);
              try {
                final chatId = await chatNotifier.getOrCreateChat(friend['uid']);
                if (context.mounted) {
                  context.push('/chat/$chatId');
                }
              } catch (e) {
                if (context.mounted) {
                  showErrorSnack(context, 'Failed to open chat');
                }
              }
            },
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 8),
              child: Column(
                children: [
                  Stack(
                    children: [
                      AuthCircleAvatar(
                        imageUrl: friend['profilePicUrl'],
                        radius: 28,
                        fallbackText: (friend['displayName'] as String? ?? 'U')[0].toUpperCase(),
                      ),
                      // Green online dot
                      Positioned(
                        right: 0,
                        bottom: 0,
                        child: Container(
                          width: 14,
                          height: 14,
                          decoration: BoxDecoration(
                            color: Colors.green,
                            shape: BoxShape.circle,
                            border: Border.all(color: Colors.white, width: 2),
                          ),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 4),
                  SizedBox(
                    width: 56,
                    child: Text(
                      friend['displayName'] ?? 'User',
                      style: const TextStyle(fontSize: 12),
                      overflow: TextOverflow.ellipsis,
                      textAlign: TextAlign.center,
                    ),
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }
}

class _ChatTile extends StatelessWidget {
  final dynamic chat;
  const _ChatTile({required this.chat});

  @override
  Widget build(BuildContext context) {
    final unread = (chat.unreadCounts as Map<String, dynamic>?)
            ?.values
            .fold<int>(0, (sum, v) => sum + ((v as num?)?.toInt() ?? 0)) ??
        0;
    final lastMsg = chat.lastMessage as String?;
    final lastTime = chat.lastMessageTime;

    return ListTile(
      leading: Stack(children: [
        AuthCircleAvatar(
          imageUrl: chat.groupPhotoUrl,
          fallbackText: chat.groupName?.isNotEmpty == true
              ? chat.groupName![0].toUpperCase()
              : 'C',
        ),
        if (unread > 0)
          Positioned(
            right: 0, top: 0,
            child: Container(
              padding: const EdgeInsets.all(4),
              decoration: const BoxDecoration(
                color: Color(0xFFB0213F), shape: BoxShape.circle),
              constraints: const BoxConstraints(minWidth: 16, minHeight: 16),
              child: Text('$unread',
                style: const TextStyle(color: Colors.white, fontSize: 10, fontWeight: FontWeight.w700),
                textAlign: TextAlign.center),
            ),
          ),
      ]),
      title: Text(
        chat.groupName ?? 'Chat',
        style: TextStyle(fontWeight: unread > 0 ? FontWeight.w700 : FontWeight.w500),
      ),
      subtitle: Text(
        lastMsg ?? 'No messages yet',
        maxLines: 1, overflow: TextOverflow.ellipsis,
        style: TextStyle(
          color: unread > 0 ? Colors.black87 : Colors.grey[600],
          fontWeight: unread > 0 ? FontWeight.w600 : FontWeight.normal,
        ),
      ),
      trailing: lastTime != null
          ? Text(timeago.format(lastTime.toDate()),
              style: TextStyle(fontSize: 11, color: Colors.grey[500]))
          : null,
      onTap: () {
        final chatId = chat.chatId as String? ?? '';
        if (chatId.isNotEmpty) context.push('/chat/$chatId');
      },
    );
  }
}
