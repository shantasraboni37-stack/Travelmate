import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../core/utils/error_handler.dart';
import '../../../core/widgets/message_tick.dart';
import '../providers/chat_provider.dart';
import '../../../models/chat.dart';

class ChatDetailScreen extends ConsumerStatefulWidget {
  final String chatId;
  const ChatDetailScreen({super.key, required this.chatId});

  @override
  ConsumerState<ChatDetailScreen> createState() => _ChatDetailScreenState();
}

class _ChatDetailScreenState extends ConsumerState<ChatDetailScreen> {
  final _msgCtrl = TextEditingController();
  final _scrollCtrl = ScrollController();
  String? _myUid;

  @override
  void initState() {
    super.initState();
    _myUid = FirebaseAuth.instance.currentUser?.uid;
    _markAsRead();
    _updateOnlineStatus(true);
  }

  @override
  void dispose() {
    _msgCtrl.dispose();
    _scrollCtrl.dispose();
    _updateOnlineStatus(false);
    super.dispose();
  }

  /// Write/remove active_chats/{chatId}/{uid} RTDB node for delivered ticks
  void _updateOnlineStatus(bool online) {
    final uid = _myUid;
    if (uid == null) return;
    final ref = FirebaseDatabase.instance.ref('active_chats/${widget.chatId}/$uid');
    if (online) {
      ref.set(true);
    } else {
      ref.remove();
    }
  }

  void _markAsRead() {
    ref.read(chatProvider.notifier).markAsRead(widget.chatId);
  }

  Future<void> _sendMessage() async {
    final text = _msgCtrl.text.trim();
    if (text.isEmpty) return;
    _msgCtrl.clear();
    final success = await ref.read(chatProvider.notifier).sendMessage(widget.chatId, text);
    if (!success && mounted) {
      showErrorSnack(context, ref.read(chatProvider).error ?? 'Failed to send message');
    }
  }

  @override
  Widget build(BuildContext context) {
    final chatState = ref.watch(chatProvider);
    final messagesAsync = ref.watch(chatMessagesProvider(widget.chatId));

    // Safely find current chat - avoid RangeError when chat not loaded yet
    final currentChat = chatState.chats.isEmpty
        ? null
        : chatState.chats.cast<Chat?>().firstWhere(
            (c) => c?.chatId == widget.chatId,
            orElse: () => null,
          );

    return Scaffold(
      appBar: AppBar(
        title: const Text('Chat', style: TextStyle(fontWeight: FontWeight.w800)),
        actions: [
          IconButton(icon: const Icon(Icons.videocam_outlined), onPressed: () {}),
        ],
      ),
      body: Column(children: [
        Expanded(
          child: messagesAsync.when(
            data: (messages) => ListView.builder(
              reverse: true,
              controller: _scrollCtrl,
              itemCount: messages.length,
              itemBuilder: (context, index) {
                final msg = messages[index];
                // Proper isMe logic: compare senderId with current user's UID
                final isMe = msg.senderId == _myUid;
                return _MessageBubble(message: msg, isMe: isMe);
              },
            ),
            loading: () => const Center(child: CircularProgressIndicator()),
            error: (err, _) {
              WidgetsBinding.instance.addPostFrameCallback((_) {
                showErrorSnack(context, err);
              });
              return Center(child: Text('Error: $err'));
            },
          ),
        ),
        _buildInputArea(),
      ]),
    );
  }

  Widget _buildInputArea() {
    final state = ref.watch(chatProvider);
    return SafeArea(
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
        decoration: BoxDecoration(
          color: Theme.of(context).cardColor,
          border: Border(top: BorderSide(color: Theme.of(context).dividerColor)),
        ),
        child: Row(children: [
          IconButton(icon: const Icon(Icons.add_circle_outline), onPressed: () {}),
          Expanded(
            child: TextField(
              controller: _msgCtrl,
              textInputAction: TextInputAction.send,
              onSubmitted: (_) => _sendMessage(),
              decoration: const InputDecoration(
                hintText: 'Type a message...',
                contentPadding: EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                border: OutlineInputBorder(borderRadius: BorderRadius.all(Radius.circular(24))),
              ),
            ),
          ),
          state.isSending
              ? const SizedBox(width: 48, child: Center(child: SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2))))
              : IconButton(
                  icon: const Icon(Icons.send, color: Color(0xFFB0213F)),
                  onPressed: _sendMessage,
                ),
        ]),
      ),
    );
  }
}

class _MessageBubble extends StatelessWidget {
  final Message message;
  final bool isMe;
  const _MessageBubble({required this.message, required this.isMe});

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    return Align(
      alignment: isMe ? Alignment.centerRight : Alignment.centerLeft,
      child: Container(
        margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
        constraints: BoxConstraints(maxWidth: MediaQuery.of(context).size.width * 0.75),
        decoration: BoxDecoration(
          color: isMe ? const Color(0xFFB0213F) : (isDark ? const Color(0xFF3A3C3C) : const Color(0xFFF0F0F0)),
          borderRadius: BorderRadius.only(
            topLeft: const Radius.circular(16), topRight: const Radius.circular(16),
            bottomLeft: Radius.circular(isMe ? 16 : 4),
            bottomRight: Radius.circular(isMe ? 4 : 16),
          ),
        ),
        child: Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
          Text(message.content,
            style: TextStyle(
              color: isMe ? Colors.white : (isDark ? Colors.white : Colors.black87), fontSize: 15)),
          const SizedBox(height: 4),
          if (isMe)
            MessageTick(
              status: message.status == 'seen' ? MessageStatus.seen : MessageStatus.sent,
              color: Colors.white70,
            ),
        ]),
      ),
    );
  }
}
