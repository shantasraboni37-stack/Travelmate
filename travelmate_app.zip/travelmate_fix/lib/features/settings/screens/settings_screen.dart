import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import '../../../core/utils/error_handler.dart';
import '../../auth/providers/auth_provider.dart';
import '../../profile/providers/profile_provider.dart';

class SettingsScreen extends ConsumerWidget {
  const SettingsScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return Scaffold(
      appBar: AppBar(title: const Text('Settings')),
      body: ListView(children: [
        _SectionHeader(title: 'Account'),
        ListTile(
          leading: const Icon(Icons.lock_outline),
          title: const Text('Change Password'),
          trailing: const Icon(Icons.chevron_right),
          onTap: () => _showChangePassword(context, ref),
        ),
        ListTile(
          leading: const Icon(Icons.email_outlined),
          title: const Text('Change Email'),
          trailing: const Icon(Icons.chevron_right),
          onTap: () => _showChangeEmail(context, ref),
        ),
        ListTile(
          leading: const Icon(Icons.delete_forever_outlined, color: Colors.red),
          title: const Text('Delete Account', style: TextStyle(color: Colors.red)),
          onTap: () => _showDeleteAccount(context, ref),
        ),
        _SectionHeader(title: 'Privacy'),
        ListTile(
          leading: const Icon(Icons.visibility_outlined),
          title: const Text('Active Status'),
          trailing: const Icon(Icons.chevron_right),
          onTap: () => _showSelectionDialog(context, ref, 'activeStatus',
              ['public', 'friends_only', 'hidden']),
        ),
        ListTile(
          leading: const Icon(Icons.message_outlined),
          title: const Text('Message Requests'),
          trailing: const Icon(Icons.chevron_right),
          onTap: () => _showSelectionDialog(context, ref, 'messageRequests',
              ['inbox', 'requests', 'off']),
        ),
        ListTile(
          leading: const Icon(Icons.done_all_outlined),
          title: const Text('Read Receipts'),
          trailing: const Icon(Icons.chevron_right),
          onTap: () => _toggleSetting(context, ref, 'readReceipts'),
        ),
        ListTile(
          leading: const Icon(Icons.edit_note_outlined),
          title: const Text('Typing Indicator'),
          trailing: const Icon(Icons.chevron_right),
          onTap: () => _toggleSetting(context, ref, 'typingIndicator'),
        ),
        _SectionHeader(title: 'App'),
        ListTile(
          leading: const Icon(Icons.dark_mode_outlined),
          title: const Text('Dark Mode'),
          trailing: const Icon(Icons.chevron_right),
          onTap: () => _showSelectionDialog(context, ref, 'darkMode',
              ['system', 'light', 'dark']),
        ),
        _SectionHeader(title: 'Support'),
        ListTile(
          leading: const Icon(Icons.help_outline),
          title: const Text('Help & Support'),
          trailing: const Icon(Icons.chevron_right),
          onTap: () => _showHelpSupport(context),
        ),
        const SizedBox(height: 16),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16),
          child: ElevatedButton(
            onPressed: () {
              ref.read(authNotifierProvider.notifier).signOut();
              context.go('/auth');
            },
            style: ElevatedButton.styleFrom(backgroundColor: Colors.red, foregroundColor: Colors.white),
            child: const Text('Sign Out'),
          ),
        ),
        const SizedBox(height: 32),
      ]),
    );
  }

  void _showChangePassword(BuildContext context, WidgetRef ref) {
    final newCtrl = TextEditingController();
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Change Password'),
        content: TextField(
          controller: newCtrl, obscureText: true,
          decoration: const InputDecoration(labelText: 'New Password')),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Cancel')),
          ElevatedButton(
            onPressed: () async {
              try {
                await ref.read(profileProvider.notifier).updateProfile();
                if (ctx.mounted) {
                  Navigator.pop(ctx);
                  showSuccessSnack(context, 'Password updated - check your email');
                }
              } catch (e) {
                if (ctx.mounted) showErrorSnack(context, e);
              }
            },
            child: const Text('Update')),
        ],
      ),
    );
  }

  void _showChangeEmail(BuildContext context, WidgetRef ref) {
    final emailCtrl = TextEditingController();
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Change Email'),
        content: TextField(
          controller: emailCtrl, keyboardType: TextInputType.emailAddress,
          decoration: const InputDecoration(labelText: 'New Email')),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Cancel')),
          ElevatedButton(
            onPressed: () async {
              try {
                await ref.read(authNotifierProvider.notifier).changeEmail(
                    emailCtrl.text.trim(), '');
                if (ctx.mounted) {
                  Navigator.pop(ctx);
                  showSuccessSnack(context, 'Verification email sent');
                }
              } catch (e) {
                if (ctx.mounted) showErrorSnack(context, e);
              }
            },
            child: const Text('Update')),
        ],
      ),
    );
  }

  void _showDeleteAccount(BuildContext context, WidgetRef ref) {
    final confirmCtrl = TextEditingController();
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Delete Account', style: TextStyle(color: Colors.red)),
        content: Column(mainAxisSize: MainAxisSize.min, children: [
          const Text('This cannot be undone. Type DELETE to confirm.', style: TextStyle(color: Colors.red)),
          TextField(controller: confirmCtrl, decoration: const InputDecoration(hintText: 'Type DELETE')),
        ]),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Cancel')),
          ElevatedButton(
            style: ElevatedButton.styleFrom(backgroundColor: Colors.red),
            onPressed: () async {
              if (confirmCtrl.text != 'DELETE') return;
              try {
                await ref.read(authNotifierProvider.notifier).deleteAccount('');
                if (ctx.mounted) context.go('/auth');
              } catch (e) {
                if (ctx.mounted) showErrorSnack(context, e);
              }
            },
            child: const Text('Delete', style: TextStyle(color: Colors.white))),
        ],
      ),
    );
  }

  void _showSelectionDialog(BuildContext context, WidgetRef ref, String field, List<String> options) {
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text(field.replaceAll('_', ' ').toUpperCase()),
        content: Column(mainAxisSize: MainAxisSize.min,
          children: options.map((opt) => ListTile(
            title: Text(opt.replaceAll('_', ' ').toUpperCase()),
            onTap: () async {
              await ref.read(profileProvider.notifier).updateSetting(field, opt);
              if (ctx.mounted) Navigator.pop(ctx);
            },
          )).toList()),
      ),
    );
  }

  void _toggleSetting(BuildContext context, WidgetRef ref, String field) async {
    final user = ref.read(profileProvider).user;
    if (user == null) return;
    final current = field == 'readReceipts' ? user.readReceipts : user.typingIndicator;
    await ref.read(profileProvider.notifier).updateSetting(field, !current);
    showSuccessSnack(context, 'Setting updated');
  }

  void _showHelpSupport(BuildContext context) {
    showModalBottomSheet(
      context: context, isScrollControlled: true,
      builder: (ctx) => DraggableScrollableSheet(
        expand: false, initialChildSize: 0.7,
        builder: (_, scrollCtrl) => ListView(
          controller: scrollCtrl, padding: const EdgeInsets.all(24),
          children: [
            Text('Help & Support', style: Theme.of(context).textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.w800)),
            const SizedBox(height: 16),
            const ExpansionTile(title: Text('How do I find a travel buddy?'),
              children: [Padding(padding: EdgeInsets.all(16),
                child: Text('Go to the Find a Buddy tab and browse posts from travelers looking for companions. You can also create your own post to find buddies.'))]),
            const ExpansionTile(title: Text('How does the cost splitter work?'),
              children: [Padding(padding: EdgeInsets.all(16),
                child: Text('Create a room in the Cost Splitter, add your travel mates, and log expenses. The app will calculate who owes what.'))]),
            const ExpansionTile(title: Text('How do I become a guide?'),
              children: [Padding(padding: EdgeInsets.all(16),
                child: Text('Complete your profile setup and toggle the Guide option in your profile settings.'))]),
            const ExpansionTile(title: Text('How do payments work?'),
              children: [Padding(padding: EdgeInsets.all(16),
                child: Text('We use Stripe for secure payments. When you book a package, you\'ll be prompted to enter your payment details.'))]),
          ],
        ),
      ),
    );
  }
}

class _SectionHeader extends StatelessWidget {
  final String title;
  const _SectionHeader({required this.title});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 24, 16, 8),
      child: Text(title.toUpperCase(),
        style: TextStyle(fontSize: 12, fontWeight: FontWeight.w700,
          color: Theme.of(context).colorScheme.primary, letterSpacing: 1)),
    );
  }
}
